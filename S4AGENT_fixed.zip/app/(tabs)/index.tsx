import React, { useEffect, useState } from 'react';
import { View, StyleSheet, Keyboard, SafeAreaView } from 'react-native';
import { useAppStore } from '@/store';
import { useAIAgent } from '@/hooks/useAIAgent';
import { useFileSystem } from '@/hooks/useFileSystem';
import { Chat } from '@/components/chat/Chat';
import { FileTree } from '@/components/file-manager/FileTree';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { LucideIcon } from '@/components/ui/LucideIcon';
import { useTheme } from '@/hooks';

export default function ChatScreen() {
  const { theme, colors, spacing, typography } = useTheme();
  const { chatHistory, addChatMessage, clearChatHistory, agentConfig, setAgentConfig } = useAppStore();
  const { loadProject, currentProject } = useFileSystem();
  const { sendMessage, isProcessing, updateConfig, checkConnection } = useAIAgent();
  
  const [showProjectPicker, setShowProjectPicker] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [projectPath, setProjectPath] = useState('');
  const [temperature, setTemperature] = useState(agentConfig.temperature);
  const [maxTokens, setMaxTokens] = useState(agentConfig.maxTokens);
  const [systemPrompt, setSystemPrompt] = useState(agentConfig.systemPrompt);

  useEffect(() => {
    checkConnection();
  }, [checkConnection]);

  const handleSendMessage = (content: string) => {
    sendMessage(content);
  };

  const handleLoadProject = () => {
    if (projectPath.trim()) {
      loadProject(projectPath.trim());
      setShowProjectPicker(false);
    }
  };

  const handleSaveSettings = () => {
    updateConfig({
      temperature,
      maxTokens,
      systemPrompt,
    });
    setShowSettings(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <LucideIcon name="bot" size={24} color={colors.primary} />
          <Text style={styles.title}>S4AGENT</Text>
        </View>
        <View style={styles.headerRight}>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setShowProjectPicker(true)}
            leftIcon={<LucideIcon name="folder" size={16} />}
          >
            {currentProject ? 'Project' : 'Open Project'}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setShowSettings(true)}
            leftIcon={<LucideIcon name="settings" size={16} />}
          >
            Settings
          </Button>
        </View>
      </View>

      <View style={styles.chatContainer}>
        <Chat
          messages={chatHistory}
          onSendMessage={handleSendMessage}
          isLoading={isProcessing}
          placeholder="Ask me to create, edit, or analyze files..."
        />
      </View>

      <Modal
        visible={showProjectPicker}
        onClose={() => setShowProjectPicker(false)}
        title="Open Project"
        description="Enter the path to your project directory"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="Project Path"
            placeholder="/path/to/project"
            value={projectPath}
            onChangeText={setProjectPath}
            helperText="Enter the full path to your project directory"
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => setShowProjectPicker(false)}>
              Cancel
            </Button>
            <Button onPress={handleLoadProject}>
              Open Project
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showSettings}
        onClose={() => setShowSettings(false)}
        title="AI Settings"
        size="lg"
      >
        <View style={styles.modalContent}>
          <Card>
            <CardTitle>Model Configuration</CardTitle>
            <CardContent>
              <Input
                label="Model"
                value={agentConfig.model}
                onChangeText={(v) => updateConfig({ model: v })}
                placeholder="deepseek-coder:6.7b"
              />
              <Input
                label="API Provider"
                value={agentConfig.apiProvider}
                onChangeText={(v) => updateConfig({ apiProvider: v as any })}
                placeholder="ollama"
              />
              <Input
                label="API Endpoint"
                value={agentConfig.apiEndpoint}
                onChangeText={(v) => updateConfig({ apiEndpoint: v })}
                placeholder="http://localhost:11434"
              />
            </CardContent>
          </Card>

          <Card>
            <CardTitle>Generation Parameters</CardTitle>
            <CardContent>
              <View style={styles.sliderContainer}>
                <Text style={styles.sliderLabel}>Temperature: {temperature.toFixed(1)}</Text>
                <View style={styles.slider}>
                  <Slider
                    value={temperature}
                    onValueChange={setTemperature}
                    minimumValue={0}
                    maximumValue={2}
                    step={0.1}
                    minimumTrackTintColor={colors.primary}
                    maximumTrackTintColor={colors.border}
                  />
                </View>
              </View>
              <View style={styles.sliderContainer}>
                <Text style={styles.sliderLabel}>Max Tokens: {maxTokens}</Text>
                <View style={styles.slider}>
                  <Slider
                    value={maxTokens}
                    onValueChange={setMaxTokens}
                    minimumValue={512}
                    maximumValue={8192}
                    step={256}
                    minimumTrackTintColor={colors.primary}
                    maximumTrackTintColor={colors.border}
                  />
                </View>
              </View>
            </CardContent>
          </Card>

          <Card>
            <CardTitle>System Prompt</CardTitle>
            <CardContent>
              <Input
                label="System Prompt"
                value={systemPrompt}
                onChangeText={setSystemPrompt}
                multiline
                numberOfLines={8}
                placeholder="Enter system prompt..."
              />
            </CardContent>
          </Card>

          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => setShowSettings(false)}>
              Cancel
            </Button>
            <Button onPress={handleSaveSettings}>
              Save Settings
            </Button>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

import { Slider } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
  },
  chatContainer: {
    flex: 1,
  },
  modalContent: {
    flex: 1,
    gap: 16,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 8,
  },
  sliderContainer: {
    marginVertical: 12,
  },
  sliderLabel: {
    marginBottom: 8,
  },
  slider: {
    height: 40,
  },
});