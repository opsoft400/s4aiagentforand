import React, { useState } from 'react';
import { Tabs } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { useTheme } from '@/hooks';
import { TabBar } from '@/components/ui/TabBar';
import { LucideIcon } from '@/components/ui/LucideIcon';

export default function TabLayout() {
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.onSurface,
        tabBarStyle: { backgroundColor: colors.surface },
        headerShown: false,
      }}
      tabBar={(props) => <CustomTabBar {...props} />}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Chat',
          tabBarIcon: ({ focused, color }) => (
            <LucideIcon name={focused ? 'message-square' : 'message-square'} size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="files"
        options={{
          title: 'Files',
          tabBarIcon: ({ focused, color }) => (
            <LucideIcon name={focused ? 'folder-open' : 'folder'} size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarIcon: ({ focused, color }) => (
            <LucideIcon name={focused ? 'settings' : 'settings'} size={24} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="github"
        options={{
          title: 'GitHub',
          tabBarIcon: ({ focused, color }) => (
            <LucideIcon name={focused ? 'github' : 'github'} size={24} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

function CustomTabBar({ state, descriptors, navigation, ...rest }) {
  const { colors } = useTheme();
  const [focusedTab, setFocusedTab] = useState(state.routes[state.index].name);

  const tabs = [
    { id: 'index', label: 'Chat', icon: 'message-square' },
    { id: 'files', label: 'Files', icon: 'folder' },
    { id: 'settings', label: 'Settings', icon: 'settings' },
    { id: 'github', label: 'GitHub', icon: 'github' },
  ];

  return (
    <TabBar
      tabs={tabs}
      activeTab={focusedTab}
      onTabPress={(tabId) => {
        setFocusedTab(tabId);
        const route = state.routes.find((r) => r.name === tabId);
        if (route) {
          navigation.navigate(tabId);
        }
      }}
    />
  );
}