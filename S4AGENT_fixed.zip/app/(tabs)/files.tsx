import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, Alert, TextInput, Platform } from 'react-native';
import { useAppStore } from '@/store';
import { useFileSystem } from '@/hooks/useFileSystem';
import { FileTree } from '@/components/file-manager/FileTree';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { LucideIcon } from '@/components/ui/LucideIcon';
import { useTheme } from '@/hooks';

export default function FilesScreen() {
  const { theme, colors, spacing, typography, borderRadius } = useTheme();
  const { fileTree, setFileTree, currentProject } = useAppStore();
  const { loadProject, createFile, createFolder, deleteItem, renameItem, zipFiles, unzipFile, downloadFile } = useFileSystem();
  
  const [showProjectPicker, setShowProjectPicker] = useState(false);
  const [showNewFile, setShowNewFile] = useState(false);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [showZipExport, setShowZipExport] = useState(false);
  const [showZipImport, setShowZipImport] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [projectPath, setProjectPath] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [newFolderName, setNewFolderName] = useState('');
  const [zipPath, setZipPath] = useState('');
  const [importZipPath, setImportZipPath] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [downloadPath, setDownloadPath] = useState('');
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleLoadProject = () => {
    if (projectPath.trim()) {
      loadProject(projectPath.trim());
      setShowProjectPicker(false);
    }
  };

  const handleCreateFile = async () => {
    if (newFileName.trim() && selectedFile) {
      const path = selectedFile.endsWith('/') 
        ? `${selectedFile}${newFileName.trim()}` 
        : `${selectedFile}/${newFileName.trim()}`.replace(/\/+/g, '/');
      await createFile(path);
      setShowNewFile(false);
      setNewFileName('');
    }
  };

  const handleCreateFolder = async () => {
    if (newFolderName.trim() && selectedFile) {
      const path = selectedFile.endsWith('/') 
        ? `${selectedFile}${newFolderName.trim()}` 
        : `${selectedFile}/${newFolderName.trim()}`.replace(/\/+/g, '/');
      await createFolder(path);
      setShowNewFolder(false);
      setNewFolderName('');
    }
  };

  const handleDelete = async (path: string) => {
    Alert.alert(
      'Delete',
      `Are you sure you want to delete this ${path.endsWith('/') ? 'folder' : 'file'}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => deleteItem(path, true) },
      ]
    );
  };

  const handleRename = async (oldPath: string) => {
    const newName = prompt('Enter new name:', oldPath.split('/').pop());
    if (newName && newName.trim()) {
      const newPath = oldPath.substring(0, oldPath.lastIndexOf('/') + 1) + newName.trim();
      await renameItem(oldPath, newPath);
    }
  };

  const handleZipExport = async () => {
    if (zipPath.trim() && currentProject) {
      const result = await zipFiles([currentProject], zipPath.trim());
      if (result.success) {
        Alert.alert('Success', `Project exported to ${result.path}`);
        setShowZipExport(false);
        setZipPath('');
      } else {
        Alert.alert('Error', result.error || 'Failed to create zip');
      }
    }
  };

  const handleZipImport = async () => {
    if (importZipPath.trim()) {
      const result = await unzipFile(importZipPath.trim(), currentProject || '');
      if (result.success) {
        Alert.alert('Success', 'Project imported successfully');
        setShowZipImport(false);
        setImportZipPath('');
      } else {
        Alert.alert('Error', result.error || 'Failed to extract zip');
      }
    }
  };

  const handleDownload = async () => {
    if (downloadUrl.trim() && downloadPath.trim()) {
      const success = await downloadFile(downloadUrl.trim(), downloadPath.trim());
      if (success) {
        Alert.alert('Success', 'File downloaded successfully');
        setShowDownload(false);
        setDownloadUrl('');
        setDownloadPath('');
      } else {
        Alert.alert('Error', 'Failed to download file');
      }
    }
  };

  const handleFileSelect = (file: any) => {
    setSelectedFile(file.path);
  };

  const handleFileAction = (action: string, file: any) => {
    switch (action) {
      case 'delete':
        handleDelete(file.path);
        break;
      case 'rename':
        handleRename(file.path);
        break;
      case 'download':
        setDownloadPath(file.path);
        setShowDownload(true);
        break;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <LucideIcon name="folder-open" size={24} color={colors.primary} />
          <Text style={styles.title}>File Manager</Text>
        </View>
        <View style={styles.headerRight}>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setShowProjectPicker(true)}
            leftIcon={<LucideIcon name="folder" size={16} />}
          >
            {currentProject ? 'Project' : 'Open Project'}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setShowNewFile(true)}
            leftIcon={<LucideIcon name="file-plus" size={16} />}
          >
            New File
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onPress={() => setShowNewFolder(true)}
            leftIcon={<LucideIcon name="folder-plus" size={16} />}
          >
            New Folder
          </Button>
        </View>
      </View>

      <View style={styles.toolbar}>
        <Input
          placeholder="Search files..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          leftIcon={<LucideIcon name="search" size={18} />}
          style={{ flex: 1, maxWidth: 300 }}
        />
        <View style={styles.toolbarActions}>
          <Button
            variant="outline"
            size="sm"
            onPress={() => setShowZipExport(true)}
            leftIcon={<LucideIcon name="download" size={14} />}
          >
            Export Zip
          </Button>
          <Button
            variant="outline"
            size="sm"
            onPress={() => setShowZipImport(true)}
            leftIcon={<LucideIcon name="upload" size={14} />}
          >
            Import Zip
          </Button>
        </View>
      </View>

      <View style={styles.content}>
        {fileTree ? (
          <FileTree
            rootNode={fileTree}
            onFileSelect={handleFileSelect}
            onFileAction={handleFileAction}
            onFolderToggle={() => {}}
            searchQuery={searchQuery}
          />
        ) : (
          <View style={styles.emptyState}>
            <LucideIcon name="folder-open" size={64} color={colors.onSurface} opacity={0.3} />
            <Text style={styles.emptyText}>No project opened</Text>
            <Text style={styles.emptySubtext}>Click "Open Project" to select a directory</Text>
            <Button
              variant="primary"
              onPress={() => setShowProjectPicker(true)}
              style={{ marginTop: spacing.md, width: 200 }}
            >
              Open Project
            </Button>
          </View>
        )}
      </View>

      <Modal
        visible={showProjectPicker}
        onClose={() => setShowProjectPicker(false)}
        title="Open Project"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="Project Path"
            placeholder="/path/to/project"
            value={projectPath}
            onChangeText={setProjectPath}
            helperText="Enter the full path to your project directory"
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => setShowProjectPicker(false)}>
              Cancel
            </Button>
            <Button onPress={handleLoadProject}>
              Open Project
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showNewFile}
        onClose={() => { setShowNewFile(false); setNewFileName(''); }}
        title="Create New File"
        size="sm"
      >
        <View style={styles.modalContent}>
          <Input
            label="File Name"
            placeholder="example.js"
            value={newFileName}
            onChangeText={setNewFileName}
            helperText={`Will be created in: ${selectedFile || 'root'}`}
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowNewFile(false); setNewFileName(''); }}>
              Cancel
            </Button>
            <Button onPress={handleCreateFile} disabled={!newFileName.trim()}>
              Create File
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showNewFolder}
        onClose={() => { setShowNewFolder(false); setNewFolderName(''); }}
        title="Create New Folder"
        size="sm"
      >
        <View style={styles.modalContent}>
          <Input
            label="Folder Name"
            placeholder="new-folder"
            value={newFolderName}
            onChangeText={setNewFolderName}
            helperText={`Will be created in: ${selectedFile || 'root'}`}
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowNewFolder(false); setNewFolderName(''); }}>
              Cancel
            </Button>
            <Button onPress={handleCreateFolder} disabled={!newFolderName.trim()}>
              Create Folder
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showZipExport}
        onClose={() => { setShowZipExport(false); setZipPath(''); }}
        title="Export as Zip"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="Output Path"
            placeholder="/path/to/project.zip"
            value={zipPath}
            onChangeText={setZipPath}
            helperText="Enter the path where the zip file should be saved"
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowZipExport(false); setZipPath(''); }}>
              Cancel
            </Button>
            <Button onPress={handleZipExport} disabled={!zipPath.trim()}>
              Export Zip
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showZipImport}
        onClose={() => { setShowZipImport(false); setImportZipPath(''); }}
        title="Import Zip"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="Zip File Path"
            placeholder="/path/to/project.zip"
            value={importZipPath}
            onChangeText={setImportZipPath}
            helperText="Enter the path to the zip file to extract"
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowZipImport(false); setImportZipPath(''); }}>
              Cancel
            </Button>
            <Button onPress={handleZipImport} disabled={!importZipPath.trim()}>
              Import Zip
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showDownload}
        onClose={() => { setShowDownload(false); setDownloadUrl(''); setDownloadPath(''); }}
        title="Download File"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="URL"
            placeholder="https://example.com/file.js"
            value={downloadUrl}
            onChangeText={setDownloadUrl}
          />
          <Input
            label="Save As"
            placeholder="filename.js"
            value={downloadPath}
            onChangeText={setDownloadPath}
          />
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowDownload(false); setDownloadUrl(''); setDownloadPath(''); }}>
              Cancel
            </Button>
            <Button onPress={handleDownload} disabled={!downloadUrl.trim() || !downloadPath.trim()}>
              Download
            </Button>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
  },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  toolbarActions: {
    flexDirection: 'row',
    gap: 8,
  },
  content: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    gap: 16,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
  },
  emptySubtext: {
    opacity: 0.6,
    textAlign: 'center',
  },
  modalContent: {
    gap: 16,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 8,
  },
});