import React, { useState } from 'react';
import { View, StyleSheet, SafeAreaView, ScrollView, Switch, Alert } from 'react-native';
import { useAppStore } from '@/store';
import { useTheme } from '@/hooks';
import { Card, CardTitle, CardDescription, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { LucideIcon } from '@/components/ui/LucideIcon';

export default function SettingsScreen() {
  const { theme, colors, spacing, typography, borderRadius } = useTheme();
  const { preferences, setPreferences, agentConfig, setAgentConfig } = useAppStore();

  const [tempFontSize, setTempFontSize] = useState(preferences.fontSize);
  const [tempSidebarWidth, setTempSidebarWidth] = useState(preferences.sidebarWidth);
  const [tempPanelHeight, setTempPanelHeight] = useState(preferences.panelHeight);

  const handleSavePreferences = () => {
    setPreferences({
      fontSize: tempFontSize,
      sidebarWidth: tempSidebarWidth,
      panelHeight: tempPanelHeight,
    });
    Alert.alert('Saved', 'Preferences have been saved');
  };

  const handleResetPreferences = () => {
    Alert.alert(
      'Reset Preferences',
      'Are you sure you want to reset all preferences to defaults?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: () => {
            setPreferences({
              theme: 'dark',
              layout: 'ide',
              fontSize: 15,
              fontFamily: 'JetBrains Mono',
              sidebarWidth: 280,
              panelHeight: 300,
              showLineNumbers: true,
              wordWrap: true,
              tabSize: 2,
              autoSave: true,
              aiConfirmActions: true,
              aiAutoRunTools: false,
              language: 'en',
              keyboardShortcuts: {},
            });
          },
        },
      ]
    );
  };

  const themeOptions = [
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System' },
    { value: 'custom', label: 'Custom' },
  ];

  const layoutOptions = [
    { value: 'ide', label: 'IDE' },
    { value: 'chat', label: 'Chat' },
    { value: 'minimal', label: 'Minimal' },
  ];

  const fontFamilyOptions = [
    { value: 'JetBrains Mono', label: 'JetBrains Mono' },
    { value: 'Fira Code', label: 'Fira Code' },
    { value: 'Source Code Pro', label: 'Source Code Pro' },
    { value: 'Monospace', label: 'System Monospace' },
  ];

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Spanish' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' },
    { value: 'zh', label: 'Chinese' },
    { value: 'ja', label: 'Japanese' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <LucideIcon name="settings" size={24} color={colors.primary} />
        <Text style={styles.title}>Settings</Text>
      </View>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.scrollContent}>
        <Card>
          <CardTitle>Appearance</CardTitle>
          <CardContent>
            <Select
              label="Theme"
              placeholder="Select theme"
              value={preferences.theme}
              onChange={(v) => setPreferences({ theme: v as any })}
              options={themeOptions}
            />
            <Select
              label="Layout"
              placeholder="Select layout"
              value={preferences.layout}
              onChange={(v) => setPreferences({ layout: v as any })}
              options={layoutOptions}
            />
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Font Size</Text>
                <Text style={styles.settingValue}>{tempFontSize}px</Text>
              </View>
              <Slider
                value={tempFontSize}
                onValueChange={setTempFontSize}
                minimumValue={10}
                maximumValue={24}
                step={1}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                style={{ flex: 1, marginLeft: spacing.md }}
              />
            </View>
            <Select
              label="Font Family"
              placeholder="Select font"
              value={preferences.fontFamily}
              onChange={(v) => setPreferences({ fontFamily: v })}
              options={fontFamilyOptions}
            />
          </CardContent>
        </Card>

        <Card>
          <CardTitle>Editor</CardTitle>
          <CardContent>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleLabelText}>Show Line Numbers</Text>
                <Text style={styles.toggleLabelHint}>Display line numbers in editor</Text>
              </View>
              <Switch
                value={preferences.showLineNumbers}
                onValueChange={(v) => setPreferences({ showLineNumbers: v })}
                thumbColor={preferences.showLineNumbers ? colors.primary : colors.border}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleLabelText}>Word Wrap</Text>
                <Text style={styles.toggleLabelHint}>Wrap long lines in editor</Text>
              </View>
              <Switch
                value={preferences.wordWrap}
                onValueChange={(v) => setPreferences({ wordWrap: v })}
                thumbColor={preferences.wordWrap ? colors.primary : colors.border}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleLabelText}>Auto Save</Text>
                <Text style={styles.toggleLabelHint}>Automatically save files</Text>
              </View>
              <Switch
                value={preferences.autoSave}
                onValueChange={(v) => setPreferences({ autoSave: v })}
                thumbColor={preferences.autoSave ? colors.primary : colors.border}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Tab Size</Text>
                <Text style={styles.settingValue}>{preferences.tabSize} spaces</Text>
              </View>
              <Select
                value={String(preferences.tabSize)}
                onChange={(v) => setPreferences({ tabSize: parseInt(v) })}
                options={[
                  { value: '2', label: '2 spaces' },
                  { value: '4', label: '4 spaces' },
                  { value: '8', label: '8 spaces' },
                ]}
                style={{ flex: 1, maxWidth: 150, marginLeft: spacing.md }}
              />
            </View>
          </CardContent>
        </Card>

        <Card>
          <CardTitle>AI Assistant</CardTitle>
          <CardContent>
            <Select
              label="Model"
              placeholder="Select model"
              value={agentConfig.model}
              onChange={(v) => setAgentConfig({ model: v })}
              options={[
                { value: 'deepseek-coder:6.7b', label: 'DeepSeek Coder 6.7B' },
                { value: 'deepseek-coder:33b', label: 'DeepSeek Coder 33B' },
                { value: 'deepseek-chat:7b', label: 'DeepSeek Chat 7B' },
                { value: 'deepseek-llm:7b', label: 'DeepSeek LLM 7B' },
                { value: 'deepseek-llm:67b', label: 'DeepSeek LLM 67B' },
                { value: 'codellama:7b', label: 'CodeLlama 7B' },
                { value: 'codellama:13b', label: 'CodeLlama 13B' },
                { value: 'codellama:34b', label: 'CodeLlama 34B' },
              ]}
            />
            <Select
              label="API Provider"
              placeholder="Select provider"
              value={agentConfig.apiProvider}
              onChange={(v) => setAgentConfig({ apiProvider: v as any })}
              options={[
                { value: 'ollama', label: 'Ollama (Local)' },
                { value: 'deepseek', label: 'DeepSeek API' },
                { value: 'opencode', label: 'Opencode Server' },
                { value: 'custom', label: 'Custom Endpoint' },
              ]}
            />
            <Input
              label="API Endpoint"
              value={agentConfig.apiEndpoint}
              onChangeText={(v) => setAgentConfig({ apiEndpoint: v })}
              placeholder="http://localhost:11434"
            />
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Temperature</Text>
                <Text style={styles.settingValue}>{agentConfig.temperature.toFixed(1)}</Text>
              </View>
              <Slider
                value={agentConfig.temperature}
                onValueChange={(v) => setAgentConfig({ temperature: v })}
                minimumValue={0}
                maximumValue={2}
                step={0.1}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                style={{ flex: 1, marginLeft: spacing.md }}
              />
            </View>
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Max Tokens</Text>
                <Text style={styles.settingValue}>{agentConfig.maxTokens}</Text>
              </View>
              <Slider
                value={agentConfig.maxTokens}
                onValueChange={(v) => setAgentConfig({ maxTokens: v })}
                minimumValue={512}
                maximumValue={8192}
                step={256}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                style={{ flex: 1, marginLeft: spacing.md }}
              />
            </View>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleLabelText}>Confirm AI Actions</Text>
                <Text style={styles.toggleLabelHint}>Ask before executing file operations</Text>
              </View>
              <Switch
                value={preferences.aiConfirmActions}
                onValueChange={(v) => setPreferences({ aiConfirmActions: v })}
                thumbColor={preferences.aiConfirmActions ? colors.primary : colors.border}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
            <View style={styles.toggleRow}>
              <View style={styles.toggleLabel}>
                <Text style={styles.toggleLabelText}>Auto Run Tools</Text>
                <Text style={styles.toggleLabelHint}>Automatically execute tool calls</Text>
              </View>
              <Switch
                value={preferences.aiAutoRunTools}
                onValueChange={(v) => setPreferences({ aiAutoRunTools: v })}
                thumbColor={preferences.aiAutoRunTools ? colors.primary : colors.border}
                trackColor={{ false: colors.border, true: colors.primary }}
              />
            </View>
          </CardContent>
        </Card>

        <Card>
          <CardTitle>UI Layout</CardTitle>
          <CardContent>
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Sidebar Width</Text>
                <Text style={styles.settingValue}>{tempSidebarWidth}px</Text>
              </View>
              <Slider
                value={tempSidebarWidth}
                onValueChange={setTempSidebarWidth}
                minimumValue={200}
                maximumValue={500}
                step={10}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                style={{ flex: 1, marginLeft: spacing.md }}
              />
            </View>
            <View style={styles.settingRow}>
              <View style={styles.settingLabel}>
                <Text style={styles.settingLabelText}>Panel Height</Text>
                <Text style={styles.settingValue}>{tempPanelHeight}px</Text>
              </View>
              <Slider
                value={tempPanelHeight}
                onValueChange={setTempPanelHeight}
                minimumValue={200}
                maximumValue={600}
                step={10}
                minimumTrackTintColor={colors.primary}
                maximumTrackTintColor={colors.border}
                style={{ flex: 1, marginLeft: spacing.md }}
              />
            </View>
          </CardContent>
        </Card>

        <Card>
          <CardTitle>Language & Region</CardTitle>
          <CardContent>
            <Select
              label="Language"
              placeholder="Select language"
              value={preferences.language}
              onChange={(v) => setPreferences({ language: v })}
              options={languageOptions}
            />
          </CardContent>
        </Card>

        <Card>
          <CardTitle>Advanced</CardTitle>
          <CardContent>
            <Button
              variant="outline"
              onPress={handleResetPreferences}
              leftIcon={<LucideIcon name="refresh-cw" size={16} />}
              style={{ marginBottom: spacing.sm }}
            >
              Reset All Preferences
            </Button>
            <Button
              variant="secondary"
              onPress={handleSavePreferences}
              leftIcon={<LucideIcon name="save" size={16} />}
            >
              Save Preferences
            </Button>
          </CardContent>
        </Card>

        <View style={styles.versionInfo}>
          <Text style={styles.versionText}>S4AGENT v1.0.0</Text>
          <Text style={styles.versionText}>Built with Expo & React Native</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

import { Slider } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  settingLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  settingLabelText: {
    fontSize: 15,
    fontWeight: '500',
  },
  settingValue: {
    fontSize: 14,
    opacity: 0.6,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  toggleLabel: {
    flex: 1,
  },
  toggleLabelText: {
    fontSize: 15,
    fontWeight: '500',
  },
  toggleLabelHint: {
    fontSize: 12,
    opacity: 0.6,
    marginTop: 2,
  },
  versionInfo: {
    alignItems: 'center',
    paddingVertical: 24,
    gap: 4,
  },
  versionText: {
    fontSize: 13,
    opacity: 0.5,
  },
});