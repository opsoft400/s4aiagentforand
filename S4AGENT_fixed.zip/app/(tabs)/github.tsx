import React, { useState, useEffect } from 'react';
import { View, StyleSheet, SafeAreaView, ScrollView, Alert, Switch, TextInput } from 'react-native';
import { useAppStore } from '@/store';
import { useTheme } from '@/hooks';
import { useGitHubAuth } from '@/hooks/useGitHubAuth';
import { Card, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { LucideIcon } from '@/components/ui/LucideIcon';
import { GitHubService } from '@/services/github';

export default function GitHubScreen() {
  const { theme, colors, spacing, typography } = useTheme();
  const { githubToken, githubUser, setGitHubToken, setGitHubUser } = useAppStore();
  const { isAuthenticated, user, token, repos, isLoading: authLoading, login, logout, refreshRepos, getService, error: authError, isReady } = useGitHubAuth();
  
  const [selectedRepo, setSelectedRepo] = useState<any>(null);
  const [showRepoOptions, setShowRepoOptions] = useState(false);
  const [showCreateRepo, setShowCreateRepo] = useState(false);
  const [newRepoName, setNewRepoName] = useState('');
  const [newRepoPrivate, setNewRepoPrivate] = useState(false);
  const [newRepoDescription, setNewRepoDescription] = useState('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadRepo, setUploadRepo] = useState<string>('');
  const [uploadBranch, setUploadBranch] = useState('main');
  const [uploadFiles, setUploadFiles] = useState<{path: string; content: string; message: string}[]>([]);
  const [repoFiles, setRepoFiles] = useState<any[]>([]);
  const [showRepoFiles, setShowRepoFiles] = useState(false);
  const [currentRepoPath, setCurrentRepoPath] = useState<string>('');
  const [isLoadingRepos, setIsLoadingRepos] = useState(false);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);

  const githubService = getService();

  useEffect(() => {
    if (isAuthenticated && githubService) {
      loadRepos();
    }
  }, [isAuthenticated, githubService]);

  const loadRepos = async () => {
    if (!githubService) return;
    setIsLoadingRepos(true);
    try {
      const data = await githubService.getRepos();
      setRepos(data);
    } catch (error) {
      Alert.alert('Error', 'Failed to load repositories');
    } finally {
      setIsLoadingRepos(false);
    }
  };

  const handleCreateRepo = async () => {
    if (!githubService || !newRepoName.trim()) return;
    try {
      await githubService.createRepo(newRepoName.trim(), {
        private: newRepoPrivate,
        description: newRepoDescription,
      });
      Alert.alert('Success', 'Repository created successfully');
      setShowCreateRepo(false);
      setNewRepoName('');
      setNewRepoDescription('');
      setNewRepoPrivate(false);
      loadRepos();
    } catch (error) {
      Alert.alert('Error', 'Failed to create repository');
    }
  };

  const handleUploadFiles = async () => {
    if (!githubService || !uploadRepo || uploadFiles.length === 0) return;
    try {
      const [owner, repo] = uploadRepo.split('/');
      await githubService.uploadFiles(owner, repo, uploadFiles, uploadBranch);
      Alert.alert('Success', 'Files uploaded successfully');
      setShowUploadModal(false);
      setUploadFiles([]);
      setUploadRepo('');
    } catch (error) {
      Alert.alert('Error', 'Failed to upload files');
    }
  };

  const handleSelectRepo = (repo: any) => {
    setSelectedRepo(repo);
    setShowRepoOptions(true);
  };

  const handleRepoAction = (action: string) => {
    if (!selectedRepo || !githubService) return;

    const [owner, repo] = selectedRepo.fullName.split('/');

    switch (action) {
      case 'view':
        loadRepoFiles(owner, repo);
        setShowRepoFiles(true);
        setCurrentRepoPath('');
        break;
      case 'upload':
        setUploadRepo(selectedRepo.fullName);
        setShowUploadModal(true);
        break;
      case 'clone':
        Alert.alert('Clone URL', selectedRepo.cloneUrl, [{ text: 'Copy', onPress: () => {} }]);
        break;
      case 'delete':
        Alert.alert('Delete Repository', 'This action cannot be undone. Repository deletion requires admin access.', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Delete', style: 'destructive', onPress: () => {} },
        ]);
        break;
      case 'create_pr':
        // Would open PR creation modal
        break;
      case 'releases':
        // Would show releases
        break;
      case 'workflows':
        // Would show workflows
        break;
    }
    setShowRepoOptions(false);
  };

  const loadRepoFiles = async (owner: string, repo: string, path: string = '') => {
    if (!githubService) return;
    setIsLoadingFiles(true);
    try {
      const files = path 
        ? await githubService.getDirectory(owner, repo, path)
        : await githubService.getDirectory(owner, repo, '');
      setRepoFiles(files);
    } catch (error) {
      Alert.alert('Error', 'Failed to load repository files');
    } finally {
      setIsLoadingFiles(false);
    }
  };

  const handleFileClick = (file: any) => {
    if (file.type === 'dir') {
      const [owner, repo] = selectedRepo.fullName.split('/');
      loadRepoFiles(owner, repo, file.path);
      setCurrentRepoPath(file.path);
    } else {
      // View file content
      Alert.alert(file.name, `File: ${file.path}\nSize: ${file.size} bytes\nSHA: ${file.sha}`);
    }
  };

  const addUploadFile = () => {
    setUploadFiles((prev) => [...prev, { path: '', content: '', message: 'Add file' }]);
  };

  const updateUploadFile = (index: number, field: string, value: string) => {
    setUploadFiles((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const removeUploadFile = (index: number) => {
    setUploadFiles((prev) => prev.filter((_, i) => i !== index));
  };

  if (!isReady) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centered}>
          <LucideIcon name="github" size={64} color={colors.primary} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isAuthenticated) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centered}>
          <LucideIcon name="github" size={64} color={colors.primary} />
          <Text style={styles.title}>GitHub Integration</Text>
          <Text style={styles.description}>
            Connect your GitHub account to manage repositories, upload files, create releases, and more.
            Uses GitHub OAuth for secure authentication.
          </Text>
          {authError && (
            <View style={styles.error}>
              <Text>{authError}</Text>
            </View>
          )}
          <Button
            variant="primary"
            onPress={login}
            style={{ marginTop: spacing.lg, width: 280 }}
            leftIcon={<LucideIcon name="github" size={20} />}
          >
            Connect with GitHub
          </Button>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <LucideIcon name="github" size={24} color={colors.primary} />
          <Text style={styles.title}>GitHub</Text>
        </View>
        <View style={styles.headerRight}>
          {user && (
            <View style={styles.userInfo}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{user.login.charAt(0).toUpperCase()}</Text>
              </View>
              <Text style={styles.userName}>{user.login}</Text>
              <Button
                variant="ghost"
                size="sm"
                onPress={logout}
              >
                Logout
              </Button>
            </View>
          )}
          <Button
            variant="primary"
            onPress={() => setShowCreateRepo(true)}
            leftIcon={<LucideIcon name="plus" size={16} />}
          >
            New Repo
          </Button>
        </View>
      </View>

      <ScrollView style={styles.list} contentContainerStyle={styles.listContent} refreshControl={
        <RefreshControl refreshing={isLoadingRepos} onRefresh={loadRepos} />
      }>
        {isLoadingRepos ? (
          <View style={styles.loading}>
            <LucideIcon name="refresh-cw" size={32} color={colors.primary} />
            <Text style={styles.loadingText}>Loading repositories...</Text>
          </View>
        ) : repos.length === 0 ? (
          <View style={styles.emptyState}>
            <LucideIcon name="github" size={64} color={colors.onSurface} opacity={0.3} />
            <Text style={styles.emptyText}>No repositories found</Text>
            <Button
              variant="primary"
              onPress={() => setShowCreateRepo(true)}
              style={{ marginTop: spacing.md, width: 200 }}
            >
              Create Repository
            </Button>
          </View>
        ) : (
          repos.map((repo) => (
            <Card
              key={repo.id}
              variant="outlined"
              onPress={() => handleSelectRepo(repo)}
              style={styles.repoCard}
            >
              <View style={styles.repoHeader}>
                <View style={styles.repoIcon}>
                  <LucideIcon
                    name={repo.private ? 'lock' : 'globe'}
                    size={20}
                    color={colors.primary}
                  />
                </View>
                <View style={styles.repoInfo}>
                  <Text style={styles.repoName}>{repo.name}</Text>
                  <Text style={styles.repoDescription}>
                    {repo.description || 'No description'}
                  </Text>
                </View>
              </View>
              <View style={styles.repoMeta}>
                <Text style={styles.repoMetaItem}>
                  <LucideIcon name="star" size={12} />
                  {repo.stargazers_count || 0}
                </Text>
                <Text style={styles.repoMetaItem}>
                  <LucideIcon name="git-branch" size={12} />
                  {repo.forks_count || 0}
                </Text>
                <Text style={styles.repoMetaItem}>
                  <LucideIcon name="code" size={12} />
                  {repo.language || 'Unknown'}
                </Text>
                <Text style={styles.repoMetaItem}>
                  <LucideIcon name="calendar" size={12} />
                  {new Date(repo.updatedAt).toLocaleDateString()}
                </Text>
              </View>
            </Card>
          ))
        )}
      </ScrollView>

      <Modal
        visible={showCreateRepo}
        onClose={() => setShowCreateRepo(false)}
        title="Create Repository"
        size="md"
      >
        <View style={styles.modalContent}>
          <Input
            label="Repository Name"
            placeholder="my-awesome-project"
            value={newRepoName}
            onChangeText={setNewRepoName}
          />
          <Input
            label="Description (optional)"
            placeholder="A brief description"
            value={newRepoDescription}
            onChangeText={setNewRepoDescription}
            multiline
            numberOfLines={3}
          />
          <View style={styles.toggleRow}>
            <Text style={styles.toggleLabelText}>Private Repository</Text>
            <Switch
              value={newRepoPrivate}
              onValueChange={setNewRepoPrivate}
              thumbColor={newRepoPrivate ? colors.primary : colors.border}
              trackColor={{ false: colors.border, true: colors.primary }}
            />
          </View>
          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => setShowCreateRepo(false)}>
              Cancel
            </Button>
            <Button onPress={handleCreateRepo} disabled={!newRepoName.trim()}>
              Create Repository
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showRepoOptions}
        onClose={() => setShowRepoOptions(false)}
        title={selectedRepo?.name}
        size="sm"
      >
        <View style={styles.modalContent}>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('view')}
            leftIcon={<LucideIcon name="eye" size={16} />}
            style={styles.optionButton}
          >
            View Files
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('upload')}
            leftIcon={<LucideIcon name="upload" size={16} />}
            style={styles.optionButton}
          >
            Upload Files
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('create_pr')}
            leftIcon={<LucideIcon name="git-pull-request" size={16} />}
            style={styles.optionButton}
          >
            Create Pull Request
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('releases')}
            leftIcon={<LucideIcon name="tag" size={16} />}
            style={styles.optionButton}
          >
            Releases
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('workflows')}
            leftIcon={<LucideIcon name="workflow" size={16} />}
            style={styles.optionButton}
          >
            Workflows
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('clone')}
            leftIcon={<LucideIcon name="download" size={16} />}
            style={styles.optionButton}
          >
            Clone URL
          </Button>
          <Button
            variant="outline"
            onPress={() => handleRepoAction('delete')}
            leftIcon={<LucideIcon name="trash" size={16} />}
            style={[styles.optionButton, { borderColor: colors.error }]}
          >
            Delete Repository
          </Button>
        </View>
      </Modal>

      <Modal
        visible={showUploadModal}
        onClose={() => { setShowUploadModal(false); setUploadFiles([]); }}
        title="Upload Files"
        size="lg"
      >
        <View style={styles.modalContent}>
          <Input
            label="Repository"
            value={uploadRepo}
            editable={false}
          />
          <Input
            label="Branch"
            placeholder="main"
            value={uploadBranch}
            onChangeText={setUploadBranch}
          />
          
          {uploadFiles.map((file, index) => (
            <View key={index} style={styles.uploadFileRow}>
              <Input
                label={`File ${index + 1} Path`}
                placeholder="src/main.js"
                value={file.path}
                onChangeText={(v) => updateUploadFile(index, 'path', v)}
                style={{ flex: 1 }}
              />
              <Button
                variant="ghost"
                size="sm"
                onPress={() => removeUploadFile(index)}
                style={{ marginTop: 28 }}
              >
                <LucideIcon name="x" size={16} />
              </Button>
            </View>
          ))}
          
          {uploadFiles.map((file, index) => (
            <Input
              key={`content-${index}`}
              label={`File ${index + 1} Content`}
              placeholder="File content..."
              value={file.content}
              onChangeText={(v) => updateUploadFile(index, 'content', v)}
              multiline
              numberOfLines={4}
            />
          ))}

          {uploadFiles.map((file, index) => (
            <Input
              key={`message-${index}`}
              label={`File ${index + 1} Commit Message`}
              placeholder="Add file"
              value={file.message}
              onChangeText={(v) => updateUploadFile(index, 'message', v)}
            />
          ))}

          <Button
            variant="secondary"
            onPress={addUploadFile}
            leftIcon={<LucideIcon name="plus" size={16} />}
            style={{ marginTop: spacing.sm }}
          >
            Add Another File
          </Button>

          <View style={styles.modalActions}>
            <Button variant="secondary" onPress={() => { setShowUploadModal(false); setUploadFiles([]); }}>
              Cancel
            </Button>
            <Button onPress={handleUploadFiles} disabled={uploadFiles.length === 0}>
              Upload Files
            </Button>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showRepoFiles}
        onClose={() => setShowRepoFiles(false)}
        title={`${selectedRepo?.name} / ${currentRepoPath || 'root'}`}
        size="xl"
      >
        <View style={styles.modalContent}>
          {currentRepoPath && (
            <Button
              variant="ghost"
              onPress={() => {
                const parentPath = currentRepoPath.substring(0, currentRepoPath.lastIndexOf('/'));
                setCurrentRepoPath(parentPath);
                const [owner, repo] = selectedRepo.fullName.split('/');
                loadRepoFiles(owner, repo, parentPath);
              }}
              leftIcon={<LucideIcon name="chevron-left" size={16} />}
              style={{ marginBottom: spacing.sm, alignSelf: 'flex-start' }}
            >
              Go Up
            </Button>
          )}
          <View style={{ maxHeight: 500 }}>
            {isLoadingFiles ? (
              <View style={styles.loading}>
                <LucideIcon name="refresh-cw" size={24} color={colors.primary} />
                <Text>Loading files...</Text>
              </View>
            ) : repoFiles.length === 0 ? (
              <View style={styles.emptyState}>
                <LucideIcon name="folder-open" size={48} color={colors.onSurface} opacity={0.3} />
                <Text style={styles.emptyText}>This folder is empty</Text>
              </View>
            ) : (
              <View style={styles.fileList}>
                {repoFiles.map((file) => (
                  <TouchableWithoutFeedback key={file.sha} onPress={() => handleFileClick(file)}>
                    <View style={styles.fileRow}>
                      <LucideIcon
                        name={file.type === 'dir' ? 'folder' : 'file'}
                        size={20}
                        color={file.type === 'dir' ? colors.primary : colors.onSurface}
                      />
                      <Text style={styles.fileName}>{file.name}</Text>
                      <Text style={styles.fileMeta}>
                        {file.type === 'file' ? `${(file.size / 1024).toFixed(1)} KB` : 'Folder'}
                      </Text>
                    </View>
                  </TouchableWithoutFeedback>
                ))}
              </View>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

import { RefreshControl, TouchableWithoutFeedback } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    gap: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    textAlign: 'center',
  },
  description: {
    textAlign: 'center',
    opacity: 0.7,
    fontSize: 15,
  },
  loadingText: {
    opacity: 0.7,
    marginTop: 8,
  },
  error: {
    backgroundColor: '#ef4444',
    padding: 12,
    borderRadius: 8,
    marginTop: 12,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#0ea5e9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  userName: {
    fontSize: 14,
    fontWeight: '500',
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: 16,
    gap: 12,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    opacity: 0.7,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    gap: 16,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
  },
  repoCard: {
    padding: 16,
  },
  repoHeader: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  repoIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#0ea5e9',
    opacity: 0.1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  repoInfo: {
    flex: 1,
  },
  repoName: {
    fontSize: 16,
    fontWeight: '600',
  },
  repoDescription: {
    fontSize: 13,
    opacity: 0.7,
    marginTop: 2,
  },
  repoMeta: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  repoMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    fontSize: 12,
    opacity: 0.6,
  },
  modalContent: {
    gap: 16,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    marginTop: 8,
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
  },
  toggleLabelText: {
    fontSize: 15,
    fontWeight: '500',
  },
  uploadFileRow: {
    flexDirection: 'row',
    gap: 8,
  },
  optionButton: {
    width: '100%',
    justifyContent: 'flex-start',
  },
  fileList: {
    maxHeight: 400,
  },
  fileRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderBottomWidth: 1,
  },
  fileName: {
    flex: 1,
    fontSize: 14,
  },
  fileMeta: {
    fontSize: 12,
    opacity: 0.6,
  },
});