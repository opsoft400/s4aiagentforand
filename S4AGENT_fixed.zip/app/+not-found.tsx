import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Link } from 'expo-router';
import { LucideIcon } from '@/components/ui/LucideIcon';
import { useTheme } from '@/hooks';

export default function NotFound() {
  const { colors, spacing } = useTheme();

  return (
    <View style={styles.container}>
      <LucideIcon name="search-x" size={64} color={colors.primary} />
      <Text style={styles.title}>404 - Not Found</Text>
      <Text style={styles.description}>The screen you're looking for doesn't exist.</Text>
      <Link href="/(tabs)" asChild>
        <View style={styles.button}>
          <Text style={styles.buttonText}>Go Home</Text>
        </View>
      </Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
    gap: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
  },
  description: {
    textAlign: 'center',
    opacity: 0.7,
  },
  button: {
    marginTop: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    backgroundColor: '#0ea5e9',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});