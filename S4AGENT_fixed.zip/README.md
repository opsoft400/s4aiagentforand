# S4AGENT - AI Agent Mobile Application

Fully customizable AI agent with built-in file manager, supporting opencode servers, DeepSeek, and local LLMs. No API keys required - works with local/self-hosted models.

## Features

- 🤖 **AI Integration**: Connect to opencode servers, DeepSeek (via Ollama), and custom endpoints
- 📁 **File Manager**: Full CRUD operations, search, zip export/import, download files
- 🎨 **Customizable UI**: Themes, layouts, fonts, colors - fully configurable
- 📦 **APK Building**: EAS Build for cloud builds, local Gradle builds
- 🐙 **GitHub Integration**: Repository management, file uploads, releases
- 🔧 **AI Agent Tools**: File operations, command execution, code generation
- 📱 **Mobile Optimized**: React Native with Expo, works on Android

## Quick Start

### Prerequisites

- Node.js 18+
- Expo CLI (`npm install -g expo-cli`)
- EAS CLI (`npm install -g eas-cli`)
- Android Studio (for local builds)
- Ollama (for local DeepSeek models)

### Installation

```bash
# Clone and install
git clone <your-repo>
cd s4agent
npm install

# Start development server
npm start

# Run on Android
npm run android
```

### Configuration

1. **Ollama Setup** (for DeepSeek models):
   ```bash
   # Install Ollama
   curl -fsSL https://ollama.ai/install.sh | sh
   
   # Pull DeepSeek models
   ollama pull deepseek-coder:6.7b
   ollama pull deepseek-coder:33b
   ollama serve
   ```

2. **Opencode Server** (optional):
   ```bash
   # Install opencode
   npm install -g opencode
   
   # Start server
   opencode serve --port 3000
   ```

3. **App Settings**:
   - Open Settings tab in app
   - Configure API endpoint (default: http://localhost:11434)
   - Select model (deepseek-coder:6.7b recommended)
   - Set project path in Chat or Files tab

## Building APK

### Cloud Build (EAS)
```bash
# Login to Expo
eas login

# Configure project
eas build:configure

# Build preview APK
npm run build:apk

# Build production APK
npm run build:apk:prod
```

### Local Build
```bash
# Prebuild native code
npm run prebuild

# Build and run on device
npm run build:local
```

### APK Output
APKs are available at:
- EAS: Expo dashboard or `eas build:list`
- Local: `android/app/build/outputs/apk/release/app-release.apk`

## Project Structure

```
s4agent/
├── app/                    # Expo Router pages
│   ├── (tabs)/            # Tab navigation screens
│   │   ├── index.tsx      # Chat/Agent interface
│   │   ├── files.tsx      # File manager
│   │   ├── settings.tsx   # Settings & customization
│   │   └── github.tsx     # GitHub integration
│   ├── _layout.tsx        # Root layout
│   └── +not-found.tsx     # 404 handler
├── components/            # Reusable UI components
│   ├── ui/               # Base components
│   ├── file-manager/     # File manager components
│   ├── chat/             # Chat interface components
│   └── theme/            # Theme provider
├── hooks/                # Custom React hooks
├── services/             # Business logic services
│   ├── opencode.ts       # Opencode API client
│   ├── deepseek.ts       # DeepSeek/Ollama client
│   ├── file-system.ts    # File system operations
│   ├── zip.ts            # Zip/Unzip operations
│   ├── github.ts         # GitHub API client
│   └── ai-agent.ts       # AI agent orchestration
├── store/                # Zustand state management
├── utils/                # Utility functions
├── types/                # TypeScript types
├── constants/            # App constants
└── assets/               # Images, fonts, etc.
```

## AI Agent Capabilities

The AI agent can:
- Read, write, edit, delete files
- Create, rename, move folders
- Search files by name or content
- Run shell commands
- Download files from URLs
- Create/extract zip archives
- Upload files to GitHub
- Generate and refactor code

### Tool Definitions

```typescript
// Available tools for AI
- read_file(path, encoding?)
- write_file(path, content, encoding?)
- delete_file(path, recursive?)
- list_directory(path, recursive?)
- create_directory(path)
- move_file(source, destination)
- search_files(query, path, type?, caseSensitive?)
- download_file(url, path)
- zip_files(files[], outputPath, password?)
- unzip_file(zipPath, outputPath, password?)
- run_command(command, cwd?, timeout?)
- github_upload(repo, branch, files[], token)
```

## Customization

### Themes
Configure in Settings > Appearance:
- Light/Dark/System/Custom themes
- Color palette (primary, surface, background, etc.)
- Spacing, typography, border radius
- Shadows and animations

### Layouts
- **IDE**: File tree + editor + chat panels
- **Chat**: Full-screen chat with file access
- **Minimal**: Clean chat interface

### Keyboard Shortcuts
Customize in Settings > Advanced:
- `ctrl+n`: New file
- `ctrl+s`: Save
- `ctrl+o`: Open file
- `ctrl+b`: Toggle sidebar
- `ctrl+l`: AI chat
- `ctrl+enter`: Run code

## GitHub Integration (OAuth)

### Setup GitHub OAuth App

1. Go to [GitHub Developer Settings](https://github.com/settings/developers)
2. Click "New OAuth App"
3. Fill in:
   - **Application name**: S4AGENT
   - **Homepage URL**: `https://github.com/yourusername/s4agent`
   - **Authorization callback URL**: `s4agent://auth`
4. Save and note your **Client ID** and **Client Secret**

### Configure App

1. Update `hooks/useGitHubAuth.ts` with your credentials:
   ```typescript
   const GITHUB_CLIENT_ID = 'your-client-id';
   const GITHUB_CLIENT_SECRET = 'your-client-secret';
   ```

2. In app.json, ensure the scheme matches:
   ```json
   "scheme": "s4agent"
   ```

### Features (with OAuth)

- 🔐 **Secure OAuth login** - No tokens stored in plain text
- 📁 **Repository browser** - View all your repos with details
- 📝 **File management** - Browse, view, upload files
- 🌿 **Branch management** - Create, delete, list branches
- 🔀 **Pull requests** - Create, merge, close PRs
- 🚀 **Releases** - Create releases, upload assets (APKs!)
- ⚡ **Workflows** - Trigger GitHub Actions, view runs
- 🐛 **Issues** - Create and manage issues
- ⭐ **Stars** - Star/unstar repositories
- 🔍 **Search** - Search repos and code

### AI Agent GitHub Tools

The AI can now perform GitHub operations via natural language:

```typescript
// GitHub tools available to AI
- github_list_repos()
- github_get_repo(owner, repo)
- github_create_repo(name, description?, private?)
- github_get_file(owner, repo, path, branch?)
- github_get_directory(owner, repo, path, branch?)
- github_get_repo_tree(owner, repo, branch?, recursive?)
- github_create_file(owner, repo, path, content, message, branch?)
- github_update_file(owner, repo, path, content, message, sha, branch?)
- github_delete_file(owner, repo, path, message, sha, branch?)
- github_upload_files(owner, repo, files[], branch?)
- github_create_branch(owner, repo, branchName, fromBranch?)
- github_delete_branch(owner, repo, branchName)
- github_get_branches(owner, repo)
- github_get_commits(owner, repo, options?)
- github_get_pull_requests(owner, repo, state?)
- github_create_pull_request(owner, repo, title, head, base?, body?, draft?)
- github_merge_pull_request(owner, repo, pullNumber, options?)
- github_close_pull_request(owner, repo, pullNumber)
- github_create_release(owner, repo, tagName, name, body?, draft?, prerelease?, targetCommitish?)
- github_upload_release_asset(owner, repo, releaseId, name, contentType, data)
- github_search_repos(query, options?)
- github_search_code(owner, repo, query)
- github_create_issue(owner, repo, title, body?, assignees?, labels?, milestone?)
- github_get_issues(owner, repo, state?)
- github_get_workflows(owner, repo)
- github_trigger_workflow(owner, repo, workflowId, ref, inputs?)
- github_get_workflow_runs(owner, repo, workflowId?)
- github_get_languages(owner, repo)
- github_get_topics(owner, repo)
- github_update_topics(owner, repo, topics[])
- github_star_repo(owner, repo)
- github_unstar_repo(owner, repo)
- github_get_starred()
```

### Example AI Commands

- "Create a new repo called 'my-project' and push my current files to it"
- "Create a release v1.0.0 with the APK file"
- "Open a PR from feature-branch to main with my changes"
- "Trigger the CI workflow on the main branch"
- "Search for repositories about 'react-native' and star the top 3"

## Security

- No hardcoded API keys
- Local-first architecture
- Optional GitHub token stored securely (expo-secure-store)
- File system sandboxed to selected project directory
- AI actions require confirmation (configurable)

## Troubleshooting

### Common Issues

**Metro bundler issues:**
```bash
npx expo start -c
```

**Native module errors:**
```bash
npm run prebuild
cd android && ./gradlew clean
```

**Ollama connection failed:**
- Ensure Ollama is running: `ollama serve`
- Check endpoint in settings (default: http://localhost:11434)
- For Android emulator, use `http://10.0.2.2:11434`

**File access denied:**
- Grant storage permissions in Android settings
- Use project paths within app's document directory

## License

MIT License - feel free to use and modify.

## Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Submit PR

## Support

- Issues: GitHub Issues
- Discussions: GitHub Discussions
- Documentation: See SPEC.md for full specification