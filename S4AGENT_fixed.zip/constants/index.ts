export const APP_NAME = 'S4AGENT';
export const APP_VERSION = '1.0.0';
export const APP_DESCRIPTION = 'Fully Customizable AI Agent with File Manager';

export const DEFAULT_OPENCODE_URL = 'http://localhost:3000';
export const DEFAULT_OLLAMA_URL = 'http://localhost:11434';
export const DEFAULT_DEEPSEEK_MODELS = [
  'deepseek-coder:6.7b',
  'deepseek-coder:33b',
  'deepseek-chat:7b',
  'deepseek-llm:7b',
  'deepseek-llm:67b',
];

export const DEFAULT_THEME: ThemeConfig = {
  name: 'S4AGENT Dark',
  colors: {
    background: '#0f172a',
    surface: '#1e293b',
    surfaceVariant: '#334155',
    primary: '#0ea5e9',
    primaryVariant: '#0284c7',
    secondary: '#64748b',
    onBackground: '#f8fafc',
    onSurface: '#f1f5f9',
    onPrimary: '#ffffff',
    onSecondary: '#ffffff',
    border: '#334155',
    divider: '#1e293b',
    error: '#ef4444',
    warning: '#f59e0b',
    success: '#22c55e',
    info: '#3b82f6',
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  typography: {
    fontFamily: 'JetBrains Mono',
    fontSize: {
      xs: 11,
      sm: 13,
      md: 15,
      lg: 17,
      xl: 20,
      xxl: 24,
    },
    fontWeight: {
      normal: 400,
      medium: 500,
      bold: 700,
    },
    lineHeight: {
      tight: 1.2,
      normal: 1.5,
      relaxed: 1.8,
    },
  },
  borderRadius: {
    none: 0,
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
    full: 9999,
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
  },
  animations: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
};

export const LIGHT_THEME: ThemeConfig = {
  name: 'S4AGENT Light',
  colors: {
    background: '#ffffff',
    surface: '#f8fafc',
    surfaceVariant: '#f1f5f9',
    primary: '#0284c7',
    primaryVariant: '#0369a1',
    secondary: '#64748b',
    onBackground: '#0f172a',
    onSurface: '#1e293b',
    onPrimary: '#ffffff',
    onSecondary: '#ffffff',
    border: '#e2e8f0',
    divider: '#f1f5f9',
    error: '#dc2626',
    warning: '#d97706',
    success: '#16a34a',
    info: '#2563eb',
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  typography: {
    fontFamily: 'JetBrains Mono',
    fontSize: {
      xs: 11,
      sm: 13,
      md: 15,
      lg: 17,
      xl: 20,
      xxl: 24,
    },
    fontWeight: {
      normal: 400,
      medium: 500,
      bold: 700,
    },
    lineHeight: {
      tight: 1.2,
      normal: 1.5,
      relaxed: 1.8,
    },
  },
  borderRadius: {
    none: 0,
    sm: 4,
    md: 8,
    lg: 12,
    xl: 16,
    full: 9999,
  },
  shadows: {
    sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
  },
  animations: {
    fast: 150,
    normal: 300,
    slow: 500,
  },
};

export const DEFAULT_PREFERENCES: UserPreferences = {
  theme: 'dark',
  layout: 'ide',
  fontSize: 15,
  fontFamily: 'JetBrains Mono',
  sidebarWidth: 280,
  panelHeight: 300,
  showLineNumbers: true,
  wordWrap: true,
  tabSize: 2,
  autoSave: true,
  aiConfirmActions: true,
  aiAutoRunTools: false,
  language: 'en',
  keyboardShortcuts: {
    'new-file': 'ctrl+n',
    'save-file': 'ctrl+s',
    'open-file': 'ctrl+o',
    'toggle-sidebar': 'ctrl+b',
    'toggle-terminal': 'ctrl+`',
    'find': 'ctrl+f',
    'replace': 'ctrl+h',
    'command-palette': 'ctrl+shift+p',
    'ai-chat': 'ctrl+l',
    'run-code': 'ctrl+enter',
  },
};

export const FILE_ICONS: Record<string, string> = {
  folder: 'folder',
  'folder-open': 'folder-open',
  file: 'file',
  js: 'file-code',
  ts: 'file-code',
  tsx: 'file-code',
  jsx: 'file-code',
  json: 'file-json',
  html: 'file-code',
  css: 'file-code',
  scss: 'file-code',
  py: 'file-code',
  rs: 'file-code',
  go: 'file-code',
  java: 'file-code',
  cpp: 'file-code',
  c: 'file-code',
  h: 'file-code',
  md: 'file-text',
  txt: 'file-text',
  yaml: 'file-code',
  yml: 'file-code',
  xml: 'file-code',
  svg: 'image',
  png: 'image',
  jpg: 'image',
  jpeg: 'image',
  gif: 'image',
  webp: 'image',
  ico: 'image',
  pdf: 'file-text',
  zip: 'archive',
  tar: 'archive',
  gz: 'archive',
  rar: 'archive',
  exe: 'file',
  dll: 'file',
  so: 'file',
  dylib: 'file',
  db: 'database',
  sqlite: 'database',
  log: 'file-text',
  env: 'file-text',
  gitignore: 'file-text',
  dockerfile: 'file-code',
  makefile: 'file-code',
  cmake: 'file-code',
  gradle: 'file-code',
  maven: 'file-code',
  npm: 'file-code',
  yarn: 'file-code',
  pnpm: 'file-code',
};

export const MIME_TYPES: Record<string, string> = {
  '.js': 'application/javascript',
  '.ts': 'application/typescript',
  '.tsx': 'application/typescript',
  '.jsx': 'application/javascript',
  '.json': 'application/json',
  '.html': 'text/html',
  '.css': 'text/css',
  '.scss': 'text/css',
  '.py': 'text/x-python',
  '.rs': 'text/rust',
  '.go': 'text/x-go',
  '.java': 'text/x-java',
  '.cpp': 'text/x-c++',
  '.c': 'text/x-c',
  '.h': 'text/x-c',
  '.md': 'text/markdown',
  '.txt': 'text/plain',
  '.yaml': 'application/yaml',
  '.yml': 'application/yaml',
  '.xml': 'application/xml',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
  '.tar': 'application/x-tar',
  '.gz': 'application/gzip',
};

export const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    name: 'read_file',
    description: 'Read the contents of a file',
    parameters: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'The path to the file to read',
        },
        encoding: {
          type: 'string',
          description: 'The encoding to use (utf-8 or base64)',
          enum: ['utf-8', 'base64'],
          default: 'utf-8',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'write_file',
    description: 'Write content to a file',
    parameters: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'The path to the file to write',
        },
        content: {
          type: 'string',
          description: 'The content to write to the file',
        },
        encoding: {
          type: 'string',
          description: 'The encoding to use (utf-8 or base64)',
          enum: ['utf-8', 'base64'],
          default: 'utf-8',
        },
      },
      required: ['path', 'content'],
    },
  },
  {
    name: 'delete_file',
    description: 'Delete a file or folder',
    parameters: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'The path to the file or folder to delete',
        },
        recursive: {
          type: 'boolean',
          description: 'Whether to delete recursively (for folders)',
          default: false,
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'list_directory',
    description: 'List the contents of a directory',
    parameters: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'The path to the directory to list',
        },
        recursive: {
          type: 'boolean',
          description: 'Whether to list recursively',
          default: false,
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'create_directory',
    description: 'Create a new directory',
    parameters: {
      type: 'object',
      properties: {
        path: {
          type: 'string',
          description: 'The path to the directory to create',
        },
      },
      required: ['path'],
    },
  },
  {
    name: 'move_file',
    description: 'Move or rename a file or folder',
    parameters: {
      type: 'object',
      properties: {
        source: {
          type: 'string',
          description: 'The source path',
        },
        destination: {
          type: 'string',
          description: 'The destination path',
        },
      },
      required: ['source', 'destination'],
    },
  },
  {
    name: 'search_files',
    description: 'Search for files by name or content',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'The search query',
        },
        path: {
          type: 'string',
          description: 'The path to search in',
        },
        type: {
          type: 'string',
          description: 'Search type: name, content, or both',
          enum: ['name', 'content', 'both'],
          default: 'both',
        },
        caseSensitive: {
          type: 'boolean',
          description: 'Whether the search is case sensitive',
          default: false,
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'download_file',
    description: 'Download a file from a URL',
    parameters: {
      type: 'object',
      properties: {
        url: {
          type: 'string',
          description: 'The URL to download from',
        },
        path: {
          type: 'string',
          description: 'The local path to save the file',
        },
      },
      required: ['url', 'path'],
    },
  },
  {
    name: 'zip_files',
    description: 'Create a zip archive from files',
    parameters: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: { type: 'string' },
          description: 'Array of file paths to include',
        },
        outputPath: {
          type: 'string',
          description: 'The output path for the zip file',
        },
        password: {
          type: 'string',
          description: 'Optional password for encryption',
        },
      },
      required: ['files', 'outputPath'],
    },
  },
  {
    name: 'unzip_file',
    description: 'Extract a zip archive',
    parameters: {
      type: 'object',
      properties: {
        zipPath: {
          type: 'string',
          description: 'The path to the zip file',
        },
        outputPath: {
          type: 'string',
          description: 'The output directory',
        },
        password: {
          type: 'string',
          description: 'Optional password for decryption',
        },
      },
      required: ['zipPath', 'outputPath'],
    },
  },
  {
    name: 'run_command',
    description: 'Run a shell command',
    parameters: {
      type: 'object',
      properties: {
        command: {
          type: 'string',
          description: 'The command to run',
        },
        cwd: {
          type: 'string',
          description: 'The working directory',
        },
        timeout: {
          type: 'number',
          description: 'Timeout in milliseconds',
          default: 30000,
        },
      },
      required: ['command'],
    },
  },
  {
    name: 'github_upload',
    description: 'Upload files to GitHub',
    parameters: {
      type: 'object',
      properties: {
        repo: {
          type: 'string',
          description: 'Repository in format owner/repo',
        },
        branch: {
          type: 'string',
          description: 'Branch name',
          default: 'main',
        },
        files: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              path: { type: 'string' },
              content: { type: 'string' },
              message: { type: 'string' },
            },
            required: ['path', 'content', 'message'],
          },
          description: 'Files to upload',
        },
        token: {
          type: 'string',
          description: 'GitHub token',
        },
      },
      required: ['repo', 'files', 'token'],
    },
  },
  {
    name: 'github_list_repos',
    description: 'List all GitHub repositories for the authenticated user',
    parameters: {
      type: 'object',
      properties: {
        sort: { type: 'string', description: 'Sort by: updated, created, pushed, full_name', enum: ['updated', 'created', 'pushed', 'full_name'] },
        per_page: { type: 'number', description: 'Results per page', default: 100 },
      },
    },
  },
  {
    name: 'github_get_repo',
    description: 'Get details of a specific repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_create_repo',
    description: 'Create a new GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'Repository name' },
        description: { type: 'string', description: 'Repository description' },
        private: { type: 'boolean', description: 'Make repository private', default: false },
      },
      required: ['name'],
    },
  },
  {
    name: 'github_get_file',
    description: 'Get contents of a file from GitHub',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path' },
        branch: { type: 'string', description: 'Branch name' },
      },
      required: ['owner', 'repo', 'path'],
    },
  },
  {
    name: 'github_get_directory',
    description: 'List contents of a directory in GitHub',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'Directory path' },
        branch: { type: 'string', description: 'Branch name' },
      },
      required: ['owner', 'repo', 'path'],
    },
  },
  {
    name: 'github_get_repo_tree',
    description: 'Get the full file tree of a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        branch: { type: 'string', description: 'Branch name', default: 'main' },
        recursive: { type: 'boolean', description: 'Get recursive tree', default: true },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_create_file',
    description: 'Create a new file in GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path' },
        content: { type: 'string', description: 'File content' },
        message: { type: 'string', description: 'Commit message' },
        branch: { type: 'string', description: 'Branch name' },
      },
      required: ['owner', 'repo', 'path', 'content', 'message'],
    },
  },
  {
    name: 'github_update_file',
    description: 'Update an existing file in GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path' },
        content: { type: 'string', description: 'New file content' },
        message: { type: 'string', description: 'Commit message' },
        sha: { type: 'string', description: 'Current file SHA' },
        branch: { type: 'string', description: 'Branch name' },
      },
      required: ['owner', 'repo', 'path', 'content', 'message', 'sha'],
    },
  },
  {
    name: 'github_delete_file',
    description: 'Delete a file from GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        path: { type: 'string', description: 'File path' },
        message: { type: 'string', description: 'Commit message' },
        sha: { type: 'string', description: 'Current file SHA' },
        branch: { type: 'string', description: 'Branch name' },
      },
      required: ['owner', 'repo', 'path', 'message', 'sha'],
    },
  },
  {
    name: 'github_upload_files',
    description: 'Upload multiple files to GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        files: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              path: { type: 'string' },
              content: { type: 'string' },
              message: { type: 'string' },
            },
            required: ['path', 'content', 'message'],
          },
        },
        branch: { type: 'string', description: 'Branch name', default: 'main' },
      },
      required: ['owner', 'repo', 'files'],
    },
  },
  {
    name: 'github_create_branch',
    description: 'Create a new branch in GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        branchName: { type: 'string', description: 'New branch name' },
        fromBranch: { type: 'string', description: 'Source branch', default: 'main' },
      },
      required: ['owner', 'repo', 'branchName'],
    },
  },
  {
    name: 'github_delete_branch',
    description: 'Delete a branch from GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        branchName: { type: 'string', description: 'Branch name to delete' },
      },
      required: ['owner', 'repo', 'branchName'],
    },
  },
  {
    name: 'github_get_branches',
    description: 'List all branches in a GitHub repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_commits',
    description: 'Get commit history of a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        sha: { type: 'string', description: 'SHA or branch to start from' },
        path: { type: 'string', description: 'Filter by file path' },
        per_page: { type: 'number', description: 'Results per page', default: 30 },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_pull_requests',
    description: 'List pull requests in a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        state: { type: 'string', description: 'PR state', enum: ['open', 'closed', 'all'], default: 'open' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_create_pull_request',
    description: 'Create a new pull request',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        title: { type: 'string', description: 'PR title' },
        head: { type: 'string', description: 'Head branch (your changes)' },
        base: { type: 'string', description: 'Base branch (target)', default: 'main' },
        body: { type: 'string', description: 'PR description' },
        draft: { type: 'boolean', description: 'Create as draft', default: false },
      },
      required: ['owner', 'repo', 'title', 'head'],
    },
  },
  {
    name: 'github_merge_pull_request',
    description: 'Merge a pull request',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        pullNumber: { type: 'number', description: 'Pull request number' },
        commitTitle: { type: 'string', description: 'Merge commit title' },
        commitMessage: { type: 'string', description: 'Merge commit message' },
        sha: { type: 'string', description: 'Expected head SHA' },
        mergeMethod: { type: 'string', description: 'Merge method', enum: ['merge', 'squash', 'rebase'], default: 'merge' },
      },
      required: ['owner', 'repo', 'pullNumber'],
    },
  },
  {
    name: 'github_close_pull_request',
    description: 'Close a pull request without merging',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        pullNumber: { type: 'number', description: 'Pull request number' },
      },
      required: ['owner', 'repo', 'pullNumber'],
    },
  },
  {
    name: 'github_create_release',
    description: 'Create a new release',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        tagName: { type: 'string', description: 'Tag name (e.g., v1.0.0)' },
        name: { type: 'string', description: 'Release name' },
        body: { type: 'string', description: 'Release notes' },
        draft: { type: 'boolean', description: 'Create as draft', default: false },
        prerelease: { type: 'boolean', description: 'Mark as prerelease', default: false },
        targetCommitish: { type: 'string', description: 'Target branch/commit', default: 'main' },
      },
      required: ['owner', 'repo', 'tagName', 'name'],
    },
  },
  {
    name: 'github_upload_release_asset',
    description: 'Upload an asset to a release',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        releaseId: { type: 'number', description: 'Release ID' },
        name: { type: 'string', description: 'Asset filename' },
        contentType: { type: 'string', description: 'MIME type' },
        data: { type: 'string', description: 'Base64 encoded file data' },
      },
      required: ['owner', 'repo', 'releaseId', 'name', 'contentType', 'data'],
    },
  },
  {
    name: 'github_search_repos',
    description: 'Search GitHub repositories',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search query' },
        sort: { type: 'string', description: 'Sort by', enum: ['stars', 'forks', 'updated'], default: 'stars' },
        order: { type: 'string', description: 'Order', enum: ['asc', 'desc'], default: 'desc' },
        per_page: { type: 'number', description: 'Results per page', default: 30 },
      },
      required: ['query'],
    },
  },
  {
    name: 'github_search_code',
    description: 'Search code in a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        query: { type: 'string', description: 'Search query' },
      },
      required: ['owner', 'repo', 'query'],
    },
  },
  {
    name: 'github_create_issue',
    description: 'Create a new issue',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        title: { type: 'string', description: 'Issue title' },
        body: { type: 'string', description: 'Issue body' },
        assignees: { type: 'array', items: { type: 'string' }, description: 'Assignees' },
        labels: { type: 'array', items: { type: 'string' }, description: 'Labels' },
        milestone: { type: 'number', description: 'Milestone number' },
      },
      required: ['owner', 'repo', 'title'],
    },
  },
  {
    name: 'github_get_issues',
    description: 'List issues in a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        state: { type: 'string', description: 'Issue state', enum: ['open', 'closed', 'all'], default: 'open' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_workflows',
    description: 'List GitHub Actions workflows',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_trigger_workflow',
    description: 'Trigger a GitHub Actions workflow',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        workflowId: { type: 'string', description: 'Workflow ID or filename' },
        ref: { type: 'string', description: 'Branch/tag to run on' },
        inputs: { type: 'object', description: 'Workflow inputs' },
      },
      required: ['owner', 'repo', 'workflowId', 'ref'],
    },
  },
  {
    name: 'github_get_workflow_runs',
    description: 'Get workflow run history',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        workflowId: { type: 'string', description: 'Specific workflow ID' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_languages',
    description: 'Get repository languages',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_topics',
    description: 'Get repository topics',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_update_topics',
    description: 'Update repository topics',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
        topics: { type: 'array', items: { type: 'string' }, description: 'Topics list' },
      },
      required: ['owner', 'repo', 'topics'],
    },
  },
  {
    name: 'github_star_repo',
    description: 'Star a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_unstar_repo',
    description: 'Unstar a repository',
    parameters: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'Repository owner' },
        repo: { type: 'string', description: 'Repository name' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'github_get_starred',
    description: 'Get starred repositories',
    parameters: {
      type: 'object',
      properties: {},
    },
  },
];

export const SYSTEM_PROMPTS = {
  default: `You are S4AGENT, a powerful AI coding assistant with full access to the file system. You can read, write, edit, delete, move, and search files. You can also run commands, download files, create zip archives, and upload to GitHub.

Always confirm destructive actions (delete, overwrite) with the user before executing.
Use tools efficiently - batch operations when possible.
Provide clear explanations of what you're doing.
Ask for clarification if the request is ambiguous.`,
  coding: `You are an expert software engineer. Write clean, efficient, well-documented code.
Follow best practices and design patterns.
Consider error handling, testing, and maintainability.
Use the project's existing conventions and style.`,
  file_manager: `You are a file management assistant. Help users organize, find, and manipulate files.
Use the file system tools to perform operations.
Confirm before deleting or overwriting files.`,
  github: `You are a GitHub integration assistant. Help users manage repositories, create commits, push changes, and manage releases.
Always confirm before pushing changes to remote repositories.`,
};

export const STORAGE_KEYS = {
  PREFERENCES: 's4agent_preferences',
  PROJECTS: 's4agent_projects',
  CHAT_HISTORY: 's4agent_chat_history',
  AGENT_CONFIG: 's4agent_agent_config',
  GITHUB_TOKEN: 's4agent_github_token',
  THEME: 's4agent_theme',
  RECENT_FILES: 's4agent_recent_files',
  FILE_BOOKMARKS: 's4agent_file_bookmarks',
};

export const EVENT_NAMES = {
  FILE_CHANGED: 'file_changed',
  FILE_CREATED: 'file_created',
  FILE_DELETED: 'file_deleted',
  FILE_MOVED: 'file_moved',
  FOLDER_EXPANDED: 'folder_expanded',
  FOLDER_COLLAPSED: 'folder_collapsed',
  SELECTION_CHANGED: 'selection_changed',
  THEME_CHANGED: 'theme_changed',
  PREFERENCES_CHANGED: 'preferences_changed',
  CONNECTION_STATUS_CHANGED: 'connection_status_changed',
  AI_MESSAGE_RECEIVED: 'ai_message_received',
  AI_TOOL_CALL: 'ai_tool_call',
  AI_TOOL_RESULT: 'ai_tool_result',
  BUILD_STARTED: 'build_started',
  BUILD_COMPLETED: 'build_completed',
  BUILD_FAILED: 'build_failed',
};