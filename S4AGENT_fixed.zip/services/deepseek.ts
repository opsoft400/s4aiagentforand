import axios, { AxiosInstance } from 'axios';
import type { DeepSeekModel, AIMessage, ToolDefinition, ToolCall } from '@/types';

interface OllamaConfig {
  baseUrl: string;
}

interface OllamaGenerateRequest {
  model: string;
  prompt: string;
  system?: string;
  template?: string;
  context?: number[];
  stream?: boolean;
  raw?: boolean;
  format?: 'json' | '';
  options?: OllamaOptions;
  keep_alive?: string | number;
}

interface OllamaOptions {
  temperature?: number;
  top_p?: number;
  top_k?: number;
  num_predict?: number;
  stop?: string[];
  num_ctx?: number;
  repeat_penalty?: number;
  seed?: number;
}

interface OllamaChatRequest {
  model: string;
  messages: OllamaMessage[];
  format?: 'json' | '';
  options?: OllamaOptions;
  stream?: boolean;
  keep_alive?: string | number;
}

interface OllamaMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
}

interface OllamaResponse {
  model: string;
  created_at: string;
  response: string;
  done: boolean;
  context?: number[];
  total_duration?: number;
  load_duration?: number;
  prompt_eval_count?: number;
  eval_count?: number;
  eval_duration?: number;
}

interface OllamaChatResponse {
  model: string;
  created_at: string;
  message: OllamaMessage;
  done: boolean;
  total_duration?: number;
  load_duration?: number;
  prompt_eval_count?: number;
  eval_count?: number;
  eval_duration?: number;
}

interface OllamaModelsResponse {
  models: OllamaModel[];
}

interface OllamaModel {
  name: string;
  modified_at: string;
  size: number;
  digest: string;
  details: {
    parent_model: string;
    format: string;
    family: string;
    families: string[];
    parameter_size: string;
    quantization_level: string;
  };
}

export class DeepSeekService {
  private client: AxiosInstance;
  private availableModels: DeepSeekModel[] = [];

  constructor(config: OllamaConfig) {
    this.client = axios.create({
      baseURL: config.baseUrl,
      timeout: 120000,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  async checkConnection(): Promise<boolean> {
    try {
      await this.client.get('/api/tags');
      return true;
    } catch {
      return false;
    }
  }

  async listModels(): Promise<DeepSeekModel[]> {
    try {
      const response = await this.client.get<OllamaModelsResponse>('/api/tags');
      this.availableModels = (response.data.models || []).map((model) => ({
        id: model.name,
        name: model.name,
        size: this.formatBytes(model.size),
        parameters: model.details.parameter_size,
        quantization: model.details.quantization_level,
      }));
      return this.availableModels;
    } catch (error) {
      console.error('Failed to list models:', error);
      return [];
    }
  }

  async pullModel(modelName: string, onProgress?: (progress: number) => void): Promise<void> {
    try {
      const response = await this.client.post<string>('/api/pull', { name: modelName, stream: true }, {
        responseType: 'text',
      });
      for (const line of String(response.data || '').split(/\r?\n/)) {
        if (!line.trim()) continue;
        try {
          const data = JSON.parse(line);
          if (data.completed && data.total) onProgress?.((data.completed / data.total) * 100);
          if (data.error) throw new Error(data.error);
        } catch (error) {
          if (error instanceof Error && error.message !== 'Unexpected end of JSON input') {
            // Ignore malformed NDJSON lines, but surface explicit server errors.
            if (/error/i.test(error.message)) throw error;
          }
        }
      }
    } catch (error) {
      console.error('Failed to pull model:', error);
      throw error;
    }
  }

  async deleteModel(modelName: string): Promise<void> {
    await this.client.delete('/api/delete', { data: { name: modelName } });
  }

  async generate(request: OllamaGenerateRequest): Promise<string> {
    const response = await this.client.post<OllamaResponse>('/api/generate', {
      ...request,
      stream: false,
    });
    return response.data.response;
  }

  async chat(request: OllamaChatRequest): Promise<OllamaMessage> {
    const response = await this.client.post<OllamaChatResponse>('/api/chat', {
      ...request,
      stream: false,
    });
    return response.data.message;
  }

  async *streamChat(request: OllamaChatRequest): AsyncGenerator<OllamaMessage, void, unknown> {
    const response = await this.client.post<string>('/api/chat', {
      ...request,
      stream: true,
    }, {
      responseType: 'text',
    });

    for (const line of String(response.data || '').split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const data: OllamaChatResponse = JSON.parse(line);
        if (data.message) yield data.message;
        if (data.done) return;
      } catch {
        // Ignore malformed/partial NDJSON records.
      }
    }
  }

  async *streamGenerate(request: OllamaGenerateRequest): AsyncGenerator<string, void, unknown> {
    const response = await this.client.post<string>('/api/generate', {
      ...request,
      stream: true,
    }, {
      responseType: 'text',
    });

    for (const line of String(response.data || '').split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const data: OllamaResponse = JSON.parse(line);
        if (data.response) yield data.response;
        if (data.done) return;
      } catch {
        // Ignore malformed/partial NDJSON records.
      }
    }
  }

  getAvailableModels(): DeepSeekModel[] {
    return this.availableModels;
  }

  convertToOllamaMessages(messages: AIMessage[]): OllamaMessage[] {
    return messages.map((msg) => ({
      role: msg.role,
      content: msg.content,
      tool_calls: msg.toolCalls,
      tool_call_id: msg.toolCallId,
    }));
  }

  convertToolsToOllamaFormat(tools: ToolDefinition[]): any[] {
    return tools.map((tool) => ({
      type: 'function',
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));
  }

  private formatBytes(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

export const createDeepSeekService = (baseUrl: string): DeepSeekService => {
  return new DeepSeekService({ baseUrl });
};

export default DeepSeekService;