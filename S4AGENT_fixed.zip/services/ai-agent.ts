import { v4 as uuidv4 } from 'uuid';
import type { AIMessage, ToolCall, ToolDefinition, AgentConfig, FileNode, GitHubRepo, GitHubFile } from '@/types';
import { fileSystemService } from './file-system';
import { DeepSeekService } from './deepseek';
import { OpencodeService } from './opencode';
import { GitHubService, createGitHubService } from './github';

interface ToolResult {
  toolCallId: string;
  name: string;
  result: any;
  error?: string;
}

export class AIAgentService {
  private deepseekService: DeepSeekService | null = null;
  private opencodeService: OpencodeService | null = null;
  private githubService: GitHubService | null = null;
  private config: AgentConfig;
  private onToolCall?: (toolCall: ToolCall) => void;
  private onToolResult?: (result: ToolResult) => void;
  private onMessage?: (message: AIMessage) => void;
  private abortController: AbortController | null = null;

  constructor(config: AgentConfig) {
    this.config = config;
    this.initializeServices();
  }

  private initializeServices(): void {
    switch (this.config.apiProvider) {
      case 'ollama':
      case 'deepseek':
        this.deepseekService = new DeepSeekService({ baseUrl: this.config.apiEndpoint });
        break;
      case 'opencode':
        this.opencodeService = new OpencodeService({ 
          baseUrl: this.config.apiEndpoint,
          apiKey: this.config.apiKey,
        });
        break;
      case 'custom':
        this.deepseekService = new DeepSeekService({ baseUrl: this.config.apiEndpoint });
        break;
    }

    // GitHub service will be initialized when token is available
  }

  setGitHubToken(token: string | null): void {
    if (token) {
      this.githubService = createGitHubService(token);
    } else {
      this.githubService = null;
    }
  }

  setConfig(config: Partial<AgentConfig>): void {
    this.config = { ...this.config, ...config };
    this.initializeServices();
  }

  setCallbacks(callbacks: {
    onToolCall?: (toolCall: ToolCall) => void;
    onToolResult?: (result: ToolResult) => void;
    onMessage?: (message: AIMessage) => void;
  }): void {
    this.onToolCall = callbacks.onToolCall;
    this.onToolResult = callbacks.onToolResult;
    this.onMessage = callbacks.onMessage;
  }

  async checkConnection(): Promise<boolean> {
    if (this.deepseekService) {
      return this.deepseekService.checkConnection();
    }
    if (this.opencodeService) {
      return this.opencodeService.checkConnection();
    }
    return false;
  }

  async sendMessage(
    messages: AIMessage[],
    tools: ToolDefinition[] = this.config.tools
  ): Promise<AIMessage> {
    this.abortController = new AbortController();
    
    const systemMessage: AIMessage = {
      id: uuidv4(),
      role: 'system',
      content: this.config.systemPrompt,
      timestamp: new Date(),
    };

    const allMessages = [systemMessage, ...messages];

    if (this.config.apiProvider === 'opencode' && this.opencodeService) {
      return this.sendToOpencode(allMessages, tools);
    }

    return this.sendToDeepSeek(allMessages, tools);
  }

  private async sendToDeepSeek(
    messages: AIMessage[],
    tools: ToolDefinition[]
  ): Promise<AIMessage> {
    if (!this.deepseekService) {
      throw new Error('DeepSeek service not initialized');
    }

    const ollamaMessages = this.deepseekService.convertToOllamaMessages(messages);
    const ollamaTools = this.deepseekService.convertToolsToOllamaFormat(tools);

    let fullResponse = '';
    let toolCalls: ToolCall[] = [];

    for await (const chunk of this.deepseekService.streamChat({
      model: this.config.model,
      messages: ollamaMessages,
      options: {
        temperature: this.config.temperature,
        num_predict: this.config.maxTokens,
      },
      tools: ollamaTools,
    })) {
      if (chunk.content) {
        fullResponse += chunk.content;
        this.onMessage?.({
          id: uuidv4(),
          role: 'assistant',
          content: fullResponse,
          timestamp: new Date(),
        });
      }

      if (chunk.tool_calls) {
        toolCalls = chunk.tool_calls;
      }
    }

    const assistantMessage: AIMessage = {
      id: uuidv4(),
      role: 'assistant',
      content: fullResponse,
      timestamp: new Date(),
      toolCalls: toolCalls.length > 0 ? toolCalls : undefined,
    };

    if (toolCalls.length > 0) {
      const toolResults = await this.executeToolCalls(toolCalls);
      
      const followUpMessages = [
        ...messages,
        assistantMessage,
        ...toolResults.map((result) => ({
          id: uuidv4(),
          role: 'tool' as const,
          content: JSON.stringify(result.result),
          timestamp: new Date(),
          toolCallId: result.toolCallId,
        })),
      ];

      return this.sendToDeepSeek(followUpMessages, tools);
    }

    return assistantMessage;
  }

  private async sendToOpencode(
    messages: AIMessage[],
    tools: ToolDefinition[]
  ): Promise<AIMessage> {
    if (!this.opencodeService) {
      throw new Error('Opencode service not initialized');
    }

    const lastUserMessage = messages.filter(m => m.role === 'user').pop();
    if (!lastUserMessage) {
      throw new Error('No user message found');
    }

    const response = await this.opencodeService.sendMessage({
      sessionId: 'current',
      content: lastUserMessage.content,
      toolCalls: lastUserMessage.toolCalls,
    });

    return response;
  }

  private async executeToolCalls(toolCalls: ToolCall[]): Promise<ToolResult[]> {
    const results: ToolResult[] = [];

    for (const toolCall of toolCalls) {
      this.onToolCall?.(toolCall);

      try {
        const args = JSON.parse(toolCall.function.arguments);
        const result = await this.executeTool(toolCall.function.name, args);
        
        const toolResult: ToolResult = {
          toolCallId: toolCall.id,
          name: toolCall.function.name,
          result,
        };
        
        results.push(toolResult);
        this.onToolResult?.(toolResult);
      } catch (error) {
        const toolResult: ToolResult = {
          toolCallId: toolCall.id,
          name: toolCall.function.name,
          result: null,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
        
        results.push(toolResult);
        this.onToolResult?.(toolResult);
      }
    }

    return results;
  }

  private async executeTool(name: string, args: Record<string, any>): Promise<any> {
    // File system tools
    switch (name) {
      case 'read_file':
        return fileSystemService.readFile(args.path, args.encoding);
      
      case 'write_file':
        await fileSystemService.writeFile(args.path, args.content, args.encoding);
        return { success: true, path: args.path };
      
      case 'delete_file':
        await fileSystemService.deleteFile(args.path, args.recursive);
        return { success: true, path: args.path };
      
      case 'list_directory':
        return fileSystemService.listDirectory(args.path, args.recursive);
      
      case 'create_directory':
        await fileSystemService.createDirectory(args.path);
        return { success: true, path: args.path };
      
      case 'move_file':
        await fileSystemService.moveFile(args.source, args.destination);
        return { success: true, source: args.source, destination: args.destination };
      
      case 'search_files':
        return fileSystemService.searchFiles(args.query, args.path, args.type, args.caseSensitive);
      
      case 'download_file':
        await fileSystemService.downloadFile(args.url, args.path);
        return { success: true, path: args.path };
      
      case 'zip_files':
        return fileSystemService.zipFiles(args.files, args.outputPath, { password: args.password });
      
      case 'unzip_file':
        return fileSystemService.unzipFile(args.zipPath, args.outputPath, args.password);
      
      case 'run_command':
        return fileSystemService.runCommand(args.command, args.cwd);
    }

    // GitHub tools
    if (!this.githubService) {
      throw new Error('GitHub not authenticated. Please connect your GitHub account first.');
    }

    switch (name) {
      case 'github_list_repos':
        return this.githubService.getRepos();
      
      case 'github_get_repo':
        return this.githubService.getRepo(args.owner, args.repo);
      
      case 'github_create_repo':
        return this.githubService.createRepo({
          name: args.name,
          description: args.description,
          private: args.private ?? false,
        });
      
      case 'github_get_file':
        return this.githubService.getFile(args.owner, args.repo, args.path, args.branch);
      
      case 'github_get_directory':
        return this.githubService.getDirectory(args.owner, args.repo, args.path, args.branch);
      
      case 'github_get_repo_tree':
        return this.githubService.getRepoTree(args.owner, args.repo, args.branch, args.recursive);
      
      case 'github_create_file':
        return this.githubService.createFile(args.owner, args.repo, {
          path: args.path,
          content: args.content,
          message: args.message,
          branch: args.branch,
        });
      
      case 'github_update_file':
        return this.githubService.updateFile(args.owner, args.repo, {
          path: args.path,
          content: args.content,
          message: args.message,
          sha: args.sha,
          branch: args.branch,
        });
      
      case 'github_delete_file':
        await this.githubService.deleteFile(args.owner, args.repo, args.path, args.message, args.sha, args.branch);
        return { success: true };
      
      case 'github_upload_files':
        await this.githubService.uploadFiles(args.owner, args.repo, args.files, args.branch);
        return { success: true };
      
      case 'github_create_branch':
        return this.githubService.createBranch(args.owner, args.repo, args.branchName, args.fromBranch);
      
      case 'github_delete_branch':
        await this.githubService.deleteBranch(args.owner, args.repo, args.branchName);
        return { success: true };
      
      case 'github_get_branches':
        return this.githubService.getBranches(args.owner, args.repo);
      
      case 'github_get_commits':
        return this.githubService.getCommits(args.owner, args.repo, args);
      
      case 'github_get_pull_requests':
        return this.githubService.getPullRequests(args.owner, args.repo, args.state);
      
      case 'github_create_pull_request':
        return this.githubService.createPullRequest(args.owner, args.repo, {
          title: args.title,
          head: args.head,
          base: args.base,
          body: args.body,
          draft: args.draft,
        });
      
      case 'github_merge_pull_request':
        return this.githubService.mergePullRequest(args.owner, args.repo, args.pullNumber, {
          commit_title: args.commitTitle,
          commit_message: args.commitMessage,
          sha: args.sha,
          merge_method: args.mergeMethod,
        });
      
      case 'github_close_pull_request':
        return this.githubService.closePullRequest(args.owner, args.repo, args.pullNumber);
      
      case 'github_create_release':
        return this.githubService.createRelease(args.owner, args.repo, {
          tag_name: args.tagName,
          name: args.name,
          body: args.body,
          draft: args.draft,
          prerelease: args.prerelease,
          target_commitish: args.targetCommitish,
        });
      
      case 'github_upload_release_asset':
        return this.githubService.uploadReleaseAsset(args.owner, args.repo, args.releaseId, {
          name: args.name,
          contentType: args.contentType,
          data: args.data,
        });
      
      case 'github_search_repos':
        return this.githubService.searchRepos(args.query, args);
      
      case 'github_search_code':
        return this.githubService.searchCode(args.owner, args.repo, args.query);
      
      case 'github_create_issue':
        return this.githubService.createIssue(args.owner, args.repo, {
          title: args.title,
          body: args.body,
          assignees: args.assignees,
          labels: args.labels,
          milestone: args.milestone,
        });
      
      case 'github_get_issues':
        return this.githubService.getIssues(args.owner, args.repo, args.state);
      
      case 'github_get_workflows':
        return this.githubService.getWorkflows(args.owner, args.repo);
      
      case 'github_trigger_workflow':
        return this.githubService.triggerWorkflow(args.owner, args.repo, args.workflowId, args.ref, args.inputs);
      
      case 'github_get_workflow_runs':
        return this.githubService.getWorkflowRuns(args.owner, args.repo, args.workflowId);
      
      case 'github_get_languages':
        return this.githubService.getRepoLanguages(args.owner, args.repo);
      
      case 'github_get_topics':
        return this.githubService.getRepoTopics(args.owner, args.repo);
      
      case 'github_update_topics':
        await this.githubService.updateRepoTopics(args.owner, args.repo, args.topics);
        return { success: true };
      
      case 'github_star_repo':
        await this.githubService.starRepo(args.owner, args.repo);
        return { success: true };
      
      case 'github_unstar_repo':
        await this.githubService.unstarRepo(args.owner, args.repo);
        return { success: true };
      
      case 'github_get_starred':
        return this.githubService.getStarredRepos();
      
      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  }

  abort(): void {
    this.abortController?.abort();
  }

  getConfig(): AgentConfig {
    return { ...this.config };
  }
}

export const createAIAgent = (config: AgentConfig): AIAgentService => {
  return new AIAgentService(config);
};

export default AIAgentService;