import axios, { AxiosInstance } from 'axios';
import type { OpencodeSession, OpencodeAgent, AIMessage, ToolCall } from '@/types';

interface OpencodeConfig {
  baseUrl: string;
  apiKey?: string;
}

interface CreateSessionRequest {
  name: string;
  projectPath: string;
  agentId?: string;
}

interface SendMessageRequest {
  sessionId: string;
  content: string;
  toolCalls?: ToolCall[];
}

interface OpencodeResponse<T> {
  data: T;
  error?: string;
}

export class OpencodeService {
  private client: AxiosInstance;
  private ws: WebSocket | null = null;
  private messageHandlers: Map<string, (data: any) => void> = new Map();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;

  constructor(config: OpencodeConfig) {
    this.client = axios.create({
      baseURL: config.baseUrl,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
        ...(config.apiKey && { Authorization: `Bearer ${config.apiKey}` }),
      },
    });

    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        console.error('Opencode API error:', error.response?.data || error.message);
        return Promise.reject(error);
      }
    );
  }

  async checkConnection(): Promise<boolean> {
    try {
      await this.client.get('/health');
      return true;
    } catch {
      return false;
    }
  }

  async getSessions(): Promise<OpencodeSession[]> {
    const response = await this.client.get<OpencodeResponse<OpencodeSession[]>>('/sessions');
    return response.data.data || [];
  }

  async createSession(request: CreateSessionRequest): Promise<OpencodeSession> {
    const response = await this.client.post<OpencodeResponse<OpencodeSession>>('/sessions', request);
    return response.data.data!;
  }

  async getSession(sessionId: string): Promise<OpencodeSession> {
    const response = await this.client.get<OpencodeResponse<OpencodeSession>>(`/sessions/${sessionId}`);
    return response.data.data!;
  }

  async deleteSession(sessionId: string): Promise<void> {
    await this.client.delete(`/sessions/${sessionId}`);
  }

  async getAgents(): Promise<OpencodeAgent[]> {
    const response = await this.client.get<OpencodeResponse<OpencodeAgent[]>>('/agents');
    return response.data.data || [];
  }

  async sendMessage(request: SendMessageRequest): Promise<AIMessage> {
    const response = await this.client.post<OpencodeResponse<AIMessage>>(
      `/sessions/${request.sessionId}/messages`,
      { content: request.content, toolCalls: request.toolCalls }
    );
    return response.data.data!;
  }

  async getMessages(sessionId: string): Promise<AIMessage[]> {
    const response = await this.client.get<OpencodeResponse<AIMessage[]>>(`/sessions/${sessionId}/messages`);
    return response.data.data || [];
  }

  connectWebSocket(sessionId: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const wsUrl = this.client.defaults.baseURL!.replace('http', 'ws') + `/sessions/${sessionId}/ws`;
      
      try {
        this.ws = new WebSocket(wsUrl);
        
        this.ws.onopen = () => {
          console.log('Opencode WebSocket connected');
          this.reconnectAttempts = 0;
          resolve();
        };
        
        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            this.handleWebSocketMessage(data);
          } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
          }
        };
        
        this.ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          if (this.reconnectAttempts === 0) {
            reject(error);
          }
        };
        
        this.ws.onclose = () => {
          console.log('WebSocket closed, attempting reconnect...');
          this.attemptReconnect(sessionId);
        };
      } catch (error) {
        reject(error);
      }
    });
  }

  private attemptReconnect(sessionId: string): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('Max reconnect attempts reached');
      return;
    }
    
    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
    
    setTimeout(() => {
      this.connectWebSocket(sessionId).catch(() => {
        this.attemptReconnect(sessionId);
      });
    }, delay);
  }

  private handleWebSocketMessage(data: any): void {
    const handler = this.messageHandlers.get(data.type);
    if (handler) {
      handler(data);
    }
  }

  onMessage(type: string, handler: (data: any) => void): void {
    this.messageHandlers.set(type, handler);
  }

  offMessage(type: string): void {
    this.messageHandlers.delete(type);
  }

  sendWebSocketMessage(message: any): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.messageHandlers.clear();
  }

  async runTool(sessionId: string, toolName: string, args: Record<string, any>): Promise<any> {
    const response = await this.client.post<OpencodeResponse<any>>(
      `/sessions/${sessionId}/tools/${toolName}`,
      args
    );
    return response.data.data;
  }

  async getProjectFiles(sessionId: string): Promise<any[]> {
    const response = await this.client.get<OpencodeResponse<any[]>>(`/sessions/${sessionId}/files`);
    return response.data.data || [];
  }

  async readProjectFile(sessionId: string, path: string): Promise<string> {
    const response = await this.client.get<OpencodeResponse<{ content: string }>>(
      `/sessions/${sessionId}/files/${encodeURIComponent(path)}`
    );
    return response.data.data?.content || '';
  }

  async writeProjectFile(sessionId: string, path: string, content: string): Promise<void> {
    await this.client.put(
      `/sessions/${sessionId}/files/${encodeURIComponent(path)}`,
      { content }
    );
  }
}

export const createOpencodeService = (baseUrl: string, apiKey?: string): OpencodeService => {
  return new OpencodeService({ baseUrl, apiKey });
};

export default OpencodeService;