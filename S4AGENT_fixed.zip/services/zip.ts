import * as FileSystem from 'expo-file-system';
import { encode as btoa, decode as atob } from 'base-64';
import JSZip from 'jszip';
import type { ZipOptions, ZipResult } from '@/types';

export class ZipService {
  async createZip(files: Array<{ path: string; name?: string; content?: string; base64?: boolean }>, options: ZipOptions = {}): Promise<ZipResult> {
    try {
      const zip = new JSZip();
      
      for (const file of files) {
        const fileName = file.name || file.path.split('/').pop() || 'file';
        
        if (file.content !== undefined) {
          if (file.base64) {
            zip.file(fileName, file.content, { base64: true });
          } else {
            zip.file(fileName, file.content);
          }
        } else {
          const fullPath = file.path.startsWith('file://') ? file.path : `file://${file.path}`;
          const info = await FileSystem.getInfoAsync(fullPath);
          
          if (!info.exists) {
            return { success: false, error: `File not found: ${file.path}` };
          }
          
          if (info.isDirectory) {
            await this.addDirectoryToZip(zip, fullPath, fileName);
          } else {
            const content = await FileSystem.readAsStringAsync(fullPath, { encoding: 'base64' });
            zip.file(fileName, content, { base64: true });
          }
        }
      }
      
      const content = await zip.generateAsync({
        type: 'base64',
        compression: 'DEFLATE',
        compressionOptions: {
          level: options.compressionLevel || 6,
        },
      });
      
      return { success: true, content, size: content.length };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  private async addDirectoryToZip(zip: JSZip, fullPath: string, relativePath: string): Promise<void> {
    const items = await FileSystem.readDirectoryAsync(fullPath);
    
    for (const item of items) {
      const itemFullPath = `${fullPath}/${item}`;
      const itemRelativePath = `${relativePath}/${item}`;
      const info = await FileSystem.getInfoAsync(itemFullPath);
      
      if (info.isDirectory) {
        await this.addDirectoryToZip(zip, itemFullPath, itemRelativePath);
      } else {
        const content = await FileSystem.readAsStringAsync(itemFullPath, { encoding: 'base64' });
        zip.file(itemRelativePath, content, { base64: true });
      }
    }
  }

  async extractZip(zipBase64: string, outputPath: string, options: ZipOptions = {}): Promise<ZipResult> {
    try {
      const zip = await JSZip.loadAsync(zipBase64, { base64: true });
      
      await FileSystem.makeDirectoryAsync(outputPath, { intermediates: true });
      
      const extractPromises: Promise<void>[] = [];
      
      for (const [name, file] of Object.entries(zip.files)) {
        if (!file.dir) {
          extractPromises.push(
            (async () => {
              const content = await file.async('base64');
              const safeName = this.sanitizeEntryName(name);
              if (!safeName) throw new Error(`Unsafe ZIP entry rejected: ${name}`);
              const filePath = `${outputPath}/${safeName}`;
              const dir = filePath.substring(0, filePath.lastIndexOf('/'));
              if (dir) await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
              await FileSystem.writeAsStringAsync(filePath, content, { encoding: 'base64' });
            })()
          );
        }
      }
      
      await Promise.all(extractPromises);
      
      return { success: true, path: outputPath };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  private sanitizeEntryName(name: string): string | null {
    const normalized = String(name || '').replace(/\\/g, '/').replace(/^\\/+/, '');
    const parts = normalized.split('/').filter(Boolean);
    if (!parts.length || parts.some((part) => part === '..')) return null;
    if (parts.some((part) => /^[A-Za-z]:$/.test(part))) return null;
    return parts.join('/');
  }

  async extractZipFile(zipPath: string, outputPath: string, options: ZipOptions = {}): Promise<ZipResult> {
    try {
      const zipData = await FileSystem.readAsStringAsync(zipPath, { encoding: 'base64' });
      return this.extractZip(zipData, outputPath, options);
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async zipDirectory(directoryPath: string, outputPath: string, options: ZipOptions = {}): Promise<ZipResult> {
    try {
      const zip = new JSZip();
      await this.addDirectoryToZip(zip, directoryPath, '');
      
      const content = await zip.generateAsync({
        type: 'base64',
        compression: 'DEFLATE',
        compressionOptions: {
          level: options.compressionLevel || 6,
        },
      });
      
      await FileSystem.writeAsStringAsync(outputPath, content, { encoding: 'base64' });
      
      const info = await FileSystem.getInfoAsync(outputPath);
      return { success: true, path: outputPath, size: info.size };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async unzipToDirectory(zipPath: string, outputPath: string, options: ZipOptions = {}): Promise<ZipResult> {
    return this.extractZipFile(zipPath, outputPath, options);
  }

  async listZipContents(zipPath: string): Promise<string[]> {
    try {
      const zipData = await FileSystem.readAsStringAsync(zipPath, { encoding: 'base64' });
      const zip = await JSZip.loadAsync(zipData, { base64: true });
      return Object.keys(zip.files);
    } catch {
      return [];
    }
  }
}

export const zipService = new ZipService();
export default zipService;