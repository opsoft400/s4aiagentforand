import axios, { AxiosInstance } from 'axios';
import type { GitHubRepo, GitHubFile, GitHubUser, GitHubBranch, GitHubCommit, GitHubPullRequest } from '@/types';

interface GitHubConfig {
  token?: string;
  baseUrl?: string;
}

interface CreateFileRequest {
  path: string;
  content: string;
  message: string;
  branch?: string;
  committer?: {
    name: string;
    email: string;
  };
}

interface UpdateFileRequest extends CreateFileRequest {
  sha: string;
}

interface CreateRepoRequest {
  name: string;
  description?: string;
  private?: boolean;
  auto_init?: boolean;
  gitignore_template?: string;
  license_template?: string;
}

interface CreateBranchRequest {
  ref: string;
  sha: string;
}

interface CreatePullRequestRequest {
  title: string;
  head: string;
  base: string;
  body?: string;
  draft?: boolean;
}

interface MergePullRequestRequest {
  commit_title?: string;
  commit_message?: string;
  sha?: string;
  merge_method?: 'merge' | 'squash' | 'rebase';
}

export class GitHubService {
  private client: AxiosInstance;
  private token: string | null = null;

  constructor(config: GitHubConfig = {}) {
    this.token = config.token || null;
    this.client = axios.create({
      baseURL: config.baseUrl || 'https://api.github.com',
      timeout: 30000,
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json',
        ...(this.token && { Authorization: `Bearer ${this.token}` }),
      },
    });
  }

  setToken(token: string): void {
    this.token = token;
    this.client.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }

  getToken(): string | null {
    return this.token;
  }

  async checkAuth(): Promise<boolean> {
    try {
      await this.client.get('/user');
      return true;
    } catch {
      return false;
    }
  }

  async getUser(): Promise<GitHubUser> {
    const response = await this.client.get<GitHubUser>('/user');
    return response.data;
  }

  async getRepos(options: { sort?: string; per_page?: number; page?: number } = {}): Promise<GitHubRepo[]> {
    const response = await this.client.get<GitHubRepo[]>('/user/repos', {
      params: { sort: 'updated', per_page: 100, ...options },
    });
    return response.data;
  }

  async getRepo(owner: string, repo: string): Promise<GitHubRepo> {
    const response = await this.client.get<GitHubRepo>(`/repos/${owner}/${repo}`);
    return response.data;
  }

  async createRepo(request: CreateRepoRequest): Promise<GitHubRepo> {
    const response = await this.client.post<GitHubRepo>('/user/repos', {
      name: request.name,
      description: request.description,
      private: request.private ?? false,
      auto_init: request.auto_init ?? true,
      gitignore_template: request.gitignore_template,
      license_template: request.license_template,
    });
    return response.data;
  }

  async forkRepo(owner: string, repo: string): Promise<GitHubRepo> {
    const response = await this.client.post<GitHubRepo>(`/repos/${owner}/${repo}/forks`);
    return response.data;
  }

  async deleteRepo(owner: string, repo: string): Promise<void> {
    await this.client.delete(`/repos/${owner}/${repo}`);
  }

  async getFile(owner: string, repo: string, path: string, branch?: string): Promise<GitHubFile> {
    const response = await this.client.get<GitHubFile>(`/repos/${owner}/${repo}/contents/${path}`, {
      params: { ref: branch },
    });
    return response.data;
  }

  async getDirectory(owner: string, repo: string, path: string, branch?: string): Promise<GitHubFile[]> {
    const response = await this.client.get<GitHubFile[]>(`/repos/${owner}/${repo}/contents/${path}`, {
      params: { ref: branch },
    });
    return response.data;
  }

  async getRepoTree(owner: string, repo: string, branch = 'main', recursive = true): Promise<any[]> {
    const response = await this.client.get(`/repos/${owner}/${repo}/git/trees/${branch}`, {
      params: { recursive: recursive ? '1' : '0' },
    });
    return response.data.tree || [];
  }

  async createFile(owner: string, repo: string, request: CreateFileRequest): Promise<{ content: GitHubFile; commit: any }> {
    const response = await this.client.put(`/repos/${owner}/${repo}/contents/${request.path}`, {
      message: request.message,
      content: btoa(request.content),
      branch: request.branch,
      committer: request.committer,
    });
    return response.data;
  }

  async updateFile(owner: string, repo: string, request: UpdateFileRequest): Promise<{ content: GitHubFile; commit: any }> {
    const response = await this.client.put(`/repos/${owner}/${repo}/contents/${request.path}`, {
      message: request.message,
      content: btoa(request.content),
      sha: request.sha,
      branch: request.branch,
      committer: request.committer,
    });
    return response.data;
  }

  async deleteFile(owner: string, repo: string, path: string, message: string, sha: string, branch?: string): Promise<void> {
    await this.client.delete(`/repos/${owner}/${repo}/contents/${path}`, {
      data: { message, sha, branch },
    });
  }

  async uploadFiles(owner: string, repo: string, files: Array<{ path: string; content: string; message: string }>, branch = 'main'): Promise<void> {
    for (const file of files) {
      try {
        const existing = await this.getFile(owner, repo, file.path, branch);
        await this.updateFile(owner, repo, {
          path: file.path,
          content: file.content,
          message: file.message,
          sha: existing.sha,
          branch,
        });
      } catch {
        await this.createFile(owner, repo, {
          path: file.path,
          content: file.content,
          message: file.message,
          branch,
        });
      }
    }
  }

  async getBranches(owner: string, repo: string): Promise<GitHubBranch[]> {
    const response = await this.client.get<GitHubBranch[]>(`/repos/${owner}/${repo}/branches`);
    return response.data;
  }

  async createBranch(owner: string, repo: string, branchName: string, fromBranch = 'main'): Promise<GitHubBranch> {
    const branches = await this.getBranches(owner, repo);
    const sourceBranch = branches.find(b => b.name === fromBranch);
    if (!sourceBranch) throw new Error(`Branch ${fromBranch} not found`);

    const response = await this.client.post<GitHubBranch>(`/repos/${owner}/${repo}/git/refs`, {
      ref: `refs/heads/${branchName}`,
      sha: sourceBranch.commit.sha,
    });
    return response.data.object;
  }

  async deleteBranch(owner: string, repo: string, branchName: string): Promise<void> {
    await this.client.delete(`/repos/${owner}/${repo}/git/refs/heads/${branchName}`);
  }

  async getCommits(owner: string, repo: string, options: { sha?: string; path?: string; per_page?: number } = {}): Promise<GitHubCommit[]> {
    const response = await this.client.get<GitHubCommit[]>(`/repos/${owner}/${repo}/commits`, {
      params: options,
    });
    return response.data;
  }

  async getPullRequests(owner: string, repo: string, state: 'open' | 'closed' | 'all' = 'open'): Promise<GitHubPullRequest[]> {
    const response = await this.client.get<GitHubPullRequest[]>(`/repos/${owner}/${repo}/pulls`, {
      params: { state, sort: 'updated', direction: 'desc' },
    });
    return response.data;
  }

  async createPullRequest(owner: string, repo: string, request: CreatePullRequestRequest): Promise<GitHubPullRequest> {
    const response = await this.client.post<GitHubPullRequest>(`/repos/${owner}/${repo}/pulls`, request);
    return response.data;
  }

  async mergePullRequest(owner: string, repo: string, pullNumber: number, request: MergePullRequestRequest = {}): Promise<any> {
    const response = await this.client.put(`/repos/${owner}/${repo}/pulls/${pullNumber}/merge`, request);
    return response.data;
  }

  async closePullRequest(owner: string, repo: string, pullNumber: number): Promise<GitHubPullRequest> {
    const response = await this.client.patch<GitHubPullRequest>(`/repos/${owner}/${repo}/pulls/${pullNumber}`, {
      state: 'closed',
    });
    return response.data;
  }

  async createRelease(owner: string, repo: string, request: {
    tag_name: string;
    name: string;
    body?: string;
    draft?: boolean;
    prerelease?: boolean;
    target_commitish?: string;
  }): Promise<any> {
    const response = await this.client.post(`/repos/${owner}/${repo}/releases`, request);
    return response.data;
  }

  async uploadReleaseAsset(owner: string, repo: string, releaseId: number, request: {
    name: string;
    contentType: string;
    data: string; // base64
  }): Promise<any> {
    const uploadUrl = `https://uploads.github.com/repos/${owner}/${repo}/releases/${releaseId}/assets?name=${request.name}`;
    
    const response = await axios.post(uploadUrl, request.data, {
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': request.contentType,
        'Accept': 'application/vnd.github.v3+json',
      },
    });
    return response.data;
  }

  async getReleases(owner: string, repo: string): Promise<any[]> {
    const response = await this.client.get(`/repos/${owner}/${repo}/releases`);
    return response.data;
  }

  async downloadFile(url: string): Promise<string> {
    const response = await axios.get(url, {
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Accept': 'application/vnd.github.v3.raw',
      },
      responseType: 'text',
    });
    return response.data;
  }

  async searchRepos(query: string, options: { sort?: string; order?: string; per_page?: number } = {}): Promise<GitHubRepo[]> {
    const response = await this.client.get('/search/repositories', {
      params: { q: query, sort: 'stars', order: 'desc', ...options },
    });
    return response.data.items;
  }

  async searchCode(owner: string, repo: string, query: string): Promise<any[]> {
    const response = await this.client.get('/search/code', {
      params: { q: `${query} repo:${owner}/${repo}` },
    });
    return response.data.items;
  }

  async starRepo(owner: string, repo: string): Promise<void> {
    await this.client.put(`/user/starred/${owner}/${repo}`);
  }

  async unstarRepo(owner: string, repo: string): Promise<void> {
    await this.client.delete(`/user/starred/${owner}/${repo}`);
  }

  async getStarredRepos(): Promise<GitHubRepo[]> {
    const response = await this.client.get<GitHubRepo[]>('/user/starred');
    return response.data;
  }

  async getWorkflows(owner: string, repo: string): Promise<any[]> {
    const response = await this.client.get(`/repos/${owner}/${repo}/actions/workflows`);
    return response.data.workflows || [];
  }

  async triggerWorkflow(owner: string, repo: string, workflowId: string, ref: string, inputs?: Record<string, any>): Promise<any> {
    const response = await this.client.post(`/repos/${owner}/${repo}/actions/workflows/${workflowId}/dispatches`, {
      ref,
      inputs,
    });
    return response.data;
  }

  async getWorkflowRuns(owner: string, repo: string, workflowId?: string): Promise<any[]> {
    const url = workflowId 
      ? `/repos/${owner}/${repo}/actions/workflows/${workflowId}/runs`
      : `/repos/${owner}/${repo}/actions/runs`;
    const response = await this.client.get(url);
    return response.data.workflow_runs || [];
  }

  async getRepoLanguages(owner: string, repo: string): Promise<Record<string, number>> {
    const response = await this.client.get(`/repos/${owner}/${repo}/languages`);
    return response.data;
  }

  async getRepoTopics(owner: string, repo: string): Promise<string[]> {
    const response = await this.client.get(`/repos/${owner}/${repo}/topics`);
    return response.data.names || [];
  }

  async updateRepoTopics(owner: string, repo: string, topics: string[]): Promise<void> {
    await this.client.put(`/repos/${owner}/${repo}/topics`, { names: topics });
  }

  async createIssue(owner: string, repo: string, request: {
    title: string;
    body?: string;
    assignees?: string[];
    labels?: string[];
    milestone?: number;
  }): Promise<any> {
    const response = await this.client.post(`/repos/${owner}/${repo}/issues`, request);
    return response.data;
  }

  async getIssues(owner: string, repo: string, state: 'open' | 'closed' | 'all' = 'open'): Promise<any[]> {
    const response = await this.client.get(`/repos/${owner}/${repo}/issues`, {
      params: { state, sort: 'updated', direction: 'desc' },
    });
    return response.data;
  }
}

export const createGitHubService = (token?: string): GitHubService => {
  return new GitHubService({ token });
};

export default GitHubService;