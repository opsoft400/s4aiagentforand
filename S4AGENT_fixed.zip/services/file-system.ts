import * as FileSystem from 'expo-file-system';
import { encode as btoa, decode as atob } from 'base-64';
import { v4 as uuidv4 } from 'uuid';
import type { FileNode, FileOperation, ZipOptions, ZipResult } from '@/types';
import { MIME_TYPES } from '@/constants';

class FileSystemService {
  private basePath: string;

  constructor(basePath?: string) {
    this.basePath = basePath || FileSystem.documentDirectory || '';
  }

  setBasePath(path: string): void {
    this.basePath = path;
  }

  getBasePath(): string {
    return this.basePath;
  }

  async exists(path: string): Promise<boolean> {
    try {
      const info = await FileSystem.getInfoAsync(this.resolvePath(path));
      return info.exists;
    } catch {
      return false;
    }
  }

  async readFile(path: string, encoding: 'utf-8' | 'base64' = 'utf-8'): Promise<string> {
    const fullPath = this.resolvePath(path);
    const info = await FileSystem.getInfoAsync(fullPath);
    if (!info.exists) {
      throw new Error(`File not found: ${path}`);
    }
    return FileSystem.readAsStringAsync(fullPath, { encoding });
  }

  async writeFile(path: string, content: string, encoding: 'utf-8' | 'base64' = 'utf-8'): Promise<void> {
    const fullPath = this.resolvePath(path);
    await FileSystem.makeDirectoryAsync(this.getDirName(fullPath), { intermediates: true });
    await FileSystem.writeAsStringAsync(fullPath, content, { encoding });
  }

  async deleteFile(path: string, recursive = false): Promise<void> {
    const fullPath = this.resolvePath(path);
    await FileSystem.deleteAsync(fullPath, { idempotent: true, recursive });
  }

  async createDirectory(path: string): Promise<void> {
    const fullPath = this.resolvePath(path);
    await FileSystem.makeDirectoryAsync(fullPath, { intermediates: true });
  }

  async listDirectory(path: string, recursive = false): Promise<FileNode[]> {
    const fullPath = this.resolvePath(path);
    const info = await FileSystem.getInfoAsync(fullPath);
    if (!info.exists || !info.isDirectory) {
      throw new Error(`Directory not found: ${path}`);
    }

    const items = await FileSystem.readDirectoryAsync(fullPath);
    const nodes: FileNode[] = [];

    for (const item of items) {
      const itemPath = `${path}/${item}`.replace(/\/+/g, '/');
      const fullItemPath = this.resolvePath(itemPath);
      const itemInfo = await FileSystem.getInfoAsync(fullItemPath);
      
      const node: FileNode = {
        id: uuidv4(),
        name: item,
        path: itemPath,
        type: itemInfo.isDirectory ? 'folder' : 'file',
        size: itemInfo.size,
        mimeType: itemInfo.isDirectory ? undefined : this.getMimeType(item),
        modifiedAt: new Date(itemInfo.modificationTime || Date.now()),
        createdAt: new Date(itemInfo.modificationTime || Date.now()),
        isExpanded: false,
        isSelected: false,
      };

      if (recursive && itemInfo.isDirectory) {
        node.children = await this.listDirectory(itemPath, true);
      }

      nodes.push(node);
    }

    return nodes.sort((a, b) => {
      if (a.type !== b.type) {
        return a.type === 'folder' ? -1 : 1;
      }
      return a.name.localeCompare(b.name);
    });
  }

  async moveFile(source: string, destination: string): Promise<void> {
    const srcPath = this.resolvePath(source);
    const destPath = this.resolvePath(destination);
    await FileSystem.makeDirectoryAsync(this.getDirName(destPath), { intermediates: true });
    await FileSystem.moveAsync({ from: srcPath, to: destPath });
  }

  async copyFile(source: string, destination: string): Promise<void> {
    const srcPath = this.resolvePath(source);
    const destPath = this.resolvePath(destination);
    await FileSystem.makeDirectoryAsync(this.getDirName(destPath), { intermediates: true });
    await FileSystem.copyAsync({ from: srcPath, to: destPath });
  }

  async getFileInfo(path: string): Promise<FileSystem.FileInfo> {
    return FileSystem.getInfoAsync(this.resolvePath(path));
  }

  async searchFiles(query: string, path: string, type: 'name' | 'content' | 'both' = 'both', caseSensitive = false): Promise<FileNode[]> {
    const results: FileNode[] = [];
    const searchRecursive = async (currentPath: string) => {
      const items = await this.listDirectory(currentPath);
      for (const item of items) {
        const matchesName = caseSensitive
          ? item.name.includes(query)
          : item.name.toLowerCase().includes(query.toLowerCase());
        
        if (type === 'name' || type === 'both') {
          if (matchesName) {
            results.push(item);
          }
        }
        
        if (type === 'content' || type === 'both') {
          if (item.type === 'file') {
            try {
              const content = await this.readFile(item.path);
              const matchesContent = caseSensitive
                ? content.includes(query)
                : content.toLowerCase().includes(query.toLowerCase());
              if (matchesContent) {
                results.push(item);
              }
            } catch {
              // Ignore read errors
            }
          }
        }
        
        if (item.type === 'folder') {
          await searchRecursive(item.path);
        }
      }
    };

    await searchRecursive(path);
    return results;
  }

  async downloadFile(url: string, path: string): Promise<void> {
    const fullPath = this.resolvePath(path);
    await FileSystem.makeDirectoryAsync(this.getDirName(fullPath), { intermediates: true });
    
    const downloadResumable = FileSystem.createDownloadResumable(
      url,
      fullPath,
      {},
      (downloadProgress) => {
        const progress = downloadProgress.totalBytesWritten / downloadProgress.totalBytesExpectedToWrite;
        console.log(`Download progress: ${Math.round(progress * 100)}%`);
      }
    );
    
    const result = await downloadResumable.downloadAsync();
    if (!result) {
      throw new Error('Download failed');
    }
  }

  async zipFiles(files: string[], outputPath: string, options: ZipOptions = {}): Promise<ZipResult> {
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      
      for (const file of files) {
        const fullPath = this.resolvePath(file);
        const info = await FileSystem.getInfoAsync(fullPath);
        
        if (info.exists) {
          if (info.isDirectory) {
            await this.addDirectoryToZip(zip, fullPath, file);
          } else {
            const content = await this.readFile(file, 'base64');
            zip.file(file, content, { base64: true });
          }
        }
      }
      
      const fullOutputPath = this.resolvePath(outputPath);
      await FileSystem.makeDirectoryAsync(this.getDirName(fullOutputPath), { intermediates: true });
      
      const content = await zip.generateAsync({
        type: 'base64',
        compression: 'DEFLATE',
        compressionOptions: {
          level: options.compressionLevel || 6,
        },
      });
      
      await FileSystem.writeAsStringAsync(fullOutputPath, content, { encoding: 'base64' });
      
      const outputInfo = await FileSystem.getInfoAsync(fullOutputPath);
      return { success: true, path: outputPath, size: outputInfo.size };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  private async addDirectoryToZip(zip: any, fullPath: string, relativePath: string): Promise<void> {
    const items = await FileSystem.readDirectoryAsync(fullPath);
    for (const item of items) {
      const itemFullPath = `${fullPath}/${item}`;
      const itemRelativePath = `${relativePath}/${item}`;
      const info = await FileSystem.getInfoAsync(itemFullPath);
      
      if (info.isDirectory) {
        await this.addDirectoryToZip(zip, itemFullPath, itemRelativePath);
      } else {
        const content = await this.readFile(itemRelativePath, 'base64');
        zip.file(itemRelativePath, content, { base64: true });
      }
    }
  }

  async unzipFile(zipPath: string, outputPath: string, password?: string): Promise<ZipResult> {
    try {
      const fullZipPath = this.resolvePath(zipPath);
      const fullOutputPath = this.resolvePath(outputPath);
      
      if (password) {
        return { success: false, error: 'Password-protected zip not supported yet' };
      }
      
      const JSZip = (await import('jszip')).default;
      const zipData = await FileSystem.readAsStringAsync(fullZipPath, { encoding: 'base64' });
      const zip = await JSZip.loadAsync(zipData, { base64: true });
      
      await FileSystem.makeDirectoryAsync(fullOutputPath, { intermediates: true });
      
      for (const [name, file] of Object.entries(zip.files)) {
        if (file.dir) continue;

        const safeName = this.sanitizeZipEntryName(name);
        if (!safeName) {
          throw new Error(`Unsafe ZIP entry rejected: ${name}`);
        }

        const content = await file.async('base64');
        const filePath = `${fullOutputPath}/${safeName}`;
        await FileSystem.makeDirectoryAsync(this.getDirName(filePath), { intermediates: true });
        await FileSystem.writeAsStringAsync(filePath, content, { encoding: 'base64' });
      }
      
      return { success: true, path: outputPath };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }

  async runCommand(command: string, cwd?: string): Promise<{ stdout: string; stderr: string; exitCode: number }> {
    // React Native cannot execute an arbitrary OS shell without a native shell module.
    // Instead of pretending it worked, support common file-oriented commands locally.
    const workingDir = cwd || this.basePath;
    const parts = command.trim().match(/(?:[^\s"]+|"[^"]*")+/g)?.map((p) => p.replace(/^"|"$/g, '')) || [];
    if (!parts.length) return { stdout: '', stderr: '', exitCode: 0 };

    const cmd = parts[0];
    const arg = (index = 1) => parts[index];

    try {
      switch (cmd) {
        case 'pwd':
          return { stdout: this.resolvePath(workingDir) + '\n', stderr: '', exitCode: 0 };
        case 'ls': {
          const path = arg() || workingDir;
          const nodes = await this.listDirectory(path);
          return { stdout: nodes.map((n) => n.name + (n.type === 'folder' ? '/' : '')).join('\n') + '\n', stderr: '', exitCode: 0 };
        }
        case 'mkdir':
          await this.createDirectory(arg() || '');
          return { stdout: '', stderr: '', exitCode: 0 };
        case 'cat':
          return { stdout: await this.readFile(arg() || ''), stderr: '', exitCode: 0 };
        case 'rm':
          await this.deleteFile(arg() || '', parts.includes('-r') || parts.includes('-rf'));
          return { stdout: '', stderr: '', exitCode: 0 };
        case 'mv':
          await this.moveFile(arg(1) || '', arg(2) || '');
          return { stdout: '', stderr: '', exitCode: 0 };
        case 'cp':
          await this.copyFile(arg(1) || '', arg(2) || '');
          return { stdout: '', stderr: '', exitCode: 0 };
        case 'echo':
          return { stdout: parts.slice(1).join(' ') + '\n', stderr: '', exitCode: 0 };
        default:
          return {
            stdout: '',
            stderr: `Command "${cmd}" is not available in the mobile sandbox. Use a connected backend/terminal for arbitrary shell commands.`,
            exitCode: 127,
          };
      }
    } catch (error) {
      return { stdout: '', stderr: error instanceof Error ? error.message : String(error), exitCode: 1 };
    }
  }

  private resolvePath(path: string): string {
    const raw = String(path || '').trim();
    if (!raw) return this.basePath;

    if (raw.startsWith('file://') || raw.startsWith('/')) {
      return raw.replace(/\/+/g, '/');
    }

    const normalized = raw
      .replace(/\\/g, '/')
      .split('/')
      .filter((part) => part && part !== '.')
      .reduce<string[]>((parts, part) => {
        if (part === '..') parts.pop();
        else parts.push(part);
        return parts;
      }, [])
      .join('/');

    return `${this.basePath}/${normalized}`.replace(/\/+/g, '/');
  }

  private sanitizeZipEntryName(name: string): string | null {
    const normalized = String(name || '').replace(/\\/g, '/').replace(/^\/+/, '');
    const parts = normalized.split('/').filter(Boolean);
    if (!parts.length || parts.some((part) => part === '..')) return null;
    if (parts.some((part) => /^[A-Za-z]:$/.test(part))) return null;
    return parts.join('/');
  }

  private getDirName(path: string): string {
    return path.substring(0, path.lastIndexOf('/'));
  }

  private getMimeType(filename: string): string {
    const ext = filename.substring(filename.lastIndexOf('.')).toLowerCase();
    return MIME_TYPES[ext] || 'application/octet-stream';
  }

  async watchDirectory(path: string, callback: (event: { type: string; path: string }) => void): Promise<() => void> {
    // File system watching would need native module
    // For now, return a no-op cleanup function
    console.log(`Watching directory: ${path}`);
    return () => {};
  }
}

export const fileSystemService = new FileSystemService();
export default fileSystemService;