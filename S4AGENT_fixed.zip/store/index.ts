import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type {
  AppState,
  FileNode,
  AIMessage,
  AgentConfig,
  UserPreferences,
  ThemeConfig,
  GitHubUser,
  ToolDefinition,
} from '@/types';
import {
  DEFAULT_PREFERENCES,
  DEFAULT_THEME,
  SYSTEM_PROMPTS,
  TOOL_DEFINITIONS,
} from '@/constants';

interface AppStore extends AppState {
  setCurrentProject: (path: string | null) => void;
  setFileTree: (tree: FileNode | null) => void;
  addOpenFile: (file: FileNode) => void;
  removeOpenFile: (path: string) => void;
  setActiveFile: (path: string | null) => void;
  updateFileContent: (path: string, content: string) => void;
  addChatMessage: (message: AIMessage) => void;
  updateChatMessage: (id: string, updates: Partial<AIMessage>) => void;
  clearChatHistory: () => void;
  setAgentConfig: (config: Partial<AgentConfig>) => void;
  setPreferences: (prefs: Partial<UserPreferences>) => void;
  setTheme: (theme: ThemeConfig) => void;
  setConnectionStatus: (status: AppState['connectionStatus']) => void;
  setIsConnected: (connected: boolean) => void;
  setGitHubToken: (token: string | null) => void;
  setGitHubUser: (user: GitHubUser | null) => void;
  toggleFolder: (id: string) => void;
  selectFile: (id: string) => void;
  deselectAll: () => void;
  reset: () => void;
}

const initialAgentConfig: AgentConfig = {
  model: 'deepseek-coder:6.7b',
  temperature: 0.7,
  maxTokens: 4096,
  systemPrompt: SYSTEM_PROMPTS.default,
  tools: TOOL_DEFINITIONS,
  apiProvider: 'ollama',
  apiEndpoint: 'http://localhost:11434',
};

const initialState: AppState = {
  currentProject: null,
  fileTree: null,
  openFiles: new Map(),
  activeFile: null,
  chatHistory: [],
  agentConfig: initialAgentConfig,
  preferences: DEFAULT_PREFERENCES,
  isConnected: false,
  connectionStatus: 'disconnected',
  githubToken: null,
  githubUser: null,
};

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      ...initialState,

      setCurrentProject: (path) => set({ currentProject: path }),

      setFileTree: (tree) => set({ fileTree: tree }),

      addOpenFile: (file) =>
        set((state) => {
          const newOpenFiles = new Map(state.openFiles);
          newOpenFiles.set(file.path, file);
          return { openFiles: newOpenFiles };
        }),

      removeOpenFile: (path) =>
        set((state) => {
          const newOpenFiles = new Map(state.openFiles);
          newOpenFiles.delete(path);
          const newActiveFile = state.activeFile === path ? null : state.activeFile;
          return { openFiles: newOpenFiles, activeFile: newActiveFile };
        }),

      setActiveFile: (path) => set({ activeFile: path }),

      updateFileContent: (path, content) =>
        set((state) => {
          const newOpenFiles = new Map(state.openFiles);
          const file = newOpenFiles.get(path);
          if (file) {
            newOpenFiles.set(path, { ...file, content });
          }
          return { openFiles: newOpenFiles };
        }),

      addChatMessage: (message) =>
        set((state) => ({
          chatHistory: [...state.chatHistory, message],
        })),

      updateChatMessage: (id, updates) =>
        set((state) => ({
          chatHistory: state.chatHistory.map((msg) =>
            msg.id === id ? { ...msg, ...updates } : msg
          ),
        })),

      clearChatHistory: () => set({ chatHistory: [] }),

      setAgentConfig: (config) =>
        set((state) => ({
          agentConfig: { ...state.agentConfig, ...config },
        })),

      setPreferences: (prefs) =>
        set((state) => ({
          preferences: { ...state.preferences, ...prefs },
        })),

      setTheme: (theme) =>
        set((state) => ({
          preferences: { ...state.preferences, customTheme: theme },
        })),

      setConnectionStatus: (connectionStatus) =>
        set({ connectionStatus }),

      setIsConnected: (isConnected) =>
        set({ isConnected }),

      setGitHubToken: (githubToken) =>
        set({ githubToken }),

      setGitHubUser: (githubUser) =>
        set({ githubUser }),

      toggleFolder: (id) =>
        set((state) => {
          const toggleRecursive = (nodes: FileNode[]): FileNode[] =>
            nodes.map((node) => {
              if (node.id === id && node.type === 'folder') {
                return { ...node, isExpanded: !node.isExpanded };
              }
              if (node.children) {
                return { ...node, children: toggleRecursive(node.children) };
              }
              return node;
            });

          if (state.fileTree) {
            return {
              fileTree: {
                ...state.fileTree,
                children: toggleRecursive(state.fileTree.children || []),
              },
            };
          }
          return state;
        }),

      selectFile: (id) =>
        set((state) => {
          const selectRecursive = (nodes: FileNode[]): FileNode[] =>
            nodes.map((node) => ({
              ...node,
              isSelected: node.id === id,
              children: node.children ? selectRecursive(node.children) : undefined,
            }));

          if (state.fileTree) {
            return {
              fileTree: {
                ...state.fileTree,
                children: selectRecursive(state.fileTree.children || []),
              },
            };
          }
          return state;
        }),

      deselectAll: () =>
        set((state) => {
          const deselectRecursive = (nodes: FileNode[]): FileNode[] =>
            nodes.map((node) => ({
              ...node,
              isSelected: false,
              children: node.children ? deselectRecursive(node.children) : undefined,
            }));

          if (state.fileTree) {
            return {
              fileTree: {
                ...state.fileTree,
                children: deselectRecursive(state.fileTree.children || []),
              },
            };
          }
          return state;
        }),

      reset: () => set(initialState),
    }),
    {
      name: 's4agent-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        preferences: state.preferences,
        agentConfig: state.agentConfig,
        githubToken: state.githubToken,
        githubUser: state.githubUser,
      }),
    }
  )
);