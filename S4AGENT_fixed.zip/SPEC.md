# S4AGENT - AI Agent Mobile Application Specification

## Overview
S4AGENT is a fully customizable AI agent mobile application that connects to opencode servers, supports DeepSeek and opencode APIs without requiring API keys, includes a built-in file manager, and can be built as an APK for Android.

## Core Features

### 1. AI Integration
- **Opencode Server Connection**: Connect to local/remote opencode servers via WebSocket/HTTP
- **DeepSeek API Support**: Direct integration with DeepSeek models (no API key needed - uses local/self-hosted)
- **Opencode API Support**: Full opencode API compatibility
- **Model Loading**: Dynamic model loading and switching
- **Offline Mode**: Basic functionality without internet

### 2. File Manager (Built-in)
- **File Operations**: Create, read, update, delete files and folders
- **Navigation**: Tree view, breadcrumbs, search
- **File Types**: Support for code files, images, documents, archives
- **Drag & Drop**: Intuitive file organization
- **Context Menu**: Right-click/long-press actions

### 3. Zip Operations
- **Export**: Zip entire projects or selected files/folders
- **Import**: Unzip and import projects
- **Compression Levels**: Configurable compression
- **Password Protection**: Optional encryption

### 4. AI Agent Capabilities
- **File System Access**: AI can create, edit, rename, move, delete files/folders
- **Code Generation**: AI writes code directly to files
- **Project Scaffolding**: AI creates project structures
- **Refactoring**: AI modifies existing codebases
- **Download Management**: AI can download files from URLs

### 5. Customizable UI
- **Theme System**: Light/dark/custom themes with CSS variables
- **Layout Options**: Sidebar, tabs, panels - all configurable
- **Component Library**: Reusable styled components
- **User Preferences**: Persisted settings
- **Extensions**: Plugin system for UI additions

### 6. GitHub Integration
- **Authentication**: OAuth/GitHub App (optional)
- **Repository Operations**: Clone, push, pull, create repos
- **File Upload**: Direct file/folder upload to repos
- **Release Management**: Create releases with APK assets

### 7. APK Building
- **EAS Build**: Expo Application Services for cloud builds
- **Local Build**: Gradle/Android Studio support
- **Auto-versioning**: Semantic version management
- **Signing**: Keystore management

## Technical Architecture

### Frontend (React Native + Expo)
```
S4AGENT/
├── app/                    # Expo Router pages
│   ├── (tabs)/            # Main tab navigation
│   │   ├── index.tsx      # Chat/Agent interface
│   │   ├── files.tsx      # File manager
│   │   ├── settings.tsx   # Settings & customization
│   │   └── github.tsx     # GitHub integration
│   ├── _layout.tsx        # Root layout
│   └── +not-found.tsx     # 404 handler
├── components/            # Reusable UI components
│   ├── ui/               # Base components (Button, Input, Card, etc.)
│   ├── file-manager/     # File manager specific components
│   ├── chat/             # Chat interface components
│   └── theme/            # Theme provider and components
├── hooks/                # Custom React hooks
├── services/             # Business logic services
│   ├── opencode.ts       # Opencode API client
│   ├── deepseek.ts       # DeepSeek API client
│   ├── file-system.ts    # File system operations
│   ├── zip.ts            # Zip/Unzip operations
│   ├── github.ts         # GitHub API client
│   └── ai-agent.ts       # AI agent orchestration
├── store/                # State management (Zustand)
├── utils/                # Utility functions
├── types/                # TypeScript types
├── constants/            # App constants
└── assets/               # Images, fonts, etc.
```

### Backend Services (Node.js - for local server)
```
server/
├── opencode-proxy.ts     # Opencode server proxy
├── deepseek-proxy.ts     # DeepSeek API proxy
├── file-server.ts        # Local file server
└── websocket.ts          # Real-time communication
```

## API Integration Details

### Opencode API (No Key Required)
- Connects to local opencode server (default: http://localhost:3000)
- WebSocket for real-time updates
- REST API for operations
- Supports all opencode features: sessions, agents, tools

### DeepSeek API (No Key Required)
- Uses self-hosted DeepSeek models via Ollama/vLLM
- Default endpoint: http://localhost:11434 (Ollama)
- Supports: deepseek-coder, deepseek-chat, deepseek-llm
- Streaming responses

## File Manager Features
- **Virtual File System**: In-memory representation with persistence
- **Watchers**: Real-time file system changes
- **Search**: Full-text search across files
- **Git Integration**: Show git status per file
- **Terminal**: Integrated shell access

## AI Agent System
- **Tool Calling**: Structured tool use for file operations
- **Context Management**: Relevant file context for AI
- **Multi-step Tasks**: Chained operations with confirmation
- **Safety**: Confirmation dialogs for destructive operations
- **History**: Undo/redo for AI actions

## Customization System
- **Theme Tokens**: Colors, spacing, typography, borders
- **Layout Presets**: Predefined layouts (IDE, Chat, Minimal)
- **Component Overrides**: Replace any component
- **Keyboard Shortcuts**: Customizable keybindings
- **Plugins**: Extension system for custom features

## Build Configuration
- **EAS Build**: `eas build --platform android`
- **Local Build**: `npx expo run:android`
- **APK Output**: `./builds/S4AGENT-v{version}.apk`
- **Version**: Auto-increment from package.json

## Security Considerations
- No hardcoded API keys
- Local-first architecture
- Optional encryption for sensitive data
- Sandbox file access
- Permission-based AI actions

## Development Workflow
1. `npm install` - Install dependencies
2. `npm run dev` - Start development server
3. `npm run build:apk` - Build APK via EAS
4. `npm run deploy:github` - Deploy to GitHub releases