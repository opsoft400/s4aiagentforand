import { useState, useEffect, useCallback, useMemo } from 'react';
import { useAppStore } from '@/store';
import { Platform, Appearance, StyleSheet } from 'react-native';
import { DEFAULT_THEME, LIGHT_THEME, type ThemeConfig, type UserPreferences } from '@/constants';

export function useTheme() {
  const { preferences, setPreferences, setTheme } = useAppStore();
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('dark');
  const [systemTheme, setSystemTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setSystemTheme(colorScheme || 'dark');
    });
    setSystemTheme(Appearance.getColorScheme() || 'dark');
    return () => subscription?.remove();
  }, []);

  useEffect(() => {
    if (preferences.theme === 'system') {
      setResolvedTheme(systemTheme);
    } else if (preferences.theme === 'light' || preferences.theme === 'dark') {
      setResolvedTheme(preferences.theme);
    } else if (preferences.customTheme) {
      setResolvedTheme('dark');
    }
  }, [preferences.theme, preferences.customTheme, systemTheme]);

  const theme = useMemo((): ThemeConfig => {
    if (preferences.customTheme) {
      return preferences.customTheme;
    }
    return resolvedTheme === 'light' ? LIGHT_THEME : DEFAULT_THEME;
  }, [preferences.customTheme, resolvedTheme]);

  const updateTheme = useCallback((newTheme: Partial<ThemeConfig>) => {
    const updatedTheme = { ...theme, ...newTheme };
    setTheme(updatedTheme);
  }, [theme, setTheme]);

  const setThemeMode = useCallback((mode: UserPreferences['theme']) => {
    setPreferences({ theme: mode });
  }, [setPreferences]);

  const setCustomTheme = useCallback((customTheme: ThemeConfig) => {
    setPreferences({ theme: 'custom', customTheme });
  }, [setPreferences]);

  const styles = useMemo(() => StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.colors.background,
    },
    surface: {
      backgroundColor: theme.colors.surface,
      borderRadius: theme.borderRadius.md,
      padding: theme.spacing.md,
    },
    surfaceVariant: {
      backgroundColor: theme.colors.surfaceVariant,
      borderRadius: theme.borderRadius.md,
      padding: theme.spacing.md,
    },
    primaryButton: {
      backgroundColor: theme.colors.primary,
      borderRadius: theme.borderRadius.md,
      paddingVertical: theme.spacing.sm,
      paddingHorizontal: theme.spacing.md,
    },
    primaryButtonText: {
      color: theme.colors.onPrimary,
      fontWeight: '600',
      textAlign: 'center',
    },
    secondaryButton: {
      backgroundColor: theme.colors.surfaceVariant,
      borderRadius: theme.borderRadius.md,
      paddingVertical: theme.spacing.sm,
      paddingHorizontal: theme.spacing.md,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    secondaryButtonText: {
      color: theme.colors.onSurface,
      fontWeight: '600',
      textAlign: 'center',
    },
    input: {
      backgroundColor: theme.colors.surface,
      borderColor: theme.colors.border,
      borderWidth: 1,
      borderRadius: theme.borderRadius.md,
      padding: theme.spacing.sm,
      color: theme.colors.onSurface,
      fontSize: theme.typography.fontSize.md,
      fontFamily: theme.typography.fontFamily,
    },
    text: {
      color: theme.colors.onBackground,
      fontSize: theme.typography.fontSize.md,
      fontFamily: theme.typography.fontFamily,
      lineHeight: theme.typography.fontSize.md * theme.typography.lineHeight.normal,
    },
    textSecondary: {
      color: theme.colors.onSurface,
      opacity: 0.7,
      fontSize: theme.typography.fontSize.sm,
      fontFamily: theme.typography.fontFamily,
    },
    heading: {
      color: theme.colors.onBackground,
      fontSize: theme.typography.fontSize.xl,
      fontFamily: theme.typography.fontFamily,
      fontWeight: '700',
    },
    subheading: {
      color: theme.colors.onSurface,
      fontSize: theme.typography.fontSize.lg,
      fontFamily: theme.typography.fontFamily,
      fontWeight: '600',
    },
    divider: {
      height: 1,
      backgroundColor: theme.colors.divider,
      marginVertical: theme.spacing.md,
    },
    card: {
      backgroundColor: theme.colors.surface,
      borderRadius: theme.borderRadius.lg,
      padding: theme.spacing.md,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
    shadow: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
      elevation: 3,
    },
  }), [theme]);

  return {
    theme,
    resolvedTheme,
    systemTheme,
    styles,
    updateTheme,
    setThemeMode,
    setCustomTheme,
    colors: theme.colors,
    spacing: theme.spacing,
    typography: theme.typography,
    borderRadius: theme.borderRadius,
    shadows: theme.shadows,
    animations: theme.animations,
  };
}

export function useColorScheme() {
  const { resolvedTheme } = useTheme();
  return resolvedTheme;
}

export function useThemeColors() {
  const { colors } = useTheme();
  return colors;
}

export function useThemeSpacing() {
  const { spacing } = useTheme();
  return spacing;
}

export function useThemeTypography() {
  const { typography } = useTheme();
  return typography;
}