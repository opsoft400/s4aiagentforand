import { useState, useEffect, useCallback, useRef } from 'react';
import { useAppStore } from '@/store';
import { fileSystemService } from '@/services';
import type { FileNode } from '@/types';

export function useFileSystem(basePath?: string) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { currentProject, setFileTree, setCurrentProject } = useAppStore();

  const loadProject = useCallback(async (path: string) => {
    setIsLoading(true);
    setError(null);
    try {
      fileSystemService.setBasePath(path);
      const tree = await fileSystemService.listDirectory('', true);
      const rootNode: FileNode = {
        id: 'root',
        name: path.split('/').pop() || 'Project',
        path: '',
        type: 'folder',
        children: tree,
        isExpanded: true,
        modifiedAt: new Date(),
        createdAt: new Date(),
      };
      setFileTree(rootNode);
      setCurrentProject(path);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load project');
    } finally {
      setIsLoading(false);
    }
  }, [setFileTree, setCurrentProject]);

  const createFile = useCallback(async (path: string, content = '') => {
    try {
      await fileSystemService.writeFile(path, content);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create file');
      return false;
    }
  }, []);

  const createFolder = useCallback(async (path: string) => {
    try {
      await fileSystemService.createDirectory(path);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create folder');
      return false;
    }
  }, []);

  const deleteItem = useCallback(async (path: string, recursive = false) => {
    try {
      await fileSystemService.deleteFile(path, recursive);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete');
      return false;
    }
  }, []);

  const renameItem = useCallback(async (oldPath: string, newPath: string) => {
    try {
      await fileSystemService.moveFile(oldPath, newPath);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to rename');
      return false;
    }
  }, []);

  const readFile = useCallback(async (path: string, encoding: 'utf-8' | 'base64' = 'utf-8') => {
    try {
      return await fileSystemService.readFile(path, encoding);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read file');
      return null;
    }
  }, []);

  const writeFile = useCallback(async (path: string, content: string, encoding: 'utf-8' | 'base64' = 'utf-8') => {
    try {
      await fileSystemService.writeFile(path, content, encoding);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to write file');
      return false;
    }
  }, []);

  const searchFiles = useCallback(async (query: string, path: string, type: 'name' | 'content' | 'both' = 'both') => {
    try {
      return await fileSystemService.searchFiles(query, path, type);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Search failed');
      return [];
    }
  }, []);

  const downloadFile = useCallback(async (url: string, path: string) => {
    try {
      await fileSystemService.downloadFile(url, path);
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Download failed');
      return false;
    }
  }, []);

  const zipFiles = useCallback(async (files: string[], outputPath: string, options = {}) => {
    try {
      return await fileSystemService.zipFiles(files, outputPath, options);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Zip failed');
      return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
    }
  }, []);

  const unzipFile = useCallback(async (zipPath: string, outputPath: string, password?: string) => {
    try {
      return await fileSystemService.unzipFile(zipPath, outputPath, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unzip failed');
      return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
    }
  }, []);

  const runCommand = useCallback(async (command: string, cwd?: string) => {
    try {
      return await fileSystemService.runCommand(command, cwd);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Command failed');
      return { stdout: '', stderr: err instanceof Error ? err.message : 'Unknown error', exitCode: 1 };
    }
  }, []);

  return {
    isLoading,
    error,
    currentProject,
    loadProject,
    createFile,
    createFolder,
    deleteItem,
    renameItem,
    readFile,
    writeFile,
    searchFiles,
    downloadFile,
    zipFiles,
    unzipFile,
    runCommand,
    clearError: () => setError(null),
  };
}

export function useFileWatcher(path: string, callback: (event: { type: string; path: string }) => void) {
  const cleanupRef = useRef<() => void>();

  useEffect(() => {
    if (!path) return;
    
    fileSystemService.watchDirectory(path, callback).then((cleanup) => {
      cleanupRef.current = cleanup;
    });

    return () => {
      cleanupRef.current?.();
    };
  }, [path, callback]);
}

export function useRecentFiles() {
  const [recentFiles, setRecentFiles] = useState<string[]>([]);

  useEffect(() => {
    // Load from storage
    const loadRecent = async () => {
      // Implementation would load from AsyncStorage
    };
    loadRecent();
  }, []);

  const addRecentFile = useCallback((path: string) => {
    setRecentFiles((prev) => {
      const filtered = prev.filter((p) => p !== path);
      return [path, ...filtered].slice(0, 20);
    });
  }, []);

  const removeRecentFile = useCallback((path: string) => {
    setRecentFiles((prev) => prev.filter((p) => p !== path));
  }, []);

  return { recentFiles, addRecentFile, removeRecentFile };
}

export function useFileBookmarks() {
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  useEffect(() => {
    // Load from storage
  }, []);

  const addBookmark = useCallback((path: string) => {
    setBookmarks((prev) => {
      if (prev.includes(path)) return prev;
      return [...prev, path];
    });
  }, []);

  const removeBookmark = useCallback((path: string) => {
    setBookmarks((prev) => prev.filter((p) => p !== path));
  }, []);

  const toggleBookmark = useCallback((path: string) => {
    setBookmarks((prev) => {
      if (prev.includes(path)) {
        return prev.filter((p) => p !== path);
      }
      return [...prev, path];
    });
  }, []);

  return { bookmarks, addBookmark, removeBookmark, toggleBookmark };
}