import { makeRedirectUri, useAuthRequest, TokenResponse } from 'expo-auth-session';
import * as WebBrowser from 'expo-web-browser';
import { useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import { GitHubService, createGitHubService } from '@/services/github';
import type { GitHubUser, GitHubRepo } from '@/types';

WebBrowser.maybeCompleteAuthSession();

const GITHUB_CLIENT_ID = 'your-github-client-id'; // Replace with your GitHub OAuth App Client ID
const GITHUB_CLIENT_SECRET = 'your-github-client-secret'; // Replace with your GitHub OAuth App Client Secret
const GITHUB_REDIRECT_URI = makeRedirectUri({ scheme: 's4agent', path: 'auth' });

const STORAGE_KEYS = {
  GITHUB_TOKEN: 's4agent_github_token',
  GITHUB_USER: 's4agent_github_user',
  GITHUB_REPOS: 's4agent_github_repos',
};

export interface GitHubAuthState {
  isAuthenticated: boolean;
  user: GitHubUser | null;
  token: string | null;
  repos: GitHubRepo[];
  isLoading: boolean;
  error: string | null;
}

export function useGitHubAuth() {
  const [state, setState] = useState<GitHubAuthState>({
    isAuthenticated: false,
    user: null,
    token: null,
    repos: [],
    isLoading: true,
    error: null,
  });

  const [request, response, promptAsync] = useAuthRequest(
    {
      clientId: GITHUB_CLIENT_ID,
      redirectUri: GITHUB_REDIRECT_URI,
      scopes: ['repo', 'user', 'read:org', 'workflow'],
      responseType: 'code',
      usePKCE: true,
    },
    {
      authorizationEndpoint: 'https://github.com/login/oauth/authorize',
      tokenEndpoint: 'https://github.com/login/oauth/access_token',
    }
  );

  useEffect(() => {
    loadStoredAuth();
  }, []);

  useEffect(() => {
    if (response?.type === 'success') {
      exchangeCodeForToken(response.params.code);
    } else if (response?.type === 'error') {
      setState((prev) => ({ ...prev, error: response.error.message, isLoading: false }));
    }
  }, [response]);

  const loadStoredAuth = async () => {
    try {
      const [token, userStr, reposStr] = await Promise.all([
        SecureStore.getItemAsync(STORAGE_KEYS.GITHUB_TOKEN),
        SecureStore.getItemAsync(STORAGE_KEYS.GITHUB_USER),
        SecureStore.getItemAsync(STORAGE_KEYS.GITHUB_REPOS),
      ]);

      if (token && userStr) {
        const user = JSON.parse(userStr);
        const repos = reposStr ? JSON.parse(reposStr) : [];
        
        // Verify token is still valid
        const service = createGitHubService(token);
        const isValid = await service.checkAuth();
        
        if (isValid) {
          setState({
            isAuthenticated: true,
            user,
            token,
            repos,
            isLoading: false,
            error: null,
          });
        } else {
          await clearAuth();
        }
      } else {
        setState((prev) => ({ ...prev, isLoading: false }));
      }
    } catch (error) {
      console.error('Failed to load stored auth:', error);
      setState((prev) => ({ ...prev, isLoading: false }));
    }
  };

  const exchangeCodeForToken = async (code: string) => {
    setState((prev) => ({ ...prev, isLoading: true, error: null }));
    
    try {
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: GITHUB_CLIENT_ID,
          client_secret: GITHUB_CLIENT_SECRET,
          code,
          redirect_uri: GITHUB_REDIRECT_URI,
        }),
      });

      const tokenData = await tokenResponse.json();

      if (tokenData.error) {
        throw new Error(tokenData.error_description || 'Failed to exchange code');
      }

      const accessToken = tokenData.access_token;
      
      // Get user info
      const service = createGitHubService(accessToken);
      const user = await service.getUser();
      const repos = await service.getRepos();

      // Store securely
      await Promise.all([
        SecureStore.setItemAsync(STORAGE_KEYS.GITHUB_TOKEN, accessToken),
        SecureStore.setItemAsync(STORAGE_KEYS.GITHUB_USER, JSON.stringify(user)),
        SecureStore.setItemAsync(STORAGE_KEYS.GITHUB_REPOS, JSON.stringify(repos)),
      ]);

      setState({
        isAuthenticated: true,
        user,
        token: accessToken,
        repos,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Authentication failed',
      }));
    }
  };

  const login = async () => {
    setState((prev) => ({ ...prev, error: null }));
    await promptAsync();
  };

  const logout = async () => {
    await clearAuth();
    setState({
      isAuthenticated: false,
      user: null,
      token: null,
      repos: [],
      isLoading: false,
      error: null,
    });
  };

  const clearAuth = async () => {
    await Promise.all([
      SecureStore.deleteItemAsync(STORAGE_KEYS.GITHUB_TOKEN),
      SecureStore.deleteItemAsync(STORAGE_KEYS.GITHUB_USER),
      SecureStore.deleteItemAsync(STORAGE_KEYS.GITHUB_REPOS),
    ]);
  };

  const refreshRepos = async () => {
    if (!state.token) return;
    
    try {
      const service = createGitHubService(state.token);
      const repos = await service.getRepos();
      await SecureStore.setItemAsync(STORAGE_KEYS.GITHUB_REPOS, JSON.stringify(repos));
      setState((prev) => ({ ...prev, repos }));
    } catch (error) {
      console.error('Failed to refresh repos:', error);
    }
  };

  const getService = () => {
    if (!state.token) return null;
    return createGitHubService(state.token);
  };

  return {
    ...state,
    login,
    logout,
    refreshRepos,
    getService,
    isReady: !state.isLoading,
  };
}

import { useState } from 'react';