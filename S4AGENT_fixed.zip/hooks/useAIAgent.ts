import { useState, useCallback, useRef, useEffect } from 'react';
import { useAppStore } from '@/store';
import { AIAgentService, createAIAgent } from '@/services/ai-agent';
import type { AIMessage, AgentConfig, ToolCall } from '@/types';

export function useAIAgent() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { agentConfig, setAgentConfig, chatHistory, addChatMessage, updateChatMessage } = useAppStore();
  
  const agentRef = useRef<AIAgentService | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    agentRef.current = createAIAgent(agentConfig);
    
    agentRef.current.setCallbacks({
      onToolCall: (toolCall) => {
        console.log('Tool call:', toolCall);
      },
      onToolResult: (result) => {
        console.log('Tool result:', result);
      },
      onMessage: (message) => {
        updateChatMessage(message.id, { content: message.content });
      },
    });

    return () => {
      agentRef.current?.abort();
    };
  }, [agentConfig, updateChatMessage]);

  const sendMessage = useCallback(async (content: string) => {
    if (!agentRef.current || isProcessing) return;

    setIsProcessing(true);
    setError(null);

    const userMessage: AIMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content,
      timestamp: new Date(),
    };

    addChatMessage(userMessage);

    const assistantMessageId = crypto.randomUUID();
    const assistantMessage: AIMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      timestamp: new Date(),
    };
    addChatMessage(assistantMessage);

    try {
      abortControllerRef.current = new AbortController();
      
      const response = await agentRef.current.sendMessage(
        [...chatHistory, userMessage],
        agentConfig.tools
      );

      updateChatMessage(assistantMessageId, {
        content: response.content,
        toolCalls: response.toolCalls,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send message');
      updateChatMessage(assistantMessageId, {
        content: `Error: ${err instanceof Error ? err.message : 'Unknown error'}`,
      });
    } finally {
      setIsProcessing(false);
    }
  }, [isProcessing, chatHistory, agentConfig.tools, addChatMessage, updateChatMessage]);

  const abort = useCallback(() => {
    agentRef.current?.abort();
    abortControllerRef.current?.abort();
    setIsProcessing(false);
  }, []);

  const updateConfig = useCallback((config: Partial<AgentConfig>) => {
    setAgentConfig(config);
    agentRef.current?.setConfig(config);
  }, [setAgentConfig]);

  const checkConnection = useCallback(async () => {
    return agentRef.current?.checkConnection() ?? false;
  }, []);

  const clearHistory = useCallback(() => {
    // This would need to be implemented in store
  }, []);

  return {
    isProcessing,
    error,
    config: agentConfig,
    sendMessage,
    abort,
    updateConfig,
    checkConnection,
    clearError: () => setError(null),
  };
}

export function useAIToolExecution() {
  const [pendingTools, setPendingTools] = useState<ToolCall[]>([]);
  const [toolResults, setToolResults] = useState<Map<string, any>>(new Map());

  const executeTool = useCallback(async (toolCall: ToolCall) => {
    setPendingTools((prev) => [...prev, toolCall]);
    
    // Tool execution would happen in the agent service
    // This hook is for UI to show pending/running tools
  }, []);

  const completeTool = useCallback((toolCallId: string, result: any) => {
    setPendingTools((prev) => prev.filter((t) => t.id !== toolCallId));
    setToolResults((prev) => {
      const next = new Map(prev);
      next.set(toolCallId, result);
      return next;
    });
  }, []);

  const clearResults = useCallback(() => {
    setToolResults(new Map());
  }, []);

  return {
    pendingTools,
    toolResults,
    executeTool,
    completeTool,
    clearResults,
  };
}

export function useStreamingResponse() {
  const [chunks, setChunks] = useState<string[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const fullContentRef = useRef('');

  const startStream = useCallback(() => {
    setChunks([]);
    fullContentRef.current = '';
    setIsStreaming(true);
  }, []);

  const addChunk = useCallback((chunk: string) => {
    fullContentRef.current += chunk;
    setChunks((prev) => [...prev, chunk]);
  }, []);

  const endStream = useCallback(() => {
    setIsStreaming(false);
  }, []);

  const getFullContent = useCallback(() => fullContentRef.current, []);

  const clear = useCallback(() => {
    setChunks([]);
    fullContentRef.current = '';
    setIsStreaming(false);
  }, []);

  return {
    chunks,
    isStreaming,
    fullContent: fullContentRef.current,
    startStream,
    addChunk,
    endStream,
    getFullContent,
    clear,
  };
}