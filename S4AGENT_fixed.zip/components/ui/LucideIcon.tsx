import React from 'react';
import { Svg, Path, Circle, Rect, Line, Polyline, Polygon, Text, ViewStyle } from 'react-native-svg';
import { useTheme } from '@/hooks';

interface LucideIconProps {
  name: string;
  size?: number;
  color?: string;
  strokeWidth?: number;
  opacity?: number;
  style?: ViewStyle;
}

const icons: Record<string, React.ReactElement<any>> = {
  folder: (
    <Path
      d="M20 20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h10l4 4v10a2 2 0 0 1-2 2z"
      fill="none"
      stroke="currentColor"
    />
  ),
  'folder-open': (
    <>
      <Path
        d="M6 20V10a2 2 0 0 1 2-2h10l4 4v10a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2z"
        fill="none"
        stroke="currentColor"
      />
      <Path d="M6 20v-8a2 2 0 0 1 2-2h10l4 4v10" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),
  file: (
    <Path
      d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"
      fill="none"
      stroke="currentColor"
    />
  ),
  'file-code': (
    <>
      <Path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" />
      <Polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" />
      <Line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" />
      <Line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" />
      <Polyline points="10 9 9 12 10 15" fill="none" stroke="currentColor" />
    </>
  ),
  'file-json': (
    <>
      <Path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" />
      <Polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" />
      <Text x="8" y="16" fontSize="8" textAnchor="middle" fill="currentColor">{</Text>
      <Text x="16" y="16" fontSize="8" textAnchor="middle" fill="currentColor">}</Text>
    </>
  ),
  'file-text': (
    <>
      <Path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" />
      <Polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" />
      <Line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" />
      <Line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" />
      <Line x1="10" y1="9" x2="8" y2="9" stroke="currentColor" />
    </>
  ),
  image: (
    <>
      <Rect x="3" y="3" width="18" height="18" rx="2" ry="2" fill="none" stroke="currentColor" />
      <Circle cx="8.5" cy="8.5" r="1.5" fill="currentColor" />
      <Polyline points="21 15 16 10 5 21" fill="none" stroke="currentColor" />
    </>
  ),
  archive: (
    <>
      <Polyline points="21 8 21 21 3 21 3 8" fill="none" stroke="currentColor" />
      <Rect x="1" y="3" width="22" height="5" fill="none" stroke="currentColor" />
      <Line x1="10" y1="12" x2="14" y2="12" stroke="currentColor" />
    </>
  ),
  'more-vertical': (
    <>
      <Circle cx="12" cy="12" r="1" fill="currentColor" />
      <Circle cx="12" cy="5" r="1" fill="currentColor" />
      <Circle cx="12" cy="19" r="1" fill="currentColor" />
    </>
  ),
  'chevron-right': (
    <Polyline points="9 18 15 12 9 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  ),
  'chevron-down': (
    <Polyline points="6 9 12 15 18 9" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  ),
  'chevron-left': (
    <Polyline points="15 18 9 12 15 6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  ),
  'chevron-up': (
    <Polyline points="18 15 12 9 6 15" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  ),
  'plus': (
    <>
      <Line x1="12" y1="5" x2="12" y2="19" stroke="currentColor" />
      <Line x1="5" y1="12" x2="19" y2="12" stroke="currentColor" />
    </>
  ),
  'minus': (
    <Line x1="5" y1="12" x2="19" y2="12" stroke="currentColor" />
  ),
  'x': (
    <>
      <Line x1="18" y1="6" x2="6" y2="18" stroke="currentColor" />
      <Line x1="6" y1="6" x2="18" y2="18" stroke="currentColor" />
    </>
  ),
  'check': (
    <Polyline points="20 6 9 17 4 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  ),
  'download': (
    <>
      <Path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" fill="none" stroke="currentColor" />
      <Polyline points="7 10 12 15 17 10" fill="none" stroke="currentColor" />
      <Line x1="12" y1="15" x2="12" y2="3" stroke="currentColor" />
    </>
  ),
  'upload': (
    <>
      <Path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" fill="none" stroke="currentColor" />
      <Polyline points="17 8 12 3 7 8" fill="none" stroke="currentColor" />
      <Line x1="12" y1="3" x2="12" y2="15" stroke="currentColor" />
    </>
  ),
  search: (
    <>
      <Circle cx="11" cy="11" r="8" fill="none" stroke="currentColor" />
      <Line x1="21" y1="21" x2="16.65" y2="16.65" stroke="currentColor" />
    </>
  ),
  settings: (
    <Circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" />
  ),
  home: (
    <>
      <Path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" fill="none" stroke="currentColor" />
      <Polyline points="9 22 9 12 15 12 15 22" fill="none" stroke="currentColor" />
    </>
  ),
  terminal: (
    <>
      <Polyline points="4 17 10 11 4 5" fill="none" stroke="currentColor" />
      <Line x1="12" y1="19" x2="20" y2="19" stroke="currentColor" />
    </>
  ),
  code: (
    <>
      <Polyline points="16 18 22 12 16 6" fill="none" stroke="currentColor" />
      <Polyline points="8 6 2 12 8 18" fill="none" stroke="currentColor" />
    </>
  ),
  git_branch: (
    <>
      <Line x1="6" y1="3" x2="6" y2="15" stroke="currentColor" />
      <Circle cx="18" cy="6" r="3" fill="currentColor" />
      <Circle cx="6" cy="18" r="3" fill="currentColor" />
      <Path d="M18 9a9 9 0 0 1-9 9" fill="none" stroke="currentColor" />
    </>
  ),
  github: (
    <Path
      d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"
      fill="none"
      stroke="currentColor"
    />
  ),
  refresh_cw: (
    <Polyline points="23 4 23 10 17 10" fill="none" stroke="currentColor" />
  ),
  save: (
    <>
      <Path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" fill="none" stroke="currentColor" />
      <Polyline points="17 21 17 13 7 13 7 21" fill="none" stroke="currentColor" />
      <Polyline points="7 3 7 8 15 8" fill="none" stroke="currentColor" />
    </>
  ),
  copy: (
    <>
      <Rect x="9" y="9" width="13" height="13" rx="2" ry="2" fill="none" stroke="currentColor" />
      <Path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" fill="none" stroke="currentColor" />
    </>
  ),
  edit: (
    <>
      <Path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" fill="none" stroke="currentColor" />
      <Path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" fill="none" stroke="currentColor" />
    </>
  ),
  trash: (
    <>
      <Polyline points="3 6 5 6 21 6" fill="none" stroke="currentColor" />
      <Path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" fill="none" stroke="currentColor" />
    </>
  ),
  duplicate: (
    <>
      <Rect x="3" y="3" width="10" height="10" rx="2" ry="2" fill="none" stroke="currentColor" />
      <Path d="M17 17H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2z" fill="none" stroke="currentColor" />
    </>
  ),
  rename: (
    <>
      <Path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" fill="none" stroke="currentColor" />
      <Path d="M15 5l4 4" fill="none" stroke="currentColor" />
    </>
  ),
  'file-plus': (
    <>
      <Path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" />
      <Polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" />
      <Line x1="12" y1="18" x2="12" y2="12" stroke="currentColor" />
      <Line x1="9" y1="15" x2="15" y2="15" stroke="currentColor" />
    </>
  ),
  'folder-plus': (
    <>
      <Path d="M20 20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h10l4 4v10a2 2 0 0 1-2 2z" fill="none" stroke="currentColor" />
      <Line x1="12" y1="14" x2="12" y2="10" stroke="currentColor" />
      <Line x1="10" y1="12" x2="14" y2="12" stroke="currentColor" />
    </>
  ),
  'file-minus': (
    <>
      <Path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" fill="none" stroke="currentColor" />
      <Polyline points="14 2 14 8 20 8" fill="none" stroke="currentColor" />
      <Line x1="9" y1="15" x2="15" y2="15" stroke="currentColor" />
    </>
  ),
  'folder-minus': (
    <>
      <Path d="M20 20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h10l4 4v10a2 2 0 0 1-2 2z" fill="none" stroke="currentColor" />
      <Line x1="10" y1="12" x2="14" y2="12" stroke="currentColor" />
    </>
  ),
};

export const LucideIcon = React.forwardRef<React.ElementRef<typeof Svg>, LucideIconProps>(
  ({ name, size = 24, color, strokeWidth = 2, opacity = 1, style }, ref) => {
    const { colors } = useTheme();
    const iconColor = color || colors.onSurface;

    const IconComponent = icons[name];

    if (!IconComponent) {
      console.warn(`Icon "${name}" not found`);
      return null;
    }

    return (
      <Svg
        ref={ref}
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke={iconColor}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        style={[{ opacity }, style]}
      >
        {IconComponent.props.children}
      </Svg>
    );
  }
);

LucideIcon.displayName = 'LucideIcon';

export const createLucideIcon = (name: string) => (props: Omit<LucideIconProps, 'name'>) =>
  <LucideIcon name={name} {...props} />;