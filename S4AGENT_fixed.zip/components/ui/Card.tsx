import React from 'react';
import { View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { useTheme } from '@/hooks';

interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'outlined' | 'elevated' | 'filled';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  onPress?: () => void;
  style?: ViewStyle;
}

export const Card = React.forwardRef<View, CardProps>(
  ({ children, variant = 'default', padding = 'md', onPress, style }, ref) => {
    const { theme, colors, spacing, borderRadius, shadows } = useTheme();

    const baseStyles = StyleSheet.create({
      card: {
        borderRadius: borderRadius.lg,
        ...style,
      },
      default: {
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
      },
      outlined: {
        backgroundColor: 'transparent',
        borderWidth: 2,
        borderColor: colors.border,
      },
      elevated: {
        backgroundColor: colors.surface,
        ...shadows.md,
      },
      filled: {
        backgroundColor: colors.surfaceVariant,
      },
      paddingNone: {},
      paddingSm: { padding: spacing.sm },
      paddingMd: { padding: spacing.md },
      paddingLg: { padding: spacing.lg },
      clickable: {
        ...shadows.sm,
      },
    });

    const Component = onPress ? Text : View;

    return (
      <Component
        ref={ref}
        style={[
          baseStyles.card,
          baseStyles[variant],
          baseStyles[`padding${padding.charAt(0).toUpperCase() + padding.slice(1)}`],
          onPress && baseStyles.clickable,
        ]}
        onPress={onPress}
        accessible={!!onPress}
        accessibilityRole={onPress ? 'button' : undefined}
      >
        {children}
      </Component>
    );
  }
);

Card.displayName = 'Card';

export const CardHeader = React.forwardRef<View, { children: React.ReactNode; style?: ViewStyle }>(
  ({ children, style }, ref) => {
    const { theme, spacing, typography } = useTheme();

    return (
      <View
        ref={ref}
        style={[
          {
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: spacing.sm,
            paddingBottom: spacing.sm,
            borderBottomWidth: 1,
            borderColor: theme.colors.divider,
          },
          style,
        ]}
      >
        {children}
      </View>
    );
  }
);

CardHeader.displayName = 'CardHeader';

export const CardTitle = ({ children, style }: { children: React.ReactNode; style?: TextStyle }) => {
  const { theme, typography } = useTheme();

  return (
    <Text
      style={[
        {
          fontSize: typography.fontSize.lg,
          fontFamily: typography.fontFamily,
          fontWeight: '600',
          color: theme.colors.onSurface,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
};

export const CardDescription = ({ children, style }: { children: React.ReactNode; style?: TextStyle }) => {
  const { theme, typography } = useTheme();

  return (
    <Text
      style={[
        {
          fontSize: typography.fontSize.sm,
          fontFamily: typography.fontFamily,
          color: theme.colors.onSurface,
          opacity: 0.7,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
};

export const CardContent = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => {
  const { spacing } = useTheme();

  return (
    <View style={[{ paddingVertical: spacing.sm }, style]}>{children}</View>
  );
};

export const CardFooter = ({ children, style }: { children: React.ReactNode; style?: ViewStyle }) => {
  const { theme, spacing } = useTheme();

  return (
    <View
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: spacing.sm,
          marginTop: spacing.sm,
          paddingTop: spacing.sm,
          borderTopWidth: 1,
          borderColor: theme.colors.divider,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
};