import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  FlatList,
  TextStyle,
  ViewStyle,
  Keyboard,
} from 'react-native';
import { useTheme } from '@/hooks';
import { Portal } from 'react-native-portalize';

interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
  icon?: React.ReactNode;
}

interface SelectProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[];
  error?: string;
  helperText?: string;
  disabled?: boolean;
  required?: boolean;
  searchable?: boolean;
  maxHeight?: number;
  style?: ViewStyle;
  containerStyle?: ViewStyle;
  inputStyle?: TextStyle;
  labelStyle?: TextStyle;
}

export const Select = React.forwardRef<View, SelectProps>(
  (
    {
      label,
      placeholder,
      value,
      onChange,
      options,
      error,
      helperText,
      disabled = false,
      required = false,
      searchable = false,
      maxHeight = 300,
      style,
      containerStyle,
      inputStyle,
      labelStyle,
    },
    ref
  ) => {
    const { theme, colors, spacing, typography, borderRadius, shadows } = useTheme();
    const [isOpen, setIsOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const dropdownRef = useRef<View>(null);
    const containerRef = useRef<View>(null);

    const filteredOptions = options.filter((option) =>
      option.label.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const selectedOption = options.find((o) => o.value === value);

    useEffect(() => {
      const handleClickOutside = (event: any) => {
        if (
          containerRef.current &&
          !containerRef.current.contains(event.target) &&
          dropdownRef.current &&
          !dropdownRef.current.contains(event.target)
        ) {
          setIsOpen(false);
          Keyboard.dismiss();
        }
      };

      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const baseStyles = StyleSheet.create({
      container: {
        width: '100%',
        gap: spacing.xs,
        ...containerStyle,
      },
      label: {
        fontSize: typography.fontSize.sm,
        fontFamily: typography.fontFamily,
        fontWeight: '500',
        color: colors.onSurface,
        ...labelStyle,
      },
      required: {
        color: colors.error,
        marginLeft: 2,
      },
      trigger: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: error ? colors.error : isOpen ? colors.primary : colors.border,
        borderRadius: borderRadius.md,
        paddingHorizontal: spacing.md,
        paddingVertical: spacing.sm,
        minHeight: 48,
        ...(disabled && { opacity: 0.6 }),
        ...style,
      },
      triggerText: {
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        color: value ? colors.onSurface : colors.onSurface,
        opacity: value ? 1 : 0.5,
        flex: 1,
        ...inputStyle,
      },
      chevron: {
        fontSize: typography.fontSize.md,
        color: colors.onSurface,
        opacity: 0.5,
        marginLeft: spacing.sm,
      },
      dropdown: {
        position: 'absolute',
        top: '100%',
        left: 0,
        right: 0,
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: borderRadius.md,
        marginTop: spacing.xs,
        maxHeight,
        ...shadows.lg,
        zIndex: 1000,
      },
      searchInput: {
        padding: spacing.sm,
        borderBottomWidth: 1,
        borderColor: colors.divider,
      },
      option: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: spacing.md,
        gap: spacing.sm,
      },
      optionSelected: {
        backgroundColor: colors.primary,
        opacity: 0.1,
      },
      optionDisabled: {
        opacity: 0.5,
      },
      optionText: {
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        flex: 1,
      },
      optionTextSelected: {
        color: colors.primary,
        fontWeight: '600',
      },
      divider: {
        height: 1,
        backgroundColor: colors.divider,
        marginHorizontal: spacing.md,
      },
      errorText: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.error,
      },
      helperText: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.6,
      },
    });

    if (disabled) {
      return (
        <View style={[baseStyles.container, containerStyle]}>
          {label && (
            <Text style={[baseStyles.label, labelStyle]}>
              {label}
              {required && <Text style={baseStyles.required}>*</Text>}
            </Text>
          )}
          <View style={baseStyles.trigger}>
            <Text style={baseStyles.triggerText}>
              {selectedOption?.label || placeholder}
            </Text>
          </View>
          {error && <Text style={baseStyles.errorText}>{error}</Text>}
          {!error && helperText && <Text style={baseStyles.helperText}>{helperText}</Text>}
        </View>
      );
    }

    return (
      <View ref={containerRef} style={[baseStyles.container, containerStyle]}>
        {label && (
          <Text style={[baseStyles.label, labelStyle]}>
            {label}
            {required && <Text style={baseStyles.required}>*</Text>}
          </Text>
        )}
        <TouchableWithoutFeedback onPress={() => setIsOpen(!isOpen)}>
          <View style={baseStyles.trigger}>
            <Text style={baseStyles.triggerText}>
              {selectedOption?.label || placeholder}
            </Text>
            <Text style={baseStyles.chevron}>{isOpen ? '▲' : '▼'}</Text>
          </View>
        </TouchableWithoutFeedback>
        {isOpen && (
          <Portal>
            <View ref={dropdownRef} style={baseStyles.dropdown}>
              {searchable && (
                <View style={baseStyles.searchInput}>
                  <Input
                    placeholder="Search..."
                    value={searchQuery}
                    onChangeText={setSearchQuery}
                    inputStyle={{ padding: 0 }}
                  />
                </View>
              )}
              <FlatList
                data={filteredOptions}
                keyExtractor={(item) => item.value}
                renderItem={({ item }) => (
                  <TouchableWithoutFeedback
                    onPress={() => {
                      if (!item.disabled) {
                        onChange(item.value);
                        setIsOpen(false);
                      }
                    }}
                  >
                    <View
                      style={[
                        baseStyles.option,
                        item.value === value && baseStyles.optionSelected,
                        item.disabled && baseStyles.optionDisabled,
                      ]}
                    >
                      {item.icon && <View>{item.icon}</View>}
                      <Text
                        style={[
                          baseStyles.optionText,
                          item.value === value && baseStyles.optionTextSelected,
                        ]}
                      >
                        {item.label}
                      </Text>
                    </View>
                  </TouchableWithoutFeedback>
                )}
                ItemSeparatorComponent={() => <View style={baseStyles.divider} />}
                ListEmptyComponent={
                  <View style={{ padding: spacing.md, alignItems: 'center' }}>
                    <Text style={{ color: colors.onSurface, opacity: 0.5 }}>
                      No options found
                    </Text>
                  </View>
                }
              />
            </View>
          </Portal>
        )}
        {error && <Text style={baseStyles.errorText}>{error}</Text>}
        {!error && helperText && <Text style={baseStyles.helperText}>{helperText}</Text>}
      </View>
    );
  }
);

Select.displayName = 'Select';

import { Input } from './Input';