import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '@/hooks';
import { LucideIcon } from '@/components/ui/LucideIcon';

interface TabBarProps {
  tabs: Array<{
    id: string;
    label: string;
    icon: string;
    badge?: number;
  }>;
  activeTab: string;
  onTabPress: (tabId: string) => void;
  style?: ViewStyle;
}

export const TabBar = React.forwardRef<View, TabBarProps>(
  ({ tabs, activeTab, onTabPress, style }, ref) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const baseStyles = StyleSheet.create({
      container: {
        flexDirection: 'row',
        backgroundColor: colors.surface,
        borderTopWidth: 1,
        borderTopColor: colors.border,
        paddingBottom: spacing.sm,
        paddingTop: spacing.xs,
        paddingHorizontal: spacing.sm,
        ...style,
      },
      tab: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: spacing.xs,
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.md,
        borderRadius: borderRadius.md,
      },
      tabActive: {
        backgroundColor: colors.primary,
        opacity: 0.1,
      },
      tabLabel: {
        fontSize: typography.fontSize.sm,
        fontFamily: typography.fontFamily,
        fontWeight: '500',
        color: colors.onSurface,
      },
      tabLabelActive: {
        color: colors.primary,
        fontWeight: '600',
      },
      badge: {
        position: 'absolute',
        top: -4,
        right: -4,
        minWidth: 16,
        height: 16,
        borderRadius: 8,
        backgroundColor: colors.error,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 4,
      },
      badgeText: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        fontWeight: '600',
        color: colors.onPrimary,
      },
    });

    return (
      <View ref={ref} style={baseStyles.container}>
        {tabs.map((tab) => (
          <TouchableWithoutFeedback
            key={tab.id}
            onPress={() => onTabPress(tab.id)}
            accessibilityRole="tab"
            accessibilitySelected={activeTab === tab.id}
            accessibilityLabel={tab.label}
          >
            <View
              style={[
                baseStyles.tab,
                activeTab === tab.id && baseStyles.tabActive,
              ]}
            >
              <LucideIcon
                name={tab.icon}
                size={20}
                color={activeTab === tab.id ? colors.primary : colors.onSurface}
                opacity={activeTab === tab.id ? 1 : 0.6}
              />
              <Text
                style={[
                  baseStyles.tabLabel,
                  activeTab === tab.id && baseStyles.tabLabelActive,
                ]}
              >
                {tab.label}
              </Text>
              {tab.badge && tab.badge > 0 && (
                <View style={baseStyles.badge}>
                  <Text style={baseStyles.badgeText}>
                    {tab.badge > 99 ? '99+' : tab.badge}
                  </Text>
                </View>
              )}
            </View>
          </TouchableWithoutFeedback>
        ))}
      </View>
    );
  }
);

TabBar.displayName = 'TabBar';

import { TouchableWithoutFeedback } from 'react-native';