import React, { useEffect } from 'react';
import {
  Modal as RNModal,
  View,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
  TouchableWithoutFeedback,
  Keyboard,
  BackHandler,
} from 'react-native';
import { useTheme } from '@/hooks';
import { Portal } from 'react-native-portalize';

interface ModalProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  description?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  closeOnOverlayClick?: boolean;
  closeOnBack?: boolean;
  hideCloseButton?: boolean;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
}

export const Modal = React.forwardRef<RNModal, ModalProps>(
  (
    {
      visible,
      onClose,
      title,
      description,
      children,
      size = 'md',
      closeOnOverlayClick = true,
      closeOnBack = true,
      hideCloseButton = false,
      style,
      contentStyle,
    },
    ref
  ) => {
    const { theme, colors, spacing, typography, borderRadius, shadows } = useTheme();

    useEffect(() => {
      const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
        if (visible && closeOnBack) {
          onClose();
          return true;
        }
        return false;
      });
      return () => backHandler.remove();
    }, [visible, closeOnBack, onClose]);

    const baseStyles = StyleSheet.create({
      overlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
        padding: spacing.md,
      },
      container: {
        backgroundColor: colors.surface,
        borderRadius: borderRadius.xl,
        width: '100%',
        maxHeight: '90%',
        ...shadows.xl,
      },
      sm: { maxWidth: 320 },
      md: { maxWidth: 480 },
      lg: { maxWidth: 640 },
      xl: { maxWidth: 800 },
      full: { maxWidth: '100%', height: '100%', borderRadius: 0 },
      header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: spacing.md,
        borderBottomWidth: 1,
        borderColor: colors.divider,
      },
      title: {
        fontSize: typography.fontSize.lg,
        fontFamily: typography.fontFamily,
        fontWeight: '600',
        color: colors.onSurface,
        flex: 1,
      },
      description: {
        fontSize: typography.fontSize.sm,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.7,
        marginTop: spacing.xs,
      },
      closeButton: {
        padding: spacing.xs,
        borderRadius: borderRadius.md,
      },
      closeButtonText: {
        fontSize: typography.fontSize.xl,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.6,
      },
      content: {
        padding: spacing.md,
        maxHeight: '70%',
      },
    });

    if (!visible) return null;

    return (
      <Portal>
        <RNModal
          ref={ref}
          visible={visible}
          transparent
          animationType="fade"
          onRequestClose={closeOnBack ? onClose : undefined}
        >
          <TouchableWithoutFeedback
            onPress={closeOnOverlayClick ? onClose : undefined}
            accessible={false}
          >
            <View style={baseStyles.overlay}>
              <View
                style={[
                  baseStyles.container,
                  baseStyles[size],
                  style,
                ]}
                onPress={(e) => e.stopPropagation()}
              >
                {(title || !hideCloseButton) && (
                  <View style={baseStyles.header}>
                    <View style={{ flex: 1 }}>
                      {title && <Text style={baseStyles.title}>{title}</Text>}
                      {description && <Text style={baseStyles.description}>{description}</Text>}
                    </View>
                    {!hideCloseButton && (
                      <TouchableWithoutFeedback onPress={onClose}>
                        <View style={baseStyles.closeButton}>
                          <Text style={baseStyles.closeButtonText}>×</Text>
                        </View>
                      </TouchableWithoutFeedback>
                    )}
                  </View>
                )}
                <View
                  style={[
                    baseStyles.content,
                    contentStyle,
                  ]}
                >
                  {children}
                </View>
              </View>
            </View>
          </TouchableWithoutFeedback>
        </RNModal>
      </Portal>
    );
  }
);

Modal.displayName = 'Modal';

export const AlertModal = ({
  visible,
  onClose,
  title,
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  onConfirm,
  variant: _variant = 'default',
}: {
  visible: boolean;
  onClose: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  onConfirm: () => void;
  variant?: 'default' | 'danger';
}) => {
  const { theme, colors } = useTheme();

  return (
    <Modal
      visible={visible}
      onClose={onClose}
      title={title}
      size="sm"
    >
      <Text style={{ 
        color: theme.colors.onSurface, 
        fontSize: theme.typography.fontSize.md,
        fontFamily: theme.typography.fontFamily,
        lineHeight: theme.typography.fontSize.md * 1.5,
        marginBottom: theme.spacing.lg,
      }}>
        {message}
      </Text>
      <View style={{ flexDirection: 'row', justifyContent: 'flex-end', gap: theme.spacing.sm }}>
        <Button
          title={cancelText}
          variant="ghost"
          onPress={onClose}
        />
        <Button
          title={confirmText}
          variant={_variant === 'danger' ? 'danger' : 'primary'}
          onPress={() => {
            onConfirm();
            onClose();
          }}
        />
      </View>
    </Modal>
  );
};

import { Button } from './Button';