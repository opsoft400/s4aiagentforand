import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { useTheme } from '@/hooks';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  fullWidth?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export const Button = React.forwardRef<TouchableOpacity, ButtonProps>(
  (
    {
      title,
      onPress,
      variant = 'primary',
      size = 'md',
      disabled = false,
      loading = false,
      leftIcon,
      rightIcon,
      fullWidth = false,
      style,
      textStyle,
    },
    ref
  ) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const baseStyles = StyleSheet.create({
      button: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: borderRadius.md,
        ...(fullWidth && { width: '100%' }),
      },
      sm: {
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.sm,
        gap: spacing.xs,
      },
      md: {
        paddingVertical: spacing.sm,
        paddingHorizontal: spacing.md,
        gap: spacing.sm,
      },
      lg: {
        paddingVertical: spacing.md,
        paddingHorizontal: spacing.lg,
        gap: spacing.sm,
      },
      primary: {
        backgroundColor: colors.primary,
      },
      secondary: {
        backgroundColor: colors.surfaceVariant,
        borderWidth: 1,
        borderColor: colors.border,
      },
      outline: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: colors.primary,
      },
      ghost: {
        backgroundColor: 'transparent',
      },
      danger: {
        backgroundColor: colors.error,
      },
      disabled: {
        opacity: 0.5,
      },
      text: {
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        fontWeight: '600',
      },
      textSm: {
        fontSize: typography.fontSize.sm,
      },
      textLg: {
        fontSize: typography.fontSize.lg,
      },
      primaryText: {
        color: colors.onPrimary,
      },
      secondaryText: {
        color: colors.onSurface,
      },
      outlineText: {
        color: colors.primary,
      },
      ghostText: {
        color: colors.onSurface,
      },
      dangerText: {
        color: colors.onPrimary,
      },
    });

    const getVariantStyles = () => {
      switch (variant) {
        case 'primary':
          return [baseStyles.primary, { text: baseStyles.primaryText }];
        case 'secondary':
          return [baseStyles.secondary, { text: baseStyles.secondaryText }];
        case 'outline':
          return [baseStyles.outline, { text: baseStyles.outlineText }];
        case 'ghost':
          return [baseStyles.ghost, { text: baseStyles.ghostText }];
        case 'danger':
          return [baseStyles.danger, { text: baseStyles.dangerText }];
        default:
          return [baseStyles.primary, { text: baseStyles.primaryText }];
      }
    };

    const [variantStyle, textVariantStyle] = getVariantStyles();
    const sizeStyle = baseStyles[size];

    return (
      <TouchableOpacity
        ref={ref}
        style={[
          baseStyles.button,
          sizeStyle,
          variantStyle,
          disabled && baseStyles.disabled,
          style,
        ]}
        onPress={onPress}
        disabled={disabled || loading}
        activeOpacity={0.8}
      >
        {loading ? (
          <Text style={[baseStyles.text, textVariantStyle.text, sizeStyle, textStyle]}>Loading...</Text>
        ) : (
          <>
            {leftIcon && <React.Fragment>{leftIcon}</React.Fragment>}
            <Text style={[baseStyles.text, textVariantStyle.text, sizeStyle, textStyle]}>{title}</Text>
            {rightIcon && <React.Fragment>{rightIcon}</React.Fragment>}
          </>
        )}
      </TouchableOpacity>
    );
  }
);

Button.displayName = 'Button';