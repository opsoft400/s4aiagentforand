import React from 'react';
import { TextInput, View, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { useTheme } from '@/hooks';

interface InputProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChangeText: (text: string) => void;
  onBlur?: () => void;
  onFocus?: () => void;
  error?: string;
  helperText?: string;
  disabled?: boolean;
  required?: boolean;
  multiline?: boolean;
  numberOfLines?: number;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'numeric' | 'email-address' | 'url' | 'phone-pad';
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: ViewStyle;
  inputStyle?: TextStyle;
  labelStyle?: TextStyle;
  containerStyle?: ViewStyle;
}

export const Input = React.forwardRef<TextInput, InputProps>(
  (
    {
      label,
      placeholder,
      value,
      onChangeText,
      onBlur,
      onFocus,
      error,
      helperText,
      disabled = false,
      required = false,
      multiline = false,
      numberOfLines = 1,
      secureTextEntry = false,
      keyboardType = 'default',
      leftIcon,
      rightIcon,
      style,
      inputStyle,
      labelStyle,
      containerStyle,
    },
    ref
  ) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const baseStyles = StyleSheet.create({
      container: {
        width: '100%',
        gap: spacing.xs,
        ...containerStyle,
      },
      label: {
        fontSize: typography.fontSize.sm,
        fontFamily: typography.fontFamily,
        fontWeight: '500',
        color: colors.onSurface,
        ...labelStyle,
      },
      required: {
        color: colors.error,
        marginLeft: 2,
      },
      inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: error ? colors.error : colors.border,
        borderRadius: borderRadius.md,
        paddingHorizontal: spacing.md,
        ...(disabled && { opacity: 0.6 }),
      },
      inputWrapperFocused: {
        borderColor: colors.primary,
        borderWidth: 2,
      },
      icon: {
        marginRight: spacing.sm,
      },
      iconRight: {
        marginLeft: spacing.sm,
      },
      input: {
        flex: 1,
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        paddingVertical: multiline ? spacing.md : spacing.sm,
        ...inputStyle,
      },
      errorText: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.error,
      },
      helperText: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.6,
      },
    });

    const [isFocused, setIsFocused] = React.useState(false);

    return (
      <View style={baseStyles.container}>
        {label && (
          <Text style={baseStyles.label}>
            {label}
            {required && <Text style={baseStyles.required}>*</Text>}
          </Text>
        )}
        <View
          style={[
            baseStyles.inputWrapper,
            isFocused && baseStyles.inputWrapperFocused,
            style,
          ]}
        >
          {leftIcon && <View style={baseStyles.icon}>{leftIcon}</View>}
          <TextInput
            ref={ref}
            placeholder={placeholder}
            value={value}
            onChangeText={onChangeText}
            onBlur={() => {
              setIsFocused(false);
              onBlur?.();
            }}
            onFocus={() => {
              setIsFocused(true);
              onFocus?.();
            }}
            disabled={disabled}
            multiline={multiline}
            numberOfLines={numberOfLines}
            secureTextEntry={secureTextEntry}
            keyboardType={keyboardType}
            style={[
              baseStyles.input,
              { minHeight: multiline ? spacing.xl * 2 : undefined },
            ]}
          />
          {rightIcon && <View style={baseStyles.iconRight}>{rightIcon}</View>}
        </View>
        {error && <Text style={baseStyles.errorText}>{error}</Text>}
        {!error && helperText && <Text style={baseStyles.helperText}>{helperText}</Text>}
      </View>
    );
  }
);

Input.displayName = 'Input';