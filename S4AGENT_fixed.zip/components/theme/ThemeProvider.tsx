import React, { createContext, useContext, useMemo, ReactNode } from 'react';
import { StyleSheet, ViewStyle } from 'react-native';
import { DEFAULT_THEME, LIGHT_THEME, type ThemeConfig } from '@/constants';

interface ThemeContextValue {
  theme: ThemeConfig;
  resolvedTheme: 'light' | 'dark';
  setThemeMode: (mode: 'light' | 'dark' | 'system' | 'custom') => void;
  setCustomTheme: (theme: ThemeConfig) => void;
  styles: ReturnType<typeof StyleSheet.create>;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

interface ThemeProviderProps {
  children: ReactNode;
  initialTheme?: ThemeConfig;
  initialMode?: 'light' | 'dark' | 'system' | 'custom';
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  initialTheme = DEFAULT_THEME,
  initialMode = 'dark',
}) => {
  const [theme, setTheme] = React.useState<ThemeConfig>(initialTheme);
  const [mode, setMode] = React.useState<'light' | 'dark' | 'system' | 'custom'>(initialMode);
  const [resolvedTheme, setResolvedTheme] = React.useState<'light' | 'dark'>('dark');

  React.useEffect(() => {
    const updateResolved = () => {
      if (mode === 'system') {
        setResolvedTheme('dark'); // Would use Appearance.getColorScheme()
      } else if (mode === 'light') {
        setResolvedTheme('light');
      } else {
        setResolvedTheme('dark');
      }
    };
    updateResolved();
  }, [mode]);

  React.useEffect(() => {
    if (mode === 'custom') {
      setTheme(initialTheme);
    } else if (resolvedTheme === 'light') {
      setTheme(LIGHT_THEME);
    } else {
      setTheme(DEFAULT_THEME);
    }
  }, [mode, resolvedTheme, initialTheme]);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: theme.colors.background,
        },
        surface: {
          backgroundColor: theme.colors.surface,
          borderRadius: theme.borderRadius.md,
          padding: theme.spacing.md,
        },
        surfaceVariant: {
          backgroundColor: theme.colors.surfaceVariant,
          borderRadius: theme.borderRadius.md,
          padding: theme.spacing.md,
        },
        primaryButton: {
          backgroundColor: theme.colors.primary,
          borderRadius: theme.borderRadius.md,
          paddingVertical: theme.spacing.sm,
          paddingHorizontal: theme.spacing.md,
        },
        primaryButtonText: {
          color: theme.colors.onPrimary,
          fontWeight: '600',
          textAlign: 'center',
        },
        secondaryButton: {
          backgroundColor: theme.colors.surfaceVariant,
          borderRadius: theme.borderRadius.md,
          paddingVertical: theme.spacing.sm,
          paddingHorizontal: theme.spacing.md,
          borderWidth: 1,
          borderColor: theme.colors.border,
        },
        secondaryButtonText: {
          color: theme.colors.onSurface,
          fontWeight: '600',
          textAlign: 'center',
        },
        input: {
          backgroundColor: theme.colors.surface,
          borderColor: theme.colors.border,
          borderWidth: 1,
          borderRadius: theme.borderRadius.md,
          padding: theme.spacing.sm,
          color: theme.colors.onSurface,
          fontSize: theme.typography.fontSize.md,
          fontFamily: theme.typography.fontFamily,
        },
        text: {
          color: theme.colors.onBackground,
          fontSize: theme.typography.fontSize.md,
          fontFamily: theme.typography.fontFamily,
          lineHeight: theme.typography.fontSize.md * theme.typography.lineHeight.normal,
        },
        textSecondary: {
          color: theme.colors.onSurface,
          opacity: 0.7,
          fontSize: theme.typography.fontSize.sm,
          fontFamily: theme.typography.fontFamily,
        },
        heading: {
          color: theme.colors.onBackground,
          fontSize: theme.typography.fontSize.xl,
          fontFamily: theme.typography.fontFamily,
          fontWeight: '700',
        },
        subheading: {
          color: theme.colors.onSurface,
          fontSize: theme.typography.fontSize.lg,
          fontFamily: theme.typography.fontFamily,
          fontWeight: '600',
        },
        divider: {
          height: 1,
          backgroundColor: theme.colors.divider,
          marginVertical: theme.spacing.md,
        },
        card: {
          backgroundColor: theme.colors.surface,
          borderRadius: theme.borderRadius.lg,
          padding: theme.spacing.md,
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        },
        shadow: {
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        },
      }),
    [theme]
  );

  const value = useMemo(
    () => ({
      theme,
      resolvedTheme,
      setThemeMode: setMode,
      setCustomTheme: (customTheme: ThemeConfig) => {
        setMode('custom');
        setTheme(customTheme);
      },
      styles,
    }),
    [theme, resolvedTheme, styles]
  );

  return (
    <ThemeContext.Provider value={value}>
      <View style={styles.container}>{children}</View>
    </ThemeContext.Provider>
  );
};

export const useThemeContext = (): ThemeContextValue => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useThemeContext must be used within a ThemeProvider');
  }
  return context;
};

export const withTheme = <P extends object>(
  Component: React.ComponentType<P>
): React.FC<P> => {
  return (props) => {
    const theme = useThemeContext();
    return <Component {...props} theme={theme} />;
  };
};