import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  TouchableOpacity,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme } from '@/hooks';
import { FileNode } from '@/types';
import { LucideIcon } from '@/components/ui/LucideIcon';

interface FolderItemProps {
  node: FileNode;
  depth: number;
  isExpanded: boolean;
  isSelected: boolean;
  onToggle: () => void;
  onSelect: () => void;
  onAction: (action: 'rename' | 'delete' | 'duplicate' | 'download', file: FileNode) => void;
  style?: ViewStyle;
}

export const FolderItem = React.forwardRef<View, FolderItemProps>(
  ({ node, depth, isExpanded, isSelected, onToggle, onSelect, onAction, style }, ref) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const baseStyles = StyleSheet.create({
      container: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.sm,
        paddingLeft: spacing.md + depth * spacing.md,
        borderRadius: borderRadius.sm,
        minHeight: 36,
        ...style,
      },
      selected: {
        backgroundColor: colors.primary,
        opacity: 0.1,
      },
      expandButton: {
        padding: spacing.xs,
        marginRight: spacing.xs,
      },
      icon: {
        marginRight: spacing.sm,
      },
      name: {
        flex: 1,
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        fontWeight: '500',
        color: colors.onSurface,
      },
      nameSelected: {
        color: colors.primary,
      },
      count: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.5,
        marginLeft: spacing.sm,
      },
      menuButton: {
        padding: spacing.xs,
        borderRadius: borderRadius.sm,
      },
      childrenContainer: {
        overflow: 'hidden',
      },
    });

    const showContextMenu = () => {
      console.log('Context menu for folder:', node.name);
    };

    return (
      <TouchableWithoutFeedback
        ref={ref}
        onPress={onSelect}
        onLongPress={showContextMenu}
        accessibilityRole="button"
        accessibilityLabel={node.name}
        accessibilityHint={isExpanded ? 'Double tap to collapse' : 'Double tap to expand'}
      >
        <View
          style={[
            baseStyles.container,
            isSelected && baseStyles.selected,
          ]}
        >
          <TouchableOpacity style={baseStyles.expandButton} onPress={onToggle} accessibilityLabel={isExpanded ? 'Collapse' : 'Expand'}>
            <LucideIcon
              name={isExpanded ? 'chevron-down' : 'chevron-right'}
              size={16}
              color={colors.onSurface}
              opacity={0.7}
            />
          </TouchableOpacity>
          <View style={baseStyles.icon}>
            <LucideIcon
              name={isExpanded ? 'folder-open' : 'folder'}
              size={18}
              color={colors.primary}
            />
          </View>
          <Text
            style={[
              baseStyles.name,
              isSelected && baseStyles.nameSelected,
            ]}
            numberOfLines={1}
          >
            {node.name}
          </Text>
          {node.children && node.children.length > 0 && (
            <Text style={baseStyles.count}>
              {node.children.length} item{node.children.length !== 1 ? 's' : ''}
            </Text>
          )}
          <TouchableOpacity
            style={baseStyles.menuButton}
            onPress={showContextMenu}
            accessibilityLabel="More options"
          >
            <LucideIcon name="more-vertical" size={16} color={colors.onSurface} opacity={0.5} />
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    );
  }
);

FolderItem.displayName = 'FolderItem';