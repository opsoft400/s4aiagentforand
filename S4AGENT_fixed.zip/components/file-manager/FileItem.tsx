import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  TouchableOpacity,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme } from '@/hooks';
import { FileNode } from '@/types';
import { LucideIcon } from '@/components/ui/LucideIcon';

interface FileItemProps {
  node: FileNode;
  depth: number;
  isSelected: boolean;
  onSelect: () => void;
  onAction: (action: 'rename' | 'delete' | 'duplicate' | 'download', file: FileNode) => void;
  style?: ViewStyle;
}

const FILE_ICONS: Record<string, string> = {
  js: 'file-code',
  ts: 'file-code',
  tsx: 'file-code',
  jsx: 'file-code',
  json: 'file-json',
  html: 'file-code',
  css: 'file-code',
  scss: 'file-code',
  py: 'file-code',
  rs: 'file-code',
  go: 'file-code',
  java: 'file-code',
  cpp: 'file-code',
  c: 'file-code',
  h: 'file-code',
  md: 'file-text',
  txt: 'file-text',
  yaml: 'file-code',
  yml: 'file-code',
  xml: 'file-code',
  svg: 'image',
  png: 'image',
  jpg: 'image',
  jpeg: 'image',
  gif: 'image',
  webp: 'image',
  ico: 'image',
  pdf: 'file-text',
  zip: 'archive',
  tar: 'archive',
  gz: 'archive',
  rar: 'archive',
  default: 'file',
};

export const FileItem = React.forwardRef<View, FileItemProps>(
  ({ node, depth, isSelected, onSelect, onAction, style }, ref) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const ext = node.name.split('.').pop()?.toLowerCase() || '';
    const iconName = FILE_ICONS[ext] || FILE_ICONS.default;

    const baseStyles = StyleSheet.create({
      container: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: spacing.xs,
        paddingHorizontal: spacing.sm,
        paddingLeft: spacing.md + depth * spacing.md,
        borderRadius: borderRadius.sm,
        minHeight: 36,
        ...style,
      },
      selected: {
        backgroundColor: colors.primary,
        opacity: 0.1,
      },
      icon: {
        marginRight: spacing.sm,
      },
      name: {
        flex: 1,
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
      },
      nameSelected: {
        color: colors.primary,
        fontWeight: '500',
      },
      size: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.5,
        marginLeft: spacing.sm,
      },
      menuButton: {
        padding: spacing.xs,
        borderRadius: borderRadius.sm,
      },
    });

    const formatSize = (bytes?: number) => {
      if (!bytes) return '';
      if (bytes < 1024) return `${bytes}B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
      return `${(bytes / (1024 * 1024)).toFixed(1)}MB`;
    };

    const showContextMenu = () => {
      // In a real app, this would show a context menu
      // For now, we'll just log
      console.log('Context menu for:', node.name);
    };

    return (
      <TouchableWithoutFeedback
        ref={ref}
        onPress={onSelect}
        onLongPress={showContextMenu}
        accessibilityRole="button"
        accessibilityLabel={node.name}
        accessibilityHint="Double tap to open, long press for options"
      >
        <View
          style={[
            baseStyles.container,
            isSelected && baseStyles.selected,
          ]}
        >
          <View style={baseStyles.icon}>
            <LucideIcon name={iconName} size={18} color={colors.onSurface} />
          </View>
          <Text
            style={[
              baseStyles.name,
              isSelected && baseStyles.nameSelected,
            ]}
            numberOfLines={1}
          >
            {node.name}
          </Text>
          {node.size && (
            <Text style={baseStyles.size}>{formatSize(node.size)}</Text>
          )}
          <TouchableOpacity
            style={baseStyles.menuButton}
            onPress={showContextMenu}
            accessibilityLabel="More options"
          >
            <LucideIcon name="more-vertical" size={16} color={colors.onSurface} opacity={0.5} />
          </TouchableOpacity>
        </View>
      </TouchableWithoutFeedback>
    );
  }
);

FileItem.displayName = 'FileItem';