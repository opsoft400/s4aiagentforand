import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  FlatList,
  Animated,
  ViewStyle,
  TextStyle,
  Keyboard,
} from 'react-native';
import { useTheme } from '@/hooks';
import { FileNode } from '@/types';
import { FileItem } from './FileItem';
import { FolderItem } from './FolderItem';

interface FileTreeProps {
  rootNode: FileNode;
  onFileSelect: (file: FileNode) => void;
  onFileAction: (action: 'rename' | 'delete' | 'duplicate' | 'download', file: FileNode) => void;
  onFolderToggle: (folderId: string) => void;
  selectedFileId?: string;
  searchQuery?: string;
  showHidden?: boolean;
  style?: ViewStyle;
}

export const FileTree = React.forwardRef<View, FileTreeProps>(
  (
    {
      rootNode,
      onFileSelect,
      onFileAction,
      onFolderToggle,
      selectedFileId,
      searchQuery = '',
      showHidden = false,
      style,
    },
    ref
  ) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();
    const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['root']));

    useEffect(() => {
      if (rootNode.isExpanded) {
        setExpandedFolders((prev) => new Set(prev).add('root'));
      }
    }, [rootNode.isExpanded]);

    const filterNodes = useCallback(
      (nodes: FileNode[]): FileNode[] => {
        if (!searchQuery) return nodes;

        const filtered: FileNode[] = [];
        const query = searchQuery.toLowerCase();

        for (const node of nodes) {
          const matchesName = node.name.toLowerCase().includes(query);
          const matchesType = node.type === 'file' && query.includes('.');

          if (!showHidden && node.name.startsWith('.')) continue;

          if (matchesName || matchesType) {
            filtered.push(node);
          }

          if (node.type === 'folder' && node.children) {
            const childMatches = filterNodes(node.children);
            if (childMatches.length > 0) {
              filtered.push({
                ...node,
                children: childMatches,
                isExpanded: true,
              });
            }
          }
        }
        return filtered;
      },
      [searchQuery, showHidden]
    );

    const renderNode = useCallback(
      (node: FileNode, depth = 0): React.ReactElement => {
        const isExpanded = expandedFolders.has(node.id);
        const isSelected = node.id === selectedFileId;

        if (node.type === 'folder') {
          return (
            <FolderItem
              key={node.id}
              node={node}
              depth={depth}
              isExpanded={isExpanded}
              isSelected={isSelected}
              onToggle={() => {
                const newExpanded = new Set(expandedFolders);
                if (isExpanded) {
                  newExpanded.delete(node.id);
                } else {
                  newExpanded.add(node.id);
                }
                setExpandedFolders(newExpanded);
                onFolderToggle(node.id);
              }}
              onSelect={() => onFileSelect(node)}
              onAction={onFileAction}
            />
          );
        } else {
          return (
            <FileItem
              key={node.id}
              node={node}
              depth={depth}
              isSelected={isSelected}
              onSelect={() => onFileSelect(node)}
              onAction={onFileAction}
            />
          );
        }
      },
      [expandedFolders, selectedFileId, onFileSelect, onFolderToggle, onFileAction]
    );

    const filteredChildren = filterNodes(rootNode.children || []);

    return (
      <View ref={ref} style={[styles.container, style]}>
        <FlatList
          data={filteredChildren}
          renderItem={({ item }) => renderNode(item)}
          keyExtractor={(item) => item.id}
          style={styles.list}
          contentContainerStyle={styles.listContent}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>
                {searchQuery ? 'No files match your search' : 'No files in this directory'}
              </Text>
            </View>
          }
        />
      </View>
    );
  }
);

FileTree.displayName = 'FileTree';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  list: {
    flex: 1,
  },
  listContent: {
    paddingVertical: 4,
  },
  separator: {
    height: 1,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    opacity: 0.5,
  },
});