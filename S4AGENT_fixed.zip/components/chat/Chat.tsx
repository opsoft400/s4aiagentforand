import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ScrollView,
  TextInput,
  Keyboard,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme } from '@/hooks';
import { AIMessage } from '@/types';
import { MessageBubble } from './MessageBubble';
import { TypingIndicator } from './TypingIndicator';
import { LucideIcon } from '@/components/ui/LucideIcon';

interface ChatProps {
  messages: AIMessage[];
  onSendMessage: (content: string) => void;
  isLoading?: boolean;
  placeholder?: string;
  style?: ViewStyle;
}

export const Chat = React.forwardRef<View, ChatProps>(
  ({ messages, onSendMessage, isLoading = false, placeholder = 'Ask me anything...', style }, ref) => {
    const { theme, colors, spacing, typography } = useTheme();
    const scrollViewRef = useRef<ScrollView>(null);
    const [inputValue, setInputValue] = useState('');
    const [inputHeight, setInputHeight] = useState(48);
    const flatListRef = useRef<FlatList<AIMessage>>(null);

    useEffect(() => {
      if (flatListRef.current) {
        flatListRef.current.scrollToEnd({ animated: true });
      }
    }, [messages]);

    const handleSend = () => {
      if (inputValue.trim() && !isLoading) {
        onSendMessage(inputValue.trim());
        setInputValue('');
        setInputHeight(48);
      }
    };

    const handleTextChange = (text: string) => {
      setInputValue(text);
      // Auto-resize input
      const lines = text.split('\n').length;
      setInputHeight(Math.min(48 + (lines - 1) * 24, 200));
    };

    const renderMessage = ({ item }: { item: AIMessage }) => (
      <MessageBubble message={item} />
    );

    return (
      <View ref={ref} style={[styles.container, style]}>
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          style={styles.list}
          contentContainerStyle={styles.listContent}
          inverted={false}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
        />
        {isLoading && <TypingIndicator />}
        <View style={styles.inputContainer}>
          <View style={[styles.inputWrapper, { height: inputHeight }]}>
            <TextInput
              style={[
                styles.input,
                { minHeight: inputHeight, maxHeight: inputHeight },
              ]}
              value={inputValue}
              onChangeText={handleTextChange}
              onSubmitEditing={handleSend}
              placeholder={placeholder}
              placeholderTextColor={colors.onSurface}
              multiline={true}
              maxLength={4000}
              autoFocus={false}
              blurOnSubmit={false}
              returnsRightIcon={true}
              rightIcon={
                <TouchableWithoutFeedback onPress={handleSend} disabled={isLoading || !inputValue.trim()}>
                  <View style={styles.sendButton}>
                    <LucideIcon
                      name="send"
                      size={20}
                      color={inputValue.trim() && !isLoading ? colors.primary : colors.onSurface}
                      opacity={inputValue.trim() && !isLoading ? 1 : 0.4}
                    />
                  </View>
                </TouchableWithoutFeedback>
              }
            />
          </View>
        </View>
      </View>
    );
  }
);

Chat.displayName = 'Chat';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: 16,
    gap: 12,
  },
  inputContainer: {
    padding: 16,
    borderTopWidth: 1,
  },
  inputWrapper: {
    backgroundColor: 'transparent',
    borderRadius: 24,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  input: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'JetBrains Mono',
    paddingVertical: 8,
    paddingRight: 44,
  },
  sendButton: {
    position: 'absolute',
    right: 8,
    bottom: 8,
    padding: 4,
  },
});