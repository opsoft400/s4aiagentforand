import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { useTheme } from '@/hooks';

interface TypingIndicatorProps {
  text?: string;
  style?: ViewStyle;
}

export const TypingIndicator = React.forwardRef<View, TypingIndicatorProps>(
  ({ text = 'AI is thinking...', style }, ref) => {
    const { theme, colors, spacing, typography } = useTheme();
    const animationRef = useRef(new Animated.Value(0)).current;

    useEffect(() => {
      animationRef.setValue(0);
      Animated.timing(animationRef, {
        toValue: 1,
        duration: 1500,
        useNativeDriver: true,
        easing: (t) => t,
      }).start(({ finished }) => {
        if (finished) {
          animationRef.setValue(0);
        }
      });
    }, []);

    const dotAnimation = (index: number) => {
      return animationRef.interpolate({
        inputRange: [0, 1],
        outputRange: [0, 1],
      });
    };

    return (
      <View
        ref={ref}
        style={[
          styles.container,
          style,
        ]}
      >
        <View style={styles.dots}>
          {[0, 1, 2].map((i) => (
            <Animated.View
              key={i}
              style={[
                styles.dot,
                {
                  transform: [
                    {
                      translateY: animationRef.interpolate({
                        inputRange: [0, 0.3, 0.6, 1],
                        outputRange: [
                          0,
                          -8,
                          -8,
                          0,
                        ],
                      }),
                    },
                  ],
                },
              ]}
            />
          ))}
        </View>
        {text && <Text style={[styles.text, { color: colors.onSurface, opacity: 0.6 }]}>{text}</Text>}
      </View>
    );
  }
);

TypingIndicator.displayName = 'TypingIndicator';

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  dots: {
    flexDirection: 'row',
    gap: 4,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#0ea5e9',
  },
  text: {
    fontSize: 14,
    fontFamily: 'JetBrains Mono',
  },
});