import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { useTheme } from '@/hooks';
import { AIMessage } from '@/types';
import { LucideIcon } from '@/components/ui/LucideIcon';

interface MessageBubbleProps {
  message: AIMessage;
  style?: ViewStyle;
}

export const MessageBubble = React.forwardRef<View, MessageBubbleProps>(
  ({ message, style }, ref) => {
    const { theme, colors, spacing, typography, borderRadius } = useTheme();

    const isUser = message.role === 'user';
    const isAssistant = message.role === 'assistant';
    const isTool = message.role === 'tool';
    const isSystem = message.role === 'system';

    const baseStyles = StyleSheet.create({
      container: {
        flexDirection: isUser ? 'row-reverse' : 'row',
        alignItems: 'flex-start',
        gap: spacing.sm,
        maxWidth: '85%',
        alignSelf: isUser ? 'flex-end' : 'flex-start',
        ...style,
      },
      avatar: {
        width: 32,
        height: 32,
        borderRadius: 16,
        justifyContent: 'center',
        alignItems: 'center',
        flexShrink: 0,
      },
      userAvatar: {
        backgroundColor: colors.primary,
      },
      assistantAvatar: {
        backgroundColor: colors.surfaceVariant,
      },
      toolAvatar: {
        backgroundColor: colors.warning,
        opacity: 0.2,
      },
      systemAvatar: {
        backgroundColor: colors.info,
        opacity: 0.2,
      },
      bubble: {
        padding: spacing.md,
        borderRadius: borderRadius.lg,
        maxWidth: '100%',
      },
      userBubble: {
        backgroundColor: colors.primary,
        borderBottomRightRadius: 4,
      },
      assistantBubble: {
        backgroundColor: colors.surfaceVariant,
        borderBottomLeftRadius: 4,
        borderWidth: 1,
        borderColor: colors.border,
      },
      toolBubble: {
        backgroundColor: colors.warning,
        opacity: 0.1,
        borderBottomLeftRadius: 4,
        borderWidth: 1,
        borderColor: colors.warning,
      },
      systemBubble: {
        backgroundColor: colors.info,
        opacity: 0.1,
        borderBottomLeftRadius: 4,
        borderWidth: 1,
        borderColor: colors.info,
      },
      content: {
        fontSize: typography.fontSize.md,
        fontFamily: typography.fontFamily,
        lineHeight: typography.fontSize.md * typography.lineHeight.relaxed,
      },
      userContent: {
        color: colors.onPrimary,
      },
      assistantContent: {
        color: colors.onSurface,
      },
      toolContent: {
        color: colors.warning,
        fontFamily: typography.fontFamily,
        fontSize: typography.fontSize.sm,
      },
      systemContent: {
        color: colors.info,
        fontSize: typography.fontSize.sm,
        fontStyle: 'italic',
      },
      toolCalls: {
        marginTop: spacing.sm,
        paddingTop: spacing.sm,
        borderTopWidth: 1,
        borderTopColor: colors.border,
        opacity: 0.7,
      },
      toolCall: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacing.xs,
        marginBottom: spacing.xs,
        padding: spacing.xs,
        backgroundColor: colors.surface,
        borderRadius: borderRadius.sm,
      },
      toolCallName: {
        fontFamily: typography.fontFamily,
        fontSize: typography.fontSize.xs,
        fontWeight: '500',
        color: colors.primary,
      },
      toolCallArgs: {
        fontFamily: typography.fontFamily,
        fontSize: typography.fontSize.xs,
        color: colors.onSurface,
        opacity: 0.7,
      },
      timestamp: {
        fontSize: typography.fontSize.xs,
        fontFamily: typography.fontFamily,
        color: colors.onSurface,
        opacity: 0.5,
        marginTop: spacing.xs,
        alignSelf: isUser ? 'flex-end' : 'flex-start',
      },
    });

    const formatTime = (date: Date) => {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    };

    return (
      <View ref={ref} style={baseStyles.container}>
        {!isUser && (
          <View
            style={[
              baseStyles.avatar,
              isAssistant && baseStyles.assistantAvatar,
              isTool && baseStyles.toolAvatar,
              isSystem && baseStyles.systemAvatar,
            ]}
          >
            <LucideIcon
              name={isAssistant ? 'bot' : isTool ? 'wrench' : 'info'}
              size={16}
              color={
                isAssistant
                  ? colors.onSurface
                  : isTool
                  ? colors.warning
                  : colors.info
              }
            />
          </View>
        )}
        <View
          style={[
            baseStyles.bubble,
            isUser && baseStyles.userBubble,
            isAssistant && baseStyles.assistantBubble,
            isTool && baseStyles.toolBubble,
            isSystem && baseStyles.systemBubble,
          ]}
        >
          <Text
            style={[
              baseStyles.content,
              isUser && baseStyles.userContent,
              isAssistant && baseStyles.assistantContent,
              isTool && baseStyles.toolContent,
              isSystem && baseStyles.systemContent,
            ]}
          >
            {message.content}
          </Text>

          {message.toolCalls && message.toolCalls.length > 0 && (
            <View style={baseStyles.toolCalls}>
              {message.toolCalls.map((toolCall) => (
                <View key={toolCall.id} style={baseStyles.toolCall}>
                  <LucideIcon name="terminal" size={12} color={colors.primary} />
                  <Text style={baseStyles.toolCallName}>
                    {toolCall.function.name}
                  </Text>
                  <Text style={baseStyles.toolCallArgs}>
                    {toolCall.function.arguments}
                  </Text>
                </View>
              ))}
            </View>
          )}

          <Text style={baseStyles.timestamp}>{formatTime(message.timestamp)}</Text>
        </View>
        {isUser && (
          <View style={[baseStyles.avatar, baseStyles.userAvatar]}>
            <LucideIcon name="user" size={16} color={colors.onPrimary} />
          </View>
        )}
      </View>
    );
  }
);

MessageBubble.displayName = 'MessageBubble';