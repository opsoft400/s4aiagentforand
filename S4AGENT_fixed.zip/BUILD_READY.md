# S4AGENT build notes
- Removed unused deps (nativewind, tailwind, react-native-fs, zip-archive, clipboard, sharing, document-picker, ws, etc.).
- Fixed babel config, added module-resolver, expo-linking.
- Added GestureHandlerRoot, SafeAreaProvider and portalize Host in app/_layout.tsx.
- Fixed APK path in .github/workflows/build-apk.yml (android/app/build/...).
- Disabled new architecture for Expo 51 compatibility.
Build: push to GitHub and run the "Build Android APK" workflow, or `npm install --legacy-peer-deps && npx expo prebuild && cd android && ./gradlew assembleRelease`.
