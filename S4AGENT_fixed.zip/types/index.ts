export interface FileNode {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  size?: number;
  mimeType?: string;
  children?: FileNode[];
  parentId?: string;
  isExpanded?: boolean;
  isSelected?: boolean;
  modifiedAt: Date;
  createdAt: Date;
  gitStatus?: 'added' | 'modified' | 'deleted' | 'untracked' | 'ignored';
}

export interface FileOperation {
  type: 'create' | 'read' | 'update' | 'delete' | 'move' | 'copy' | 'rename';
  path: string;
  content?: string;
  newPath?: string;
  encoding?: 'utf-8' | 'base64';
}

export interface ZipOptions {
  compressionLevel?: number;
  password?: string;
  includeHidden?: boolean;
  excludePatterns?: string[];
}

export interface ZipResult {
  success: boolean;
  path?: string;
  error?: string;
  size?: number;
}

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  timestamp: Date;
  toolCalls?: ToolCall[];
  toolCallId?: string;
  metadata?: Record<string, unknown>;
}

export interface ToolCall {
  id: string;
  type: 'function';
  function: {
    name: string;
    arguments: string;
  };
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<string, ToolParameter>;
    required: string[];
  };
}

export interface ToolParameter {
  type: string;
  description: string;
  enum?: string[];
  default?: unknown;
}

export interface AgentConfig {
  model: string;
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
  tools: ToolDefinition[];
  apiProvider: 'opencode' | 'deepseek' | 'ollama' | 'custom';
  apiEndpoint: string;
  apiKey?: string;
}

export interface OpencodeSession {
  id: string;
  name: string;
  projectPath: string;
  messages: AIMessage[];
  createdAt: Date;
  updatedAt: Date;
  status: 'active' | 'idle' | 'error';
}

export interface OpencodeAgent {
  id: string;
  name: string;
  description: string;
  model: string;
  tools: string[];
  systemPrompt: string;
}

export interface DeepSeekModel {
  id: string;
  name: string;
  size: string;
  parameters: string;
  quantization: string;
}

export interface GitHubRepo {
  id: number;
  name: string;
  fullName: string;
  description: string;
  private: boolean;
  htmlUrl: string;
  cloneUrl: string;
  defaultBranch: string;
  updatedAt: string;
  stargazers_count?: number;
  forks_count?: number;
  language?: string;
  topics?: string[];
}

export interface GitHubFile {
  name: string;
  path: string;
  sha: string;
  size: number;
  url: string;
  htmlUrl: string;
  gitUrl: string;
  downloadUrl: string;
  type: 'file' | 'dir';
  content?: string;
  encoding?: 'base64';
}

export interface GitHubUser {
  login: string;
  id: number;
  avatarUrl: string;
  name: string;
  email: string;
}

export interface GitHubBranch {
  name: string;
  commit: {
    sha: string;
    url: string;
  };
  protected: boolean;
}

export interface GitHubCommit {
  sha: string;
  commit: {
    author: {
      name: string;
      email: string;
      date: string;
    };
    message: string;
  };
  htmlUrl: string;
}

export interface GitHubPullRequest {
  number: number;
  title: string;
  body: string;
  state: 'open' | 'closed';
  head: {
    ref: string;
    sha: string;
    repo: { fullName: string };
  };
  base: {
    ref: string;
    sha: string;
    repo: { fullName: string };
  };
  htmlUrl: string;
  user: GitHubUser;
  createdAt: string;
  updatedAt: string;
  mergedAt?: string;
}

export interface ThemeConfig {
  name: string;
  colors: {
    background: string;
    surface: string;
    surfaceVariant: string;
    primary: string;
    primaryVariant: string;
    secondary: string;
    onBackground: string;
    onSurface: string;
    onPrimary: string;
    onSecondary: string;
    border: string;
    divider: string;
    error: string;
    warning: string;
    success: string;
    info: string;
  };
  spacing: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  };
  typography: {
    fontFamily: string;
    fontSize: {
      xs: number;
      sm: number;
      md: number;
      lg: number;
      xl: number;
      xxl: number;
    };
    fontWeight: {
      normal: number;
      medium: number;
      bold: number;
    };
    lineHeight: {
      tight: number;
      normal: number;
      relaxed: number;
    };
  };
  borderRadius: {
    none: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    full: number;
  };
  shadows: {
    sm: string;
    md: string;
    lg: string;
    xl: string;
  };
  animations: {
    fast: number;
    normal: number;
    slow: number;
  };
}

export interface UserPreferences {
  theme: 'light' | 'dark' | 'system' | 'custom';
  customTheme?: ThemeConfig;
  layout: 'ide' | 'chat' | 'minimal' | 'custom';
  fontSize: number;
  fontFamily: string;
  sidebarWidth: number;
  panelHeight: number;
  showLineNumbers: boolean;
  wordWrap: boolean;
  tabSize: number;
  autoSave: boolean;
  aiConfirmActions: boolean;
  aiAutoRunTools: boolean;
  language: string;
  keyboardShortcuts: Record<string, string>;
}

export interface AppState {
  currentProject: string | null;
  fileTree: FileNode | null;
  openFiles: Map<string, FileNode>;
  activeFile: string | null;
  chatHistory: AIMessage[];
  agentConfig: AgentConfig;
  preferences: UserPreferences;
  isConnected: boolean;
  connectionStatus: 'connecting' | 'connected' | 'disconnected' | 'error';
  githubToken: string | null;
  githubUser: GitHubUser | null;
}

export interface BuildConfig {
  version: string;
  buildNumber: number;
  keystorePath?: string;
  keystorePassword?: string;
  keyAlias?: string;
  keyPassword?: string;
  outputDir: string;
}

export interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  files: TemplateFile[];
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
}

export interface TemplateFile {
  path: string;
  content: string;
  isTemplate?: boolean;
}